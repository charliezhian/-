package m;

public interface c {
  j ALLATORIxDEMO(String paramString1, String paramString2) throws Exception;
  
  j ALLATORIxDEMO(String paramString) throws Exception;
  
  j IiIIiIIIii(String paramString) throws Exception;
}


/* Location:              C:\Users\zyh\Desktop\ThinkphpGUI-1.3-SNAPSHOT.jar!\m\c.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */