package d;

public interface i {
  yb IiIIiIIIii(String paramString) throws Exception;
  
  yb ALLATORIxDEMO(String paramString) throws Exception;
  
  yb ALLATORIxDEMO(String paramString1, String paramString2) throws Exception;
}


/* Location:              C:\Users\zyh\Desktop\ThinkphpGUI-1.3-SNAPSHOT.jar!\d\i.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */