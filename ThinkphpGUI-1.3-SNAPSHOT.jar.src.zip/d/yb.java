/*     */ package d;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class yb
/*     */ {
/*     */   String ALLATORIxDEMO;
/*     */   boolean IIiIiIIIII;
/*     */   String iiiIiiIiII;
/*     */   
/*     */   public boolean ALLATORIxDEMO() {
/*  27 */     return this.IIiIiIIIII;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void ALLATORIxDEMO(String vuln) {
/*  88 */     this.ALLATORIxDEMO = vuln;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String IiIIiIIIii() {
/* 111 */     return this.iiiIiiIiII;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void IiIIiIIIii(String payload) {
/* 209 */     this.iiiIiiIiII = payload;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String ALLATORIxDEMO() {
/* 256 */     return this.ALLATORIxDEMO;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public yb(int res, String vuln, String payload) {
/* 275 */     this.IIiIiIIIII = SYNTHETIC_LOCAL_VARIABLE_1; this.iiiIiiIiII = (String)SYNTHETIC_LOCAL_VARIABLE_3; this.ALLATORIxDEMO = (String)SYNTHETIC_LOCAL_VARIABLE_2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void ALLATORIxDEMO(int res) {
/* 288 */     this.IIiIiIIIII = res;
/*     */   }
/*     */   
/*     */   public static String IiIIiIIIii(String s) {
/*     */     // Byte code:
/*     */     //   0: iconst_2
/*     */     //   1: iconst_5
/*     */     //   2: ixor
/*     */     //   3: iconst_4
/*     */     //   4: ishl
/*     */     //   5: iconst_4
/*     */     //   6: iconst_1
/*     */     //   7: ishl
/*     */     //   8: ixor
/*     */     //   9: iconst_3
/*     */     //   10: iconst_5
/*     */     //   11: ixor
/*     */     //   12: iconst_4
/*     */     //   13: ishl
/*     */     //   14: iconst_2
/*     */     //   15: iconst_5
/*     */     //   16: ixor
/*     */     //   17: ixor
/*     */     //   18: iconst_4
/*     */     //   19: dup
/*     */     //   20: ishl
/*     */     //   21: iconst_2
/*     */     //   22: dup
/*     */     //   23: ishl
/*     */     //   24: iconst_1
/*     */     //   25: ixor
/*     */     //   26: ixor
/*     */     //   27: aload_0
/*     */     //   28: checkcast java/lang/String
/*     */     //   31: dup
/*     */     //   32: astore_0
/*     */     //   33: invokevirtual length : ()I
/*     */     //   36: dup
/*     */     //   37: newarray char
/*     */     //   39: iconst_1
/*     */     //   40: dup
/*     */     //   41: iconst_1
/*     */     //   42: dup
/*     */     //   43: pop2
/*     */     //   44: pop2
/*     */     //   45: swap
/*     */     //   46: iconst_1
/*     */     //   47: isub
/*     */     //   48: dup_x2
/*     */     //   49: istore_3
/*     */     //   50: astore_1
/*     */     //   51: istore #4
/*     */     //   53: dup_x2
/*     */     //   54: pop
/*     */     //   55: istore_2
/*     */     //   56: pop
/*     */     //   57: iflt -> 98
/*     */     //   60: aload_1
/*     */     //   61: aload_0
/*     */     //   62: iload_3
/*     */     //   63: dup_x1
/*     */     //   64: invokevirtual charAt : (I)C
/*     */     //   67: iload_2
/*     */     //   68: ixor
/*     */     //   69: i2c
/*     */     //   70: iinc #3, -1
/*     */     //   73: castore
/*     */     //   74: iload_3
/*     */     //   75: iflt -> 98
/*     */     //   78: aload_1
/*     */     //   79: aload_0
/*     */     //   80: iload_3
/*     */     //   81: dup_x1
/*     */     //   82: invokevirtual charAt : (I)C
/*     */     //   85: iload #4
/*     */     //   87: iinc #3, -1
/*     */     //   90: ixor
/*     */     //   91: i2c
/*     */     //   92: castore
/*     */     //   93: iload_3
/*     */     //   94: goto -> 57
/*     */     //   97: athrow
/*     */     //   98: new java/lang/String
/*     */     //   101: dup
/*     */     //   102: aload_1
/*     */     //   103: invokespecial <init> : ([C)V
/*     */     //   106: areturn
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	107	0	s	Ljava/lang/String;
/*     */   }
/*     */   
/*     */   public static String ALLATORIxDEMO(String s) {
/*     */     // Byte code:
/*     */     //   0: iconst_3
/*     */     //   1: iconst_5
/*     */     //   2: ixor
/*     */     //   3: iconst_3
/*     */     //   4: ishl
/*     */     //   5: iconst_1
/*     */     //   6: ixor
/*     */     //   7: iconst_3
/*     */     //   8: iconst_5
/*     */     //   9: ixor
/*     */     //   10: iconst_4
/*     */     //   11: ishl
/*     */     //   12: iconst_2
/*     */     //   13: iconst_5
/*     */     //   14: ixor
/*     */     //   15: iconst_1
/*     */     //   16: ishl
/*     */     //   17: ixor
/*     */     //   18: iconst_5
/*     */     //   19: iconst_3
/*     */     //   20: ishl
/*     */     //   21: iconst_2
/*     */     //   22: ixor
/*     */     //   23: aload_0
/*     */     //   24: checkcast java/lang/String
/*     */     //   27: dup
/*     */     //   28: astore_0
/*     */     //   29: invokevirtual length : ()I
/*     */     //   32: dup
/*     */     //   33: newarray char
/*     */     //   35: iconst_1
/*     */     //   36: dup
/*     */     //   37: pop2
/*     */     //   38: swap
/*     */     //   39: iconst_1
/*     */     //   40: isub
/*     */     //   41: dup_x2
/*     */     //   42: istore_3
/*     */     //   43: astore_1
/*     */     //   44: istore #4
/*     */     //   46: dup_x2
/*     */     //   47: pop2
/*     */     //   48: istore_2
/*     */     //   49: iflt -> 89
/*     */     //   52: aload_1
/*     */     //   53: aload_0
/*     */     //   54: iload_3
/*     */     //   55: dup_x1
/*     */     //   56: invokevirtual charAt : (I)C
/*     */     //   59: iinc #3, -1
/*     */     //   62: iload_2
/*     */     //   63: ixor
/*     */     //   64: i2c
/*     */     //   65: castore
/*     */     //   66: iload_3
/*     */     //   67: iflt -> 89
/*     */     //   70: aload_1
/*     */     //   71: aload_0
/*     */     //   72: iload_3
/*     */     //   73: iinc #3, -1
/*     */     //   76: dup_x1
/*     */     //   77: invokevirtual charAt : (I)C
/*     */     //   80: iload #4
/*     */     //   82: ixor
/*     */     //   83: i2c
/*     */     //   84: castore
/*     */     //   85: iload_3
/*     */     //   86: goto -> 49
/*     */     //   89: new java/lang/String
/*     */     //   92: dup
/*     */     //   93: aload_1
/*     */     //   94: invokespecial <init> : ([C)V
/*     */     //   97: areturn
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	98	0	s	Ljava/lang/String;
/*     */   }
/*     */ }


/* Location:              C:\Users\zyh\Desktop\ThinkphpGUI-1.3-SNAPSHOT.jar!\d\yb.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */