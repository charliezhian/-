/*    */ package dylan.tools;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import org.apache.commons.configuration.PropertiesConfiguration;
/*    */ import org.apache.commons.configuration.reloading.FileChangedReloadingStrategy;
/*    */ import org.apache.commons.configuration.reloading.ReloadingStrategy;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Config
/*    */ {
/*    */   private static PropertiesConfiguration propConfig;
/* 16 */   private static final Config CONFIG = new Config();
/*    */ 
/*    */   
/*    */   private static final boolean autoSave = true;
/*    */ 
/*    */   
/*    */   public static Config getInstance(String propertiesFile) {
/* 23 */     init(propertiesFile);
/* 24 */     return CONFIG;
/*    */   }
/*    */   
/*    */   private static void init(String propertiesFile) {
/*    */     try {
/* 29 */       File f = new File(propertiesFile);
/* 30 */       if (!f.exists()) {
/* 31 */         f.createNewFile();
/*    */       }
/*    */       
/* 34 */       propConfig = new PropertiesConfiguration(propertiesFile);
/* 35 */       propConfig.setReloadingStrategy((ReloadingStrategy)new FileChangedReloadingStrategy());
/* 36 */       propConfig.setAutoSave(true);
/* 37 */     } catch (IOException|org.apache.commons.configuration.ConfigurationException var2) {
/* 38 */       var2.printStackTrace();
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getValue(String key) {
/* 44 */     return propConfig.getProperty(key);
/*    */   }
/*    */   
/*    */   public int getIntValue(String key) {
/* 48 */     return propConfig.getInt(key);
/*    */   }
/*    */   
/*    */   public boolean getBooleanValue(String key) {
/* 52 */     return propConfig.getBoolean(key, false);
/*    */   }
/*    */   
/*    */   public String getStringValue(String key) {
/* 56 */     return propConfig.getString(key);
/*    */   }
/*    */   
/*    */   public void setProperty(String key, Object value) {
/* 60 */     propConfig.setProperty(key, value);
/*    */   }
/*    */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\dylan\tools\Config.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */