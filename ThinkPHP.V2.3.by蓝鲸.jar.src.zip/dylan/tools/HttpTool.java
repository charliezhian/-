/*     */ package dylan.tools;
/*     */ import dylan.model.Response;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.Proxy;
/*     */ import java.net.SocketTimeoutException;
/*     */ import java.net.URL;
/*     */ import java.security.GeneralSecurityException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.HashMap;
/*     */ import javax.net.ssl.HostnameVerifier;
/*     */ import javax.net.ssl.HttpsURLConnection;
/*     */ import javax.net.ssl.SSLContext;
/*     */ import javax.net.ssl.SSLSession;
/*     */ import javax.net.ssl.TrustManager;
/*     */ 
/*     */ public class HttpTool {
/*  21 */   private static String UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36"; private static final String CODING = "UTF-8";
/*  22 */   private static final Config config = Config.getInstance("config.properties");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Response get(String url, HashMap<String, String> property) {
/*  30 */     Response response = new Response(0, null, null, null);
/*     */     try {
/*  32 */       HttpURLConnection conn = getCoon(url);
/*  33 */       conn.setRequestMethod("GET");
/*  34 */       for (String key : property.keySet()) {
/*  35 */         conn.setRequestProperty(key, property.get(key));
/*     */       }
/*  37 */       response = getResponse(conn);
/*  38 */     } catch (SocketTimeoutException e) {
/*  39 */       System.out.println(e.getMessage());
/*  40 */       response.setError("连接超时!");
/*  41 */     } catch (IOException e) {
/*  42 */       System.out.println(e.getMessage());
/*  43 */       response.setError(e.getMessage());
/*  44 */     } catch (NoSuchAlgorithmException|KeyManagementException|NoSuchProviderException e) {
/*  45 */       e.printStackTrace();
/*  46 */       response.setError(e.getMessage());
/*     */     } 
/*  48 */     return response;
/*     */   }
/*     */   
/*     */   public static Response post(String url, String params, HashMap<String, String> property) {
/*  52 */     Response response = new Response(0, null, null, null);
/*     */ 
/*     */     
/*     */     try {
/*  56 */       HttpURLConnection conn = getCoon(url);
/*  57 */       conn.setRequestMethod("POST");
/*     */ 
/*     */       
/*  60 */       for (String key : property.keySet()) {
/*  61 */         conn.setRequestProperty(key, property.get(key));
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  67 */       OutputStream outputStream = conn.getOutputStream();
/*  68 */       outputStream.write(params.getBytes());
/*  69 */       outputStream.flush();
/*  70 */       outputStream.close();
/*  71 */       response = getResponse(conn);
/*  72 */     } catch (IOException e) {
/*     */       
/*  74 */       response.setError(e.getMessage());
/*  75 */     } catch (NoSuchAlgorithmException|KeyManagementException|NoSuchProviderException e) {
/*  76 */       e.printStackTrace();
/*  77 */       response.setError(e.getMessage());
/*     */     } 
/*  79 */     return response;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Response getResponse(HttpURLConnection conn) {
/*  90 */     Response response = new Response(0, null, null, null);
/*     */     try {
/*  92 */       conn.connect();
/*  93 */       response.setCode(conn.getResponseCode());
/*  94 */       response.setHead(conn.getHeaderFields().toString());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 103 */       response.setText(streamToString(conn.getInputStream()));
/*     */ 
/*     */     
/*     */     }
/* 107 */     catch (IOException e) {
/*     */       
/* 109 */       response.setError(e.getMessage());
/*     */     } 
/*     */     
/* 112 */     return response;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static HttpURLConnection getCoon(String url) throws IOException, NoSuchProviderException, NoSuchAlgorithmException, KeyManagementException {
/* 123 */     SSLContext sslcontext = SSLContext.getInstance("SSL", "SunJSSE");
/* 124 */     TrustManager[] tm = { new Cert() };
/* 125 */     sslcontext.init(null, tm, new SecureRandom());
/* 126 */     HostnameVerifier ignoreHostnameVerifier = new HostnameVerifier() {
/*     */         public boolean verify(String s, SSLSession sslsession) {
/* 128 */           System.out.println("WARNING: Hostname is not matched for cert.");
/* 129 */           return true;
/*     */         }
/*     */       };
/* 132 */     HttpsURLConnection.setDefaultHostnameVerifier(ignoreHostnameVerifier);
/* 133 */     HttpsURLConnection.setDefaultSSLSocketFactory(sslcontext.getSocketFactory());
/*     */ 
/*     */ 
/*     */     
/* 137 */     URL url_object = new URL(url);
/* 138 */     HttpURLConnection conn = (HttpURLConnection)url_object.openConnection();
/*     */     
/* 140 */     boolean isProxy = config.getBooleanValue("isProxy");
/* 141 */     boolean isUA = config.getBooleanValue("isUA");
/*     */     
/* 143 */     if (isProxy) {
/* 144 */       String proxyIP = config.getStringValue("proxyIP");
/* 145 */       int proxyPort = config.getIntValue("proxyPort");
/*     */       
/* 147 */       InetSocketAddress addr = new InetSocketAddress(proxyIP, proxyPort);
/* 148 */       Proxy proxy = new Proxy(Proxy.Type.HTTP, addr);
/* 149 */       conn = (HttpURLConnection)url_object.openConnection(proxy);
/*     */     } 
/*     */     
/* 152 */     if (isUA) {
/* 153 */       UA = config.getStringValue("UA");
/*     */     }
/*     */     
/* 156 */     conn.setRequestProperty("User-Agent", UA);
/* 157 */     conn.setConnectTimeout(30000);
/* 158 */     conn.setReadTimeout(30000);
/* 159 */     conn.setDoOutput(true);
/* 160 */     conn.setDoInput(true);
/* 161 */     conn.setUseCaches(false);
/* 162 */     conn.setInstanceFollowRedirects(false);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 167 */     return conn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String streamToString(InputStream inputStream) {
/* 177 */     String resultString = null;
/*     */     
/* 179 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/* 180 */     int len = 0;
/* 181 */     byte[] data = new byte[1024];
/*     */     try {
/* 183 */       while ((len = inputStream.read(data)) != -1) {
/* 184 */         byteArrayOutputStream.write(data, 0, len);
/*     */       }
/* 186 */       resultString = byteArrayOutputStream.toString("UTF-8");
/* 187 */     } catch (IOException e) {
/* 188 */       resultString = e.getMessage();
/* 189 */       e.printStackTrace();
/*     */     } 
/* 191 */     return resultString;
/*     */   }
/*     */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\dylan\tools\HttpTool.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */