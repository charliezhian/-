/*     */ package dylan.tools;
/*     */ import dylan.model.Response;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import java.util.regex.Pattern;
/*     */ import javafx.scene.control.Alert;
/*     */ 
/*     */ public class Util {
/*  16 */   public static final String[] vulTab = new String[] { "tp_view_recent_xff_sqli", "tp_update_sql", "tp_pay_orderid_sqli", "tp_multi_sql_leak", "tp_checkcode_time_sqli", "tp_cache", "tp2_lite_code_exec", "tp5_templalte_driver_rce", "tp5_debug_index_ids_sqli", "tp5_method_filter_code_exec", "tp5_request_input_rce", "tp5_index_showid_rce", "tp5_index_construct_rce", "tp5_driver_display_rce", "tp5_construct_debug_rce", "tp5_construct_code_exec_4", "tp5_construct_code_exec_3", "tp5_construct_code_exec_2", "tp5_construct_code_exec_1", "tp5_invoke_func_code_exec_2", "tp5_invoke_func_code_exec_1", "tp6_session_file_write", "all" };
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String Github = "https://github.com/bewhale/thinkphp_gui_tools";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void alert(String title, String info) {
/*  26 */     Alert alert = new Alert(Alert.AlertType.NONE, info, new ButtonType[] { new ButtonType("确定", ButtonBar.ButtonData.YES) });
/*  27 */     alert.setTitle(title);
/*  28 */     alert.showAndWait();
/*  29 */     alert.close();
/*     */   }
/*     */   
/*     */   public static String isAlive(String url) {
/*  33 */     String results = null;
/*  34 */     HashMap<String, String> property = new HashMap<>();
/*  35 */     Response response = HttpTool.get(url, property);
/*  36 */     if (response.getError() != null) {
/*  37 */       results = response.getError();
/*     */     }
/*  39 */     return results;
/*     */   }
/*     */   
/*     */   public static List<String> readFile(String path) {
/*  43 */     List<String> lt = new ArrayList<>();
/*  44 */     File file = new File(path);
/*  45 */     Reader reader = null;
/*  46 */     BufferedReader bf = null;
/*  47 */     if (file.exists()) {
/*     */       try {
/*  49 */         reader = new InputStreamReader(new FileInputStream(file), "GBK");
/*  50 */         bf = new BufferedReader(reader);
/*  51 */         String line = null;
/*     */         
/*  53 */         while ((line = bf.readLine()) != null) {
/*  54 */           if (line.trim().length() > 0) {
/*  55 */             lt.add(line.trim());
/*     */           }
/*     */         } 
/*     */         
/*  59 */         bf.close();
/*  60 */         reader.close();
/*  61 */       } catch (IOException var6) {
/*  62 */         var6.printStackTrace();
/*     */       } 
/*     */     }
/*  65 */     return lt;
/*     */   }
/*     */   
/*     */   public static String[] reverse() {
/*  69 */     String[] b = new String[vulTab.length];
/*  70 */     System.arraycopy(vulTab, 0, b, 0, vulTab.length);
/*  71 */     for (int start = 0, end = b.length - 1; start < end; start++, end--) {
/*  72 */       String temp = b[start];
/*  73 */       b[start] = b[end];
/*  74 */       b[end] = temp;
/*     */     } 
/*  76 */     return b;
/*     */   }
/*     */   
/*     */   public static String getFDate() {
/*  80 */     String result = null;
/*  81 */     SimpleDateFormat sdf = new SimpleDateFormat("yyyy_MM_dd_hh_mm_ss");
/*  82 */     result = sdf.format(new Date());
/*  83 */     return result;
/*     */   }
/*     */   
/*     */   public static String writeResult(String path, String content, boolean flag) {
/*  87 */     File f = new File(path);
/*  88 */     FileWriter fw = null;
/*  89 */     String results = null;
/*     */     
/*     */     try {
/*  92 */       if (!f.exists()) {
/*  93 */         f.createNewFile();
/*     */       }
/*     */       
/*  96 */       fw = new FileWriter(f, flag);
/*  97 */       fw.write(content + "\r\n");
/*  98 */       fw.flush();
/*  99 */       fw.close();
/* 100 */       results = "保存成功, 当前目录下\n" + path;
/* 101 */     } catch (IOException e) {
/* 102 */       results = "保存失败： " + e.getMessage();
/*     */     } 
/* 104 */     return results;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getRandomString(int length) {
/* 113 */     String str = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
/* 114 */     Random random = new Random();
/* 115 */     StringBuilder sb = new StringBuilder();
/* 116 */     for (int i = 0; i < length; i++) {
/* 117 */       int number = random.nextInt(62);
/* 118 */       sb.append(str.charAt(number));
/*     */     } 
/* 120 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static String regReplace(String content) {
/* 126 */     String pattern = "<.*html.*>[\\s\\S]*</html>";
/* 127 */     String newString = "";
/* 128 */     Pattern p = Pattern.compile(pattern);
/* 129 */     Matcher m = p.matcher(content);
/* 130 */     String result = m.replaceAll(newString);
/* 131 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String urlParse(String url) {
/* 136 */     if (!url.contains("http")) {
/* 137 */       url = "http://" + url;
/*     */     }
/* 139 */     if (url.endsWith("/")) {
/* 140 */       url = url.substring(0, url.length() - 1);
/*     */     }
/* 142 */     return url;
/*     */   }
/*     */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\dylan\tools\Util.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */