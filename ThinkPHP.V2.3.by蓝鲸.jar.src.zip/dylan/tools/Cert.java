/*    */ package dylan.tools;
/*    */ 
/*    */ import java.security.cert.CertificateException;
/*    */ import java.security.cert.X509Certificate;
/*    */ import javax.net.ssl.X509TrustManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Cert
/*    */   implements X509TrustManager
/*    */ {
/*    */   public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {}
/*    */   
/*    */   public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {}
/*    */   
/*    */   public X509Certificate[] getAcceptedIssuers() {
/* 19 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\dylan\tools\Cert.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */