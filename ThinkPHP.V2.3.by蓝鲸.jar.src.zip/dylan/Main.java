/*    */ package dylan;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ import java.net.URL;
/*    */ import java.util.Objects;
/*    */ import javafx.application.Application;
/*    */ import javafx.fxml.FXMLLoader;
/*    */ import javafx.scene.Parent;
/*    */ import javafx.scene.Scene;
/*    */ import javafx.scene.image.Image;
/*    */ import javafx.stage.Stage;
/*    */ 
/*    */ public class Main
/*    */   extends Application {
/*    */   public void start(Stage primaryStage) throws Exception {
/* 16 */     Parent root = FXMLLoader.<Parent>load(Objects.<URL>requireNonNull(getClass().getResource("/main.fxml")));
/* 17 */     primaryStage.setTitle("ThinkPHP 综合利用工具 V2.3 by 蓝鲸");
/*    */     
/* 19 */     Scene scene = new Scene(root, 980.0D, 700.0D);
/* 20 */     primaryStage.setScene(scene);
/* 21 */     primaryStage.getIcons().add(new Image(Objects.<InputStream>requireNonNull(getClass().getResourceAsStream("/favicon.png"))));
/* 22 */     primaryStage.show();
/*    */   }
/*    */   
/*    */   public static void main(String[] args) {
/* 26 */     launch(args);
/*    */   }
/*    */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\dylan\Main.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */