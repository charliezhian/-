/*    */ package dylan.model;
/*    */ 
/*    */ public class Response
/*    */ {
/*    */   private int code;
/*    */   private String head;
/*    */   private String text;
/*    */   private String error;
/*    */   
/*    */   public Response() {}
/*    */   
/*    */   public Response(int code, String head, String text, String error) {
/* 13 */     this.code = code;
/* 14 */     this.head = head;
/* 15 */     this.text = text;
/* 16 */     this.error = error;
/*    */   }
/*    */   
/*    */   public int getCode() {
/* 20 */     return this.code;
/*    */   }
/*    */   
/*    */   public void setCode(int code) {
/* 24 */     this.code = code;
/*    */   }
/*    */   
/*    */   public String getHead() {
/* 28 */     return this.head;
/*    */   }
/*    */   
/*    */   public void setHead(String head) {
/* 32 */     this.head = head;
/*    */   }
/*    */   
/*    */   public String getText() {
/* 36 */     return this.text;
/*    */   }
/*    */   
/*    */   public void setText(String text) {
/* 40 */     this.text = text;
/*    */   }
/*    */   public String getError() {
/* 43 */     return this.error;
/*    */   }
/*    */   
/*    */   public void setError(String error) {
/* 47 */     this.error = error;
/*    */   }
/*    */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\dylan\model\Response.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */