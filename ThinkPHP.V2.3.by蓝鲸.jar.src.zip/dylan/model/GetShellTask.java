/*    */ package dylan.model;
/*    */ 
/*    */ import dylan.services.GetShell;
/*    */ import javafx.concurrent.Task;
/*    */ 
/*    */ public class GetShellTask extends Task<Void> {
/*    */   private final String target;
/*    */   private final int index;
/*    */   private final String shell;
/*    */   private final String shellName;
/*    */   
/*    */   public GetShellTask(String target, int index, String shell, String shellName) {
/* 13 */     this.target = target;
/* 14 */     this.index = index;
/* 15 */     this.shell = shell;
/* 16 */     this.shellName = shellName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Void call() throws Exception {
/* 33 */     String results = GetShell.getShell(this.target, this.index, this.shellName, this.shell);
/* 34 */     updateMessage(results);
/* 35 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\dylan\model\GetShellTask.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */