/*    */ package dylan.model;
/*    */ 
/*    */ import dylan.services.VulCheck;
/*    */ import javafx.beans.property.SimpleStringProperty;
/*    */ import javafx.concurrent.Task;
/*    */ 
/*    */ public class BatchVulCheckTask extends Task<Integer> {
/*    */   private int index;
/*    */   private int vulID;
/*    */   private String url;
/* 11 */   private final String cmd = null;
/* 12 */   private final SimpleStringProperty result = new SimpleStringProperty();
/*    */   
/*    */   protected Integer call() throws Exception {
/* 15 */     String checkResult = VulCheck.vulCheck(this.url, this.vulID);
/* 16 */     setResult(checkResult);
/* 17 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public BatchVulCheckTask(String url, int index) {
/* 22 */     this.index = index;
/* 23 */     this.url = url;
/*    */   }
/*    */   
/*    */   public BatchVulCheckTask(String url, int index, int vulID) {
/* 27 */     this.vulID = vulID;
/* 28 */     this.url = url;
/* 29 */     this.index = index;
/*    */   }
/*    */   
/*    */   public int getIndex() {
/* 33 */     return this.index;
/*    */   }
/*    */   
/*    */   public void setIndex(int index) {
/* 37 */     this.index = index;
/*    */   }
/*    */   
/*    */   public String getUrl() {
/* 41 */     return this.url;
/*    */   }
/*    */   
/*    */   public void setUrl(String url) {
/* 45 */     this.url = url;
/*    */   }
/*    */   
/*    */   public String getResult() {
/* 49 */     return this.result.get();
/*    */   }
/*    */   
/*    */   public SimpleStringProperty resultProperty() {
/* 53 */     return this.result;
/*    */   }
/*    */   
/*    */   public void setResult(String result) {
/* 57 */     this.result.set(result);
/*    */   }
/*    */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\dylan\model\BatchVulCheckTask.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */