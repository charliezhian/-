/*    */ package dylan.model;
/*    */ 
/*    */ import dylan.services.VulCheck;
/*    */ import javafx.concurrent.Task;
/*    */ 
/*    */ public class VulCheckTask extends Task<Void> {
/*    */   private final String target;
/*    */   private final int index;
/*    */   private String result;
/*    */   
/*    */   public VulCheckTask(String target, int index) {
/* 12 */     this.target = target;
/* 13 */     this.index = index;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Void call() {
/* 18 */     String result = VulCheck.vulCheck(this.target, this.index);
/* 19 */     updateMessage(result);
/* 20 */     setResult(result);
/* 21 */     return null;
/*    */   }
/*    */   
/*    */   public String getResult() {
/* 25 */     return this.result;
/*    */   }
/*    */   
/*    */   public void setResult(String result) {
/* 29 */     this.result = result;
/*    */   }
/*    */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\dylan\model\VulCheckTask.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */