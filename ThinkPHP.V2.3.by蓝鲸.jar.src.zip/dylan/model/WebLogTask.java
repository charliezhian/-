/*    */ package dylan.model;
/*    */ 
/*    */ import dylan.services.LogAnalysis;
/*    */ import javafx.concurrent.Task;
/*    */ 
/*    */ public class WebLogTask extends Task<Void> {
/*    */   private String result;
/*    */   private final String target;
/*    */   private final String path;
/*    */   private final String year;
/*    */   private final String mouth;
/*    */   private final String day;
/*    */   
/*    */   public WebLogTask(String target, String path, String year, String mouth, String day) {
/* 15 */     this.path = path;
/* 16 */     this.target = target;
/* 17 */     this.year = year;
/* 18 */     this.mouth = mouth;
/* 19 */     this.day = day;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Void call() {
/* 24 */     String result = LogAnalysis.logAnalysis(this.target, this.path, this.year, this.mouth, this.day);
/* 25 */     updateMessage(result);
/* 26 */     setResult(result);
/* 27 */     return null;
/*    */   }
/*    */   
/*    */   public String getResult() {
/* 31 */     return this.result;
/*    */   }
/*    */   
/*    */   public void setResult(String result) {
/* 35 */     this.result = result;
/*    */   }
/*    */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\dylan\model\WebLogTask.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */