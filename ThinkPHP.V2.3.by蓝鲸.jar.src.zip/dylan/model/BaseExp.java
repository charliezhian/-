package dylan.model;

public interface BaseExp {
  String vulCheck(String paramString);
  
  String cmdExec(String paramString1, String paramString2);
  
  String getShell(String paramString1, String paramString2, String paramString3);
}


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\dylan\model\BaseExp.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */