/*    */ package dylan.model;
/*    */ 
/*    */ import dylan.services.CmdExec;
/*    */ import javafx.concurrent.Task;
/*    */ 
/*    */ public class CmdExecTask extends Task<Void> {
/*    */   private final String cmd;
/*    */   private final String target;
/*    */   private final int index;
/*    */   
/*    */   public CmdExecTask(String target, String cmd, int index) {
/* 12 */     this.target = target;
/* 13 */     this.cmd = cmd;
/* 14 */     this.index = index;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Void call() throws Exception {
/* 31 */     String results = CmdExec.cmdExec(this.target, this.index, this.cmd);
/* 32 */     updateMessage(results);
/* 33 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\dylan\model\CmdExecTask.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */