/*     */ package dylan.services;public class VulCheck { public static String vulCheck(String target, int index) { tp6_session_file_write tp6sfw; tp5_invoke_func_code_exec_1 tp5ifce1; tp5_invoke_func_code_exec_2 tp5ifce2; tp5_construct_code_exec_1 tp5cce1; tp5_construct_code_exec_2 tp5cce2; tp5_construct_code_exec_3 tp5cce3; tp5_construct_code_exec_4 tp5cce4; tp5_construct_debug_rce tp5cdr; tp5_driver_display_rce tp5ddr; tp5_index_construct_rce tp5icr; tp5_index_showid_rce tp5isr; tp5_request_input_rce tp5rir; tp5_method_filter_code_exec tp5mfce; tp5_debug_index_ids_sqli tp5diis; tp5_templalte_driver_rce tptdr; tp2_lite_code_exec tp2lce;
/*     */     tp_cache tpc;
/*     */     tp_checkcode_time_sqli tpcts;
/*     */     tp_multi_sql_leak tpmsl;
/*     */     tp_pay_orderid_sqli tpos;
/*     */     tp_update_sql tpus;
/*     */     tp_view_recent_xff_sqli tpvrxs;
/*   8 */     index = Util.vulTab.length - 1 - index;
/*   9 */     String results = null;
/*  10 */     switch (index) {
/*     */       case 21:
/*  12 */         tp6sfw = new tp6_session_file_write();
/*  13 */         results = tp6sfw.vulCheck(target);
/*     */         break;
/*     */       case 20:
/*  16 */         tp5ifce1 = new tp5_invoke_func_code_exec_1();
/*  17 */         results = tp5ifce1.vulCheck(target);
/*     */         break;
/*     */       case 19:
/*  20 */         tp5ifce2 = new tp5_invoke_func_code_exec_2();
/*  21 */         results = tp5ifce2.vulCheck(target);
/*     */         break;
/*     */       case 18:
/*  24 */         tp5cce1 = new tp5_construct_code_exec_1();
/*  25 */         results = tp5cce1.vulCheck(target);
/*     */         break;
/*     */       case 17:
/*  28 */         tp5cce2 = new tp5_construct_code_exec_2();
/*  29 */         results = tp5cce2.vulCheck(target);
/*     */         break;
/*     */       case 16:
/*  32 */         tp5cce3 = new tp5_construct_code_exec_3();
/*  33 */         results = tp5cce3.vulCheck(target);
/*     */         break;
/*     */       case 15:
/*  36 */         tp5cce4 = new tp5_construct_code_exec_4();
/*  37 */         results = tp5cce4.vulCheck(target);
/*     */         break;
/*     */       case 14:
/*  40 */         tp5cdr = new tp5_construct_debug_rce();
/*  41 */         results = tp5cdr.vulCheck(target);
/*     */         break;
/*     */       case 13:
/*  44 */         tp5ddr = new tp5_driver_display_rce();
/*  45 */         results = tp5ddr.vulCheck(target);
/*     */         break;
/*     */       case 12:
/*  48 */         tp5icr = new tp5_index_construct_rce();
/*  49 */         results = tp5icr.vulCheck(target);
/*     */         break;
/*     */       case 11:
/*  52 */         tp5isr = new tp5_index_showid_rce();
/*  53 */         results = tp5isr.vulCheck(target);
/*     */         break;
/*     */       case 10:
/*  56 */         tp5rir = new tp5_request_input_rce();
/*  57 */         results = tp5rir.vulCheck(target);
/*     */         break;
/*     */       case 9:
/*  60 */         tp5mfce = new tp5_method_filter_code_exec();
/*  61 */         results = tp5mfce.vulCheck(target);
/*     */         break;
/*     */       case 8:
/*  64 */         tp5diis = new tp5_debug_index_ids_sqli();
/*  65 */         results = tp5diis.vulCheck(target);
/*     */         break;
/*     */       case 7:
/*  68 */         tptdr = new tp5_templalte_driver_rce();
/*  69 */         results = tptdr.vulCheck(target);
/*     */         break;
/*     */       case 6:
/*  72 */         tp2lce = new tp2_lite_code_exec();
/*  73 */         results = tp2lce.vulCheck(target);
/*     */         break;
/*     */       case 5:
/*  76 */         tpc = new tp_cache();
/*  77 */         results = tpc.vulCheck(target);
/*     */         break;
/*     */       case 4:
/*  80 */         tpcts = new tp_checkcode_time_sqli();
/*  81 */         results = tpcts.vulCheck(target);
/*     */         break;
/*     */       case 3:
/*  84 */         tpmsl = new tp_multi_sql_leak();
/*  85 */         results = tpmsl.vulCheck(target);
/*     */         break;
/*     */       case 2:
/*  88 */         tpos = new tp_pay_orderid_sqli();
/*  89 */         results = tpos.vulCheck(target);
/*     */         break;
/*     */       case 1:
/*  92 */         tpus = new tp_update_sql();
/*  93 */         results = tpus.vulCheck(target);
/*     */         break;
/*     */       case 0:
/*  96 */         tpvrxs = new tp_view_recent_xff_sqli();
/*  97 */         results = tpvrxs.vulCheck(target);
/*     */         break;
/*     */     } 
/* 100 */     return results; }
/*     */    }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\dylan\services\VulCheck.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */