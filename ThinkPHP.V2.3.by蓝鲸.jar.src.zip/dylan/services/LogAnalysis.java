/*    */ package dylan.services;
/*    */ 
/*    */ import dylan.exp.tp_log;
/*    */ 
/*    */ public class LogAnalysis
/*    */ {
/*    */   public static String logAnalysis(String target, String path, String year, String mouth, String day) {
/*  8 */     String results = null;
/*  9 */     tp_log tplog = new tp_log();
/* 10 */     results = tplog.vulCheck(target, path, year, mouth, day);
/* 11 */     return results;
/*    */   }
/*    */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\dylan\services\LogAnalysis.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */