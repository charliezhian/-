/*     */ package dylan.controller;
/*     */ 
/*     */ import dylan.model.BatchVulCheckTask;
/*     */ import dylan.model.CmdExecTask;
/*     */ import dylan.model.GetShellTask;
/*     */ import dylan.model.VulCheckTask;
/*     */ import dylan.model.WebLogTask;
/*     */ import dylan.tools.Config;
/*     */ import dylan.tools.Util;
/*     */ import java.awt.Desktop;
/*     */ import java.io.File;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URLEncoder;
/*     */ import java.time.LocalDate;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.Executors;
/*     */ import javafx.application.Platform;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.concurrent.Task;
/*     */ import javafx.concurrent.WorkerStateEvent;
/*     */ import javafx.event.ActionEvent;
/*     */ import javafx.fxml.FXML;
/*     */ import javafx.scene.control.Button;
/*     */ import javafx.scene.control.CheckBox;
/*     */ import javafx.scene.control.ChoiceBox;
/*     */ import javafx.scene.control.ComboBox;
/*     */ import javafx.scene.control.DatePicker;
/*     */ import javafx.scene.control.MenuItem;
/*     */ import javafx.scene.control.TableColumn;
/*     */ import javafx.scene.control.TableRow;
/*     */ import javafx.scene.control.TableView;
/*     */ import javafx.scene.control.TextArea;
/*     */ import javafx.scene.control.TextField;
/*     */ import javafx.scene.control.cell.PropertyValueFactory;
/*     */ import javafx.scene.input.Clipboard;
/*     */ import javafx.scene.input.ClipboardContent;
/*     */ import javafx.scene.input.MouseButton;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ import javafx.stage.FileChooser;
/*     */ import javafx.stage.Window;
/*     */ 
/*     */ 
/*     */ public class MainController
/*     */ {
/*     */   @FXML
/*     */   private MenuItem aboutMeMenu;
/*     */   @FXML
/*     */   private MenuItem openGithub;
/*     */   @FXML
/*     */   private MenuItem exitMenu;
/*     */   @FXML
/*     */   private TextField url;
/*     */   @FXML
/*     */   private ChoiceBox<?> poc;
/*     */   private int currentVulIndex;
/*     */   @FXML
/*     */   private Button verify;
/*     */   @FXML
/*     */   private Button logsClearBtn;
/*     */   @FXML
/*     */   private TextArea basicLog;
/*     */   @FXML
/*     */   private TextField cmd;
/*     */   @FXML
/*     */   private Button btnCmd;
/*     */   @FXML
/*     */   private Button cmdLogBtn;
/*     */   @FXML
/*     */   private TextArea cmdLog;
/*     */   @FXML
/*     */   private Button batch_clearBtn;
/*     */   private List<String> urlList;
/*     */   @FXML
/*     */   private Button batch_importBtn;
/*     */   @FXML
/*     */   private Button batch_saveBtn;
/*     */   @FXML
/*     */   private TextField batch_path;
/*     */   @FXML
/*     */   private Button batch_startBtn;
/*     */   private int batch_job_count;
/*     */   @FXML
/*     */   private TableColumn<?, ?> batch_tableColumnResult;
/*     */   @FXML
/*     */   private TableColumn<?, ?> batch_tableColumnUrl;
/*     */   @FXML
/*     */   private TableColumn<?, ?> batch_tableColumnIndex;
/*     */   @FXML
/*     */   private TableView<BatchVulCheckTask> batch_tableView;
/*     */   @FXML
/*     */   private Button batch_stopBtn;
/*     */   @FXML
/*     */   private TextArea webLogs;
/*     */   @FXML
/*     */   private Button webLogStartBtn;
/*     */   @FXML
/*     */   private Button webLogClearBtn;
/*     */   @FXML
/*     */   private ComboBox<String> logPath;
/*     */   @FXML
/*     */   private DatePicker startDate;
/*     */   @FXML
/*     */   private DatePicker endDate;
/*     */   @FXML
/*     */   private TextArea shellContent;
/*     */   @FXML
/*     */   private CheckBox isPoxyCheckBox;
/* 112 */   private Boolean isProxy = Boolean.valueOf(false);
/*     */   
/*     */   @FXML
/*     */   private ChoiceBox<?> proxyType;
/*     */   @FXML
/*     */   private TextField proxyIP;
/*     */   private String ip;
/*     */   @FXML
/*     */   private TextField proxyPort;
/*     */   private int port;
/*     */   @FXML
/*     */   private CheckBox isUACheckBox;
/* 124 */   private Boolean isUA = Boolean.valueOf(false);
/*     */   
/*     */   @FXML
/*     */   private TextField UATextFiled;
/*     */   
/*     */   private String UA;
/*     */   @FXML
/*     */   private Button configSaveBtn;
/*     */   private Config config;
/*     */   @FXML
/*     */   private TextField shellNameTextField;
/*     */   private String shellName;
/*     */   @FXML
/*     */   private Button getShellBtn;
/*     */   @FXML
/*     */   private Button shellLogClrBtn;
/*     */   @FXML
/*     */   private TextArea shellTextArea;
/*     */   private String shell;
/*     */   @FXML
/*     */   private TextArea shellLogTextArea;
/*     */   
/*     */   @FXML
/*     */   public void initialize() {
/* 148 */     this.config = Config.getInstance("config.properties");
/* 149 */     initComponents();
/* 150 */     initConfig();
/*     */   }
/*     */ 
/*     */   
/*     */   public void initConfig() {
/* 155 */     this.isProxy = Boolean.valueOf(this.config.getBooleanValue("isProxy"));
/* 156 */     this.isUA = Boolean.valueOf(this.config.getBooleanValue("isUA"));
/* 157 */     if (this.isProxy.booleanValue()) {
/* 158 */       this.proxyIP.setEditable(true);
/* 159 */       this.proxyPort.setEditable(true);
/* 160 */       this.isPoxyCheckBox.setSelected(true);
/*     */     } 
/*     */     
/* 163 */     if (this.isUA.booleanValue()) {
/* 164 */       this.isUACheckBox.setSelected(true);
/* 165 */       this.UATextFiled.setEditable(true);
/*     */     } 
/* 167 */     this.UATextFiled.setText((this.config.getStringValue("UA") != null) ? this.config.getStringValue("UA") : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36 Edg/91.0.864.59");
/* 168 */     this.proxyIP.setText(this.config.getStringValue("proxyIP"));
/* 169 */     this.proxyPort.setText(this.config.getStringValue("proxyPort"));
/* 170 */     this.isPoxyCheckBox.setOnAction(event -> {
/*     */           this.isProxy = Boolean.valueOf(false);
/*     */           
/*     */           this.proxyIP.setEditable(false);
/*     */           this.proxyPort.setEditable(false);
/*     */           if (this.isPoxyCheckBox.isSelected()) {
/*     */             this.isProxy = Boolean.valueOf(true);
/*     */             this.proxyIP.setEditable(true);
/*     */             this.proxyPort.setEditable(true);
/*     */           } 
/*     */         });
/* 181 */     this.isUACheckBox.setOnAction(event -> {
/*     */           this.isUA = Boolean.valueOf(false);
/*     */           
/*     */           this.UATextFiled.setEditable(false);
/*     */           if (this.isUACheckBox.isSelected()) {
/*     */             this.isUA = Boolean.valueOf(true);
/*     */             this.UATextFiled.setEditable(true);
/*     */           } 
/*     */         });
/* 190 */     this.configSaveBtn.setOnAction(event -> {
/*     */           try {
/*     */             if (this.isProxy.booleanValue()) {
/*     */               this.port = Integer.parseInt(this.proxyPort.getText());
/*     */               
/*     */               this.ip = this.proxyIP.getText();
/*     */               
/*     */               this.config.setProperty("proxyIP", this.ip);
/*     */               this.config.setProperty("proxyPort", Integer.valueOf(this.port));
/*     */             } 
/*     */             if (this.isUA.booleanValue()) {
/*     */               this.UA = this.UATextFiled.getText().trim();
/*     */               this.config.setProperty("UA", this.UA.replace(",", "\\,"));
/*     */             } 
/*     */             this.config.setProperty("isUA", this.isUA);
/*     */             this.config.setProperty("isProxy", this.isProxy);
/*     */             Util.alert("提示", "保存成功！");
/* 207 */           } catch (Exception var3) {
/*     */             Util.alert("警告", "保存失败，请检查填写是否正确!");
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public void initComponents() {
/* 215 */     this.aboutMeMenu.setOnAction(e -> Util.alert("关于作者", "蓝鲸\n\nGithub:https://github.com/bewhale/"));
/* 216 */     this.openGithub.setOnAction(e -> browse("https://github.com/bewhale/thinkphp_gui_tools"));
/*     */     
/* 218 */     this.exitMenu.setOnAction(e -> Platform.exit());
/* 219 */     this.basicLog.setText("\n\n\n\n\n\n* 支持大部分ThinkPHP漏洞检测\n* 支持部分漏洞执行命令\n* 支持单一漏洞批量检测\n* 支持TP3和TP5自定义路径日志遍历\n* 支持部分漏洞一键GetShell\n\n\n\n本工具仅供学习交流，严禁用于非法途径，严禁用于商业目的，如作他用所承受的法律责任一概与作者无关。\n(下载使用即代表你同意上述观点)");
/* 220 */     this.webLogClearBtn.setOnAction(event -> this.webLogs.setText(""));
/* 221 */     this.logPath.getItems().addAll(new String[] { "/runtime/log/", "/Runtime/Logs/", "/Runtime/Logs/Home/", "/Runtime/Logs/Admin/", "/App/Runtime/Logs/", "/Application/Runtime/Logs/", "/Application/Runtime/Logs/Home/", "/Application/Runtime/Logs/Common/", "/Application/Runtime/Logs/Admin/" });
/* 222 */     this.shellLogTextArea.setText("[+] 如需要自定义写入shell的路径，文件名处填写绝对路径即可(少数exp不支持)。\n[+] 默认shell使用蚁剑连接，密码为a，需要新建base64编码器。\n");
/* 223 */     String[] config_proxyTypes = { "HTTP" };
/* 224 */     ObservableList<?> proxyTypes = FXCollections.observableArrayList((Object[])config_proxyTypes);
/* 225 */     this.proxyType.setItems(proxyTypes);
/* 226 */     this.proxyType.getSelectionModel().selectFirst();
/* 227 */     this.logsClearBtn.setOnAction(e -> this.basicLog.setText(""));
/*     */ 
/*     */ 
/*     */     
/* 231 */     this.cmdLogBtn.setOnAction(e -> this.cmdLog.setText(""));
/*     */     
/* 233 */     this.url.setOnAction(this::btnVerify);
/* 234 */     this.cmd.setOnAction(this::cmdExec);
/* 235 */     this.getShellBtn.setOnAction(this::getShell);
/* 236 */     this.shellLogClrBtn.setOnAction(e -> this.shellLogTextArea.setText(""));
/*     */ 
/*     */ 
/*     */     
/* 240 */     this.batch_importBtn.setDisable(false);
/* 241 */     this.batch_startBtn.setDisable(true);
/* 242 */     this.batch_stopBtn.setDisable(true);
/* 243 */     this.batch_saveBtn.setDisable(true);
/* 244 */     this.batch_clearBtn.setDisable(true);
/* 245 */     ObservableList<?> pocs = FXCollections.observableArrayList((Object[])Util.reverse());
/* 246 */     this.poc.setItems(pocs);
/* 247 */     this.poc.getSelectionModel().selectFirst();
/* 248 */     this.currentVulIndex = 0;
/* 249 */     this.poc.getSelectionModel().selectedIndexProperty().addListener((observable, oldValue, newValue) -> this.currentVulIndex = newValue.intValue());
/*     */ 
/*     */ 
/*     */     
/* 253 */     this.batch_tableColumnIndex.setCellValueFactory(new PropertyValueFactory<>("index"));
/* 254 */     this.batch_tableColumnUrl.setCellValueFactory(new PropertyValueFactory<>("url"));
/* 255 */     this.batch_tableColumnResult.setCellValueFactory(new PropertyValueFactory<>("result"));
/* 256 */     this.batch_tableView.setRowFactory(param -> {
/*     */           TableRow<BatchVulCheckTask> row = new TableRow<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           row.setOnMouseClicked(());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           return row;
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 275 */     this.webLogStartBtn.setOnAction(event -> webLogStart());
/*     */   }
/*     */ 
/*     */   
/*     */   @FXML
/*     */   void btnVerify(ActionEvent event) {
/* 281 */     this.basicLog.setText("");
/* 282 */     String url = Util.urlParse(this.url.getText()).trim();
/* 283 */     if (url.equals("")) {
/* 284 */       Util.alert("提示", "请输入URL地址！");
/*     */     } else {
/* 286 */       String alive = Util.isAlive(url);
/* 287 */       if (alive == null) {
/* 288 */         int vulNum = this.poc.getItems().size();
/* 289 */         this.basicLog.appendText("[+] " + url + " 的检测结果如下：\n");
/* 290 */         this.basicLog.appendText("=====================================================================\n");
/* 291 */         if (this.currentVulIndex != 0) {
/* 292 */           VulCheckTask vulCheckTask = new VulCheckTask(Util.urlParse(this.url.getText()), this.currentVulIndex);
/* 293 */           vulCheckTask.messageProperty().addListener((observable, oldValue, newValue) -> this.basicLog.appendText(newValue + "\n"));
/*     */ 
/*     */           
/* 296 */           (new Thread((Runnable)vulCheckTask)).start();
/*     */         } else {
/* 298 */           for (int i = 1; i < vulNum; i++) {
/* 299 */             VulCheckTask vulCheckTask = new VulCheckTask(Util.urlParse(this.url.getText()), i);
/* 300 */             vulCheckTask.messageProperty().addListener((observable, oldValue, newValue) -> this.basicLog.appendText(newValue + "\n"));
/*     */ 
/*     */             
/* 303 */             (new Thread((Runnable)vulCheckTask)).start();
/*     */           } 
/*     */         } 
/*     */       } else {
/* 307 */         this.basicLog.appendText("[-] 访问" + url + " 失败, " + alive + "\n");
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @FXML
/*     */   void cmdExec(ActionEvent event) {
/* 315 */     if (this.poc.getValue().toString().equals("all")) {
/* 316 */       Util.alert("提示", "请先验证存在的RCE漏洞, \n再选择相应的POC执行命令！");
/*     */     } else {
/*     */       try {
/* 319 */         String cmd = URLEncoder.encode(this.cmd.getText(), "UTF-8");
/* 320 */         CmdExecTask cmdExecTask = new CmdExecTask(Util.urlParse(this.url.getText()), cmd, this.currentVulIndex);
/* 321 */         cmdExecTask.messageProperty().addListener((observable, oldValue, newValue) -> {
/*     */               this.cmdLog.appendText("============================================================\n");
/*     */               this.cmdLog.appendText(cmd + "\n");
/*     */               this.cmdLog.appendText(newValue + "\n");
/*     */             });
/* 326 */         (new Thread((Runnable)cmdExecTask)).start();
/* 327 */       } catch (Exception e) {
/* 328 */         this.cmdLog.appendText(e.getMessage() + "\n");
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @FXML
/*     */   void batchBtnimportAction(ActionEvent event) {
/* 336 */     String cwd = System.getProperty("user.dir");
/* 337 */     File file = new File(cwd);
/* 338 */     FileChooser chooser = new FileChooser();
/* 339 */     chooser.setInitialDirectory(file);
/* 340 */     chooser.setTitle("选择");
/* 341 */     chooser.getExtensionFilters().addAll(new FileChooser.ExtensionFilter[] { new FileChooser.ExtensionFilter("txt文本文件", new String[] { "*.txt" }) });
/* 342 */     File chosenDir = chooser.showOpenDialog((Window)null);
/* 343 */     if (chosenDir != null) {
/* 344 */       String filePath = chosenDir.getAbsolutePath();
/* 345 */       this.batch_path.setText(filePath);
/* 346 */       this.urlList = Util.readFile(filePath);
/* 347 */       ObservableList<BatchVulCheckTask> list = FXCollections.observableArrayList();
/* 348 */       if (this.urlList.size() > 0) {
/* 349 */         this.batch_startBtn.setDisable(false);
/* 350 */         this.batch_stopBtn.setDisable(true);
/* 351 */         this.batch_saveBtn.setDisable(true);
/* 352 */         this.batch_clearBtn.setDisable(true);
/*     */       } 
/*     */       
/* 355 */       for (int i = 0; i < this.urlList.size(); i++) {
/* 356 */         BatchVulCheckTask batchCheckTask = new BatchVulCheckTask(this.urlList.get(i), i + 1);
/* 357 */         list.add(batchCheckTask);
/*     */       } 
/* 359 */       this.batch_tableView.setItems(list);
/*     */     } 
/*     */   }
/*     */   
/*     */   @FXML
/*     */   void batchBtnStartAction(ActionEvent event) {
/* 365 */     if (this.currentVulIndex != 0) {
/* 366 */       this.batch_job_count = 0;
/* 367 */       int tableSize = this.batch_tableView.getItems().size();
/* 368 */       if (this.urlList.size() > 0) {
/* 369 */         this.batch_tableView.getItems().clear();
/* 370 */         this.batch_clearBtn.setDisable(true);
/* 371 */         this.batch_saveBtn.setDisable(true);
/* 372 */         this.batch_importBtn.setDisable(true);
/* 373 */         this.batch_startBtn.setDisable(true);
/* 374 */         this.batch_stopBtn.setDisable(false);
/* 375 */         Executor exec = Executors.newFixedThreadPool(10, r -> {
/*     */               Thread t = new Thread(r);
/*     */               t.setDaemon(true);
/*     */               return t;
/*     */             });
/* 380 */         for (int i = 0; i < this.urlList.size(); i++) {
/* 381 */           String url = this.urlList.get(i);
/* 382 */           BatchVulCheckTask batchVulCheckTask = new BatchVulCheckTask(url, i + 1, this.currentVulIndex);
/* 383 */           exec.execute((Runnable)batchVulCheckTask);
/* 384 */           this.batch_tableView.getItems().addAll(new BatchVulCheckTask[] { batchVulCheckTask });
/* 385 */           batchVulCheckTask.setOnSucceeded(event1 -> {
/*     */                 this.batch_job_count++;
/*     */                 if (this.batch_job_count == this.urlList.size()) {
/*     */                   jobDone(true);
/*     */                 }
/*     */               });
/* 391 */           batchVulCheckTask.setOnCancelled(event12 -> {
/*     */                 this.batch_job_count++;
/*     */                 if (this.batch_job_count == this.urlList.size()) {
/*     */                   jobDone(true);
/*     */                 }
/*     */               });
/* 397 */           batchVulCheckTask.setOnFailed(event13 -> {
/*     */                 this.batch_job_count++;
/*     */                 if (this.batch_job_count == this.urlList.size()) {
/*     */                   jobDone(true);
/*     */                 }
/*     */               });
/*     */         } 
/*     */       } 
/*     */     } else {
/* 406 */       jobDone(false);
/*     */     } 
/*     */   }
/*     */   
/*     */   @FXML
/*     */   void batchBtnStopAction(ActionEvent event) {
/* 412 */     this.batch_clearBtn.setDisable(false);
/* 413 */     this.batch_saveBtn.setDisable(false);
/* 414 */     this.batch_importBtn.setDisable(false);
/* 415 */     this.batch_startBtn.setDisable(false);
/* 416 */     this.batch_stopBtn.setDisable(true);
/* 417 */     this.batch_tableView.getItems().forEach(Task::cancel);
/*     */   }
/*     */   
/*     */   @FXML
/*     */   void batchBtnSaveAction(ActionEvent event) {
/* 422 */     String results = null;
/* 423 */     if (this.batch_tableView.getItems().size() == 0) {
/* 424 */       Util.alert("提示", "没有可以保存的数据");
/*     */     }
/*     */     
/* 427 */     String batch_filePath = this.batch_path.getText().trim();
/* 428 */     StringBuilder saveNameSB = new StringBuilder();
/* 429 */     if (!batch_filePath.equals("")) {
/* 430 */       File f = new File(batch_filePath);
/* 431 */       saveNameSB.append(f.getName(), 0, f.getName().lastIndexOf("."));
/*     */     } 
/*     */     
/* 434 */     saveNameSB.append("_");
/* 435 */     saveNameSB.append(Util.getFDate());
/* 436 */     saveNameSB.append(".txt");
/* 437 */     String path = saveNameSB.toString();
/* 438 */     StringBuilder sb = new StringBuilder();
/*     */     
/* 440 */     for (int i = 0; i < this.batch_tableView.getItems().size(); i++) {
/* 441 */       BatchVulCheckTask batchCheckTask = this.batch_tableView.getItems().get(i);
/* 442 */       sb.append(batchCheckTask.getIndex());
/* 443 */       sb.append("\t\t");
/* 444 */       sb.append(batchCheckTask.getUrl());
/* 445 */       sb.append("\t\t");
/* 446 */       if (batchCheckTask.getResult() == null) {
/* 447 */         sb.append("暂未检测");
/*     */       } else {
/* 449 */         sb.append(batchCheckTask.getResult());
/*     */       } 
/* 451 */       sb.append("\r\n");
/*     */     } 
/*     */     
/* 454 */     results = Util.writeResult(path, sb.toString(), true);
/* 455 */     Util.alert("提示", results);
/*     */   }
/*     */   
/*     */   @FXML
/*     */   void batchBtnClearAction(ActionEvent event) {
/* 460 */     this.batch_tableView.getItems().clear();
/* 461 */     this.batch_clearBtn.setDisable(false);
/* 462 */     this.batch_saveBtn.setDisable(true);
/* 463 */     this.batch_importBtn.setDisable(false);
/* 464 */     this.batch_startBtn.setDisable(false);
/* 465 */     this.batch_stopBtn.setDisable(true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void webLogStart() {
/* 471 */     if (this.startDate.getValue() == null || this.endDate.getValue() == null || this.logPath.getValue() == null || ((String)this.logPath.getValue()).equals("")) {
/* 472 */       Util.alert("提示", "请输入路径和需要遍历的日期区间！");
/*     */     } else {
/* 474 */       this.webLogs.appendText("开始遍历日志：\n");
/* 475 */       for (LocalDate currentdate = this.startDate.getValue(); currentdate.isBefore(this.endDate.getValue()) || currentdate.equals(this.endDate.getValue()); currentdate = currentdate.plusDays(1L)) {
/* 476 */         WebLogTask webLogTask = new WebLogTask(Util.urlParse(this.url.getText()), this.logPath.getValue(), String.valueOf(currentdate.getYear()), String.valueOf(currentdate.getMonth().getValue()), String.valueOf(currentdate.getDayOfMonth()));
/* 477 */         webLogTask.messageProperty().addListener((observable, oldValue, newValue) -> this.webLogs.appendText(newValue + "\n"));
/*     */ 
/*     */         
/* 480 */         (new Thread((Runnable)webLogTask)).start();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   @FXML
/*     */   void getShell(ActionEvent event) {
/* 487 */     if (this.poc.getValue().toString().equals("all")) {
/* 488 */       Util.alert("提示", "请先验证存在的RCE漏洞, \n再选择相应的POC getshell！");
/*     */     } else {
/*     */       try {
/* 491 */         this.shellLogTextArea.appendText("============================================================\n");
/* 492 */         this.shellLogTextArea.appendText("[+] 开始尝试进行 GetShell...\n");
/* 493 */         this.shellName = this.shellNameTextField.getText().trim();
/* 494 */         this.shell = this.shellTextArea.getText().trim();
/* 495 */         GetShellTask getShellTask = new GetShellTask(Util.urlParse(this.url.getText()), this.currentVulIndex, this.shellName, this.shell);
/* 496 */         getShellTask.messageProperty().addListener((observable, oldValue, newValue) -> this.shellLogTextArea.appendText(newValue + "\n"));
/*     */ 
/*     */         
/* 499 */         (new Thread((Runnable)getShellTask)).start();
/* 500 */       } catch (Exception e) {
/* 501 */         this.cmdLog.appendText(e.getMessage() + "\n");
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void jobDone(boolean flag) {
/* 507 */     if (flag) {
/* 508 */       Util.alert("提示", "检测完成！");
/*     */     } else {
/* 510 */       Util.alert("提示", "暂时只支持单一漏洞批量检测！");
/* 511 */     }  this.batch_clearBtn.setDisable(false);
/* 512 */     this.batch_saveBtn.setDisable(false);
/* 513 */     this.batch_importBtn.setDisable(false);
/* 514 */     this.batch_startBtn.setDisable(false);
/* 515 */     this.batch_stopBtn.setDisable(true);
/* 516 */     if (this.batch_tableView.getItems().size() == 0) {
/* 517 */       this.batch_saveBtn.setDisable(true);
/*     */     }
/*     */   }
/*     */   
/*     */   protected static void browse(String url) {
/*     */     try {
/* 523 */       Desktop desktop = Desktop.getDesktop();
/* 524 */       if (Desktop.isDesktopSupported() && desktop.isSupported(Desktop.Action.BROWSE)) {
/* 525 */         URI uri = new URI(url);
/* 526 */         desktop.browse(uri);
/*     */       } 
/* 528 */     } catch (URISyntaxException|java.io.IOException e) {
/* 529 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\dylan\controller\MainController.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */