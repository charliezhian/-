/*    */ package io.reactivex.disposables;
/*    */ 
/*    */ import io.reactivex.annotations.NonNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class RunnableDisposable
/*    */   extends ReferenceDisposable<Runnable>
/*    */ {
/*    */   private static final long serialVersionUID = -8219729196779211169L;
/*    */   
/*    */   RunnableDisposable(Runnable value) {
/* 25 */     super(value);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void onDisposed(@NonNull Runnable value) {
/* 30 */     value.run();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 35 */     return "RunnableDisposable(disposed=" + isDisposed() + ", " + get() + ")";
/*    */   }
/*    */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\io\reactivex\disposables\RunnableDisposable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */