/*    */ package io.reactivex.disposables;
/*    */ 
/*    */ import io.reactivex.annotations.NonNull;
/*    */ import io.reactivex.functions.Action;
/*    */ import io.reactivex.internal.util.ExceptionHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ActionDisposable
/*    */   extends ReferenceDisposable<Action>
/*    */ {
/*    */   private static final long serialVersionUID = -8219729196779211169L;
/*    */   
/*    */   ActionDisposable(Action value) {
/* 24 */     super(value);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void onDisposed(@NonNull Action value) {
/*    */     try {
/* 30 */       value.run();
/* 31 */     } catch (Throwable ex) {
/* 32 */       throw ExceptionHelper.wrapOrThrow(ex);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\io\reactivex\disposables\ActionDisposable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */