/*    */ package io.reactivex.flowables;
/*    */ 
/*    */ import io.reactivex.Flowable;
/*    */ import io.reactivex.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class GroupedFlowable<K, T>
/*    */   extends Flowable<T>
/*    */ {
/*    */   final K key;
/*    */   
/*    */   protected GroupedFlowable(@Nullable K key) {
/* 42 */     this.key = key;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public K getKey() {
/* 52 */     return this.key;
/*    */   }
/*    */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\io\reactivex\flowables\GroupedFlowable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */