/*    */ package io.reactivex.annotations;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum BackpressureKind
/*    */ {
/* 24 */   PASS_THROUGH,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 29 */   FULL,
/*    */ 
/*    */ 
/*    */   
/* 33 */   SPECIAL,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 38 */   UNBOUNDED_IN,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 43 */   ERROR,
/*    */ 
/*    */ 
/*    */   
/* 47 */   NONE;
/*    */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\io\reactivex\annotations\BackpressureKind.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */