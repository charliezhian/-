package io.reactivex.functions;

public interface Consumer<T> {
  void accept(T paramT) throws Exception;
}


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\io\reactivex\functions\Consumer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */