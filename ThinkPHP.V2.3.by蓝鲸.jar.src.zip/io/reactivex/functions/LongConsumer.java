package io.reactivex.functions;

public interface LongConsumer {
  void accept(long paramLong) throws Exception;
}


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\io\reactivex\functions\LongConsumer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */