package io.reactivex.functions;

import io.reactivex.annotations.NonNull;

public interface Function<T, R> {
  R apply(@NonNull T paramT) throws Exception;
}


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\io\reactivex\functions\Function.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */