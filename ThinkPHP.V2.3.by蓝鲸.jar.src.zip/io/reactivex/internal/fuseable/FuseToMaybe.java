package io.reactivex.internal.fuseable;

import io.reactivex.Maybe;

public interface FuseToMaybe<T> {
  Maybe<T> fuseToMaybe();
}


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\io\reactivex\internal\fuseable\FuseToMaybe.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */