package io.reactivex.internal.fuseable;

public interface QueueFuseable<T> extends SimpleQueue<T> {
  public static final int NONE = 0;
  
  public static final int SYNC = 1;
  
  public static final int ASYNC = 2;
  
  public static final int ANY = 3;
  
  public static final int BOUNDARY = 4;
  
  int requestFusion(int paramInt);
}


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\io\reactivex\internal\fuseable\QueueFuseable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */