package io.reactivex.internal.fuseable;

import io.reactivex.annotations.NonNull;
import io.reactivex.annotations.Nullable;

public interface SimpleQueue<T> {
  boolean offer(@NonNull T paramT);
  
  boolean offer(@NonNull T paramT1, @NonNull T paramT2);
  
  @Nullable
  T poll() throws Exception;
  
  boolean isEmpty();
  
  void clear();
}


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\io\reactivex\internal\fuseable\SimpleQueue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */