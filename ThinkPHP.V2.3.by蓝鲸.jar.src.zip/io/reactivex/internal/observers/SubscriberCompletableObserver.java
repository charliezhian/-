/*    */ package io.reactivex.internal.observers;
/*    */ 
/*    */ import io.reactivex.CompletableObserver;
/*    */ import io.reactivex.disposables.Disposable;
/*    */ import io.reactivex.internal.disposables.DisposableHelper;
/*    */ import org.reactivestreams.Subscriber;
/*    */ import org.reactivestreams.Subscription;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SubscriberCompletableObserver<T>
/*    */   implements CompletableObserver, Subscription
/*    */ {
/*    */   final Subscriber<? super T> subscriber;
/*    */   Disposable upstream;
/*    */   
/*    */   public SubscriberCompletableObserver(Subscriber<? super T> subscriber) {
/* 28 */     this.subscriber = subscriber;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onComplete() {
/* 33 */     this.subscriber.onComplete();
/*    */   }
/*    */ 
/*    */   
/*    */   public void onError(Throwable e) {
/* 38 */     this.subscriber.onError(e);
/*    */   }
/*    */ 
/*    */   
/*    */   public void onSubscribe(Disposable d) {
/* 43 */     if (DisposableHelper.validate(this.upstream, d)) {
/* 44 */       this.upstream = d;
/*    */       
/* 46 */       this.subscriber.onSubscribe(this);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void request(long n) {}
/*    */ 
/*    */ 
/*    */   
/*    */   public void cancel() {
/* 57 */     this.upstream.dispose();
/*    */   }
/*    */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\io\reactivex\internal\observers\SubscriberCompletableObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */