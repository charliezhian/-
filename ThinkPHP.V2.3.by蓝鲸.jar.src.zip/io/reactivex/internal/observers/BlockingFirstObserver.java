/*    */ package io.reactivex.internal.observers;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BlockingFirstObserver<T>
/*    */   extends BlockingBaseObserver<T>
/*    */ {
/*    */   public void onNext(T t) {
/* 25 */     if (this.value == null) {
/* 26 */       this.value = t;
/* 27 */       this.upstream.dispose();
/* 28 */       countDown();
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void onError(Throwable t) {
/* 34 */     if (this.value == null) {
/* 35 */       this.error = t;
/*    */     }
/* 37 */     countDown();
/*    */   }
/*    */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\io\reactivex\internal\observers\BlockingFirstObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */