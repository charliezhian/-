package io.reactivex.internal.observers;

public interface InnerQueuedObserverSupport<T> {
  void innerNext(InnerQueuedObserver<T> paramInnerQueuedObserver, T paramT);
  
  void innerError(InnerQueuedObserver<T> paramInnerQueuedObserver, Throwable paramThrowable);
  
  void innerComplete(InnerQueuedObserver<T> paramInnerQueuedObserver);
  
  void drain();
}


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\io\reactivex\internal\observers\InnerQueuedObserverSupport.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */