/*    */ package io.reactivex.internal.observers;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BlockingLastObserver<T>
/*    */   extends BlockingBaseObserver<T>
/*    */ {
/*    */   public void onNext(T t) {
/* 25 */     this.value = t;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onError(Throwable t) {
/* 30 */     this.value = null;
/* 31 */     this.error = t;
/* 32 */     countDown();
/*    */   }
/*    */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\io\reactivex\internal\observers\BlockingLastObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */