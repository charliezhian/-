package io.reactivex.internal.disposables;

import io.reactivex.annotations.Experimental;
import io.reactivex.disposables.Disposable;

@Experimental
public interface ResettableConnectable {
  void resetIf(Disposable paramDisposable);
}


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\io\reactivex\internal\disposables\ResettableConnectable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */