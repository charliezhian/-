/*    */ package io.reactivex.exceptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class UndeliverableException
/*    */   extends IllegalStateException
/*    */ {
/*    */   private static final long serialVersionUID = 1644750035281290266L;
/*    */   
/*    */   public UndeliverableException(Throwable cause) {
/* 31 */     super("The exception could not be delivered to the consumer because it has already canceled/disposed the flow or the exception has nowhere to go to begin with. Further reading: https://github.com/ReactiveX/RxJava/wiki/What's-different-in-2.0#error-handling | " + cause, cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\io\reactivex\exceptions\UndeliverableException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */