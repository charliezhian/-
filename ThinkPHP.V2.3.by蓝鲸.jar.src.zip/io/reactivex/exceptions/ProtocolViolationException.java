/*    */ package io.reactivex.exceptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ProtocolViolationException
/*    */   extends IllegalStateException
/*    */ {
/*    */   private static final long serialVersionUID = 1644750035281290266L;
/*    */   
/*    */   public ProtocolViolationException(String message) {
/* 31 */     super(message);
/*    */   }
/*    */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\io\reactivex\exceptions\ProtocolViolationException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */