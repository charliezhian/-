package com.sun.jna;

public interface AltCallingConvention {}


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\com\sun\jna\AltCallingConvention.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */