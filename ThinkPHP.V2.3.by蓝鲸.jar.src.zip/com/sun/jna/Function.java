/*     */ package com.sun.jna;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Function
/*     */   extends Pointer
/*     */ {
/*     */   public static final int MAX_NARGS = 256;
/*     */   public static final int C_CONVENTION = 0;
/*     */   public static final int ALT_CONVENTION = 63;
/*     */   private static final int MASK_CC = 63;
/*     */   public static final int THROW_LAST_ERROR = 64;
/*     */   public static final int USE_VARARGS = 384;
/*  82 */   static final Integer INTEGER_TRUE = Integer.valueOf(-1);
/*  83 */   static final Integer INTEGER_FALSE = Integer.valueOf(0);
/*     */ 
/*     */   
/*     */   private NativeLibrary library;
/*     */ 
/*     */   
/*     */   private final String functionName;
/*     */   
/*     */   final String encoding;
/*     */   
/*     */   final int callFlags;
/*     */   
/*     */   final Map<String, ?> options;
/*     */   
/*     */   static final String OPTION_INVOKING_METHOD = "invoking-method";
/*     */ 
/*     */   
/*     */   public static Function getFunction(String libraryName, String functionName) {
/* 101 */     return NativeLibrary.getInstance(libraryName).getFunction(functionName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Function getFunction(String libraryName, String functionName, int callFlags) {
/* 122 */     return NativeLibrary.getInstance(libraryName).getFunction(functionName, callFlags, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Function getFunction(String libraryName, String functionName, int callFlags, String encoding) {
/* 146 */     return NativeLibrary.getInstance(libraryName).getFunction(functionName, callFlags, encoding);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Function getFunction(Pointer p) {
/* 161 */     return getFunction(p, 0, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Function getFunction(Pointer p, int callFlags) {
/* 179 */     return getFunction(p, callFlags, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Function getFunction(Pointer p, int callFlags, String encoding) {
/* 200 */     return new Function(p, callFlags, encoding);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 215 */   private static final VarArgsChecker IS_VARARGS = VarArgsChecker.create();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Function(NativeLibrary library, String functionName, int callFlags, String encoding) {
/* 237 */     checkCallingConvention(callFlags & 0x3F);
/* 238 */     if (functionName == null) {
/* 239 */       throw new NullPointerException("Function name must not be null");
/*     */     }
/* 241 */     this.library = library;
/* 242 */     this.functionName = functionName;
/* 243 */     this.callFlags = callFlags;
/* 244 */     this.options = library.options;
/* 245 */     this.encoding = (encoding != null) ? encoding : Native.getDefaultStringEncoding();
/*     */     try {
/* 247 */       this.peer = library.getSymbolAddress(functionName);
/* 248 */     } catch (UnsatisfiedLinkError e) {
/* 249 */       throw new UnsatisfiedLinkError("Error looking up function '" + functionName + "': " + e
/*     */           
/* 251 */           .getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Function(Pointer functionAddress, int callFlags, String encoding) {
/* 271 */     checkCallingConvention(callFlags & 0x3F);
/* 272 */     if (functionAddress == null || functionAddress.peer == 0L)
/*     */     {
/* 274 */       throw new NullPointerException("Function address may not be null");
/*     */     }
/* 276 */     this.functionName = functionAddress.toString();
/* 277 */     this.callFlags = callFlags;
/* 278 */     this.peer = functionAddress.peer;
/* 279 */     this.options = Collections.EMPTY_MAP;
/* 280 */     this
/* 281 */       .encoding = (encoding != null) ? encoding : Native.getDefaultStringEncoding();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkCallingConvention(int convention) throws IllegalArgumentException {
/* 287 */     if ((convention & 0x3F) != convention) {
/* 288 */       throw new IllegalArgumentException("Unrecognized calling convention: " + convention);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/* 294 */     return this.functionName;
/*     */   }
/*     */   
/*     */   public int getCallingConvention() {
/* 298 */     return this.callFlags & 0x3F;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object invoke(Class<?> returnType, Object[] inArgs) {
/* 305 */     return invoke(returnType, inArgs, this.options);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object invoke(Class<?> returnType, Object[] inArgs, Map<String, ?> options) {
/* 312 */     Method invokingMethod = (Method)options.get("invoking-method");
/* 313 */     Class<?>[] paramTypes = (invokingMethod != null) ? invokingMethod.getParameterTypes() : null;
/* 314 */     return invoke(invokingMethod, paramTypes, returnType, inArgs, options);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object invoke(Method invokingMethod, Class<?>[] paramTypes, Class<?> returnType, Object[] inArgs, Map<String, ?> options) {
/* 325 */     Object[] args = new Object[0];
/* 326 */     if (inArgs != null) {
/* 327 */       if (inArgs.length > 256) {
/* 328 */         throw new UnsupportedOperationException("Maximum argument count is 256");
/*     */       }
/* 330 */       args = new Object[inArgs.length];
/* 331 */       System.arraycopy(inArgs, 0, args, 0, args.length);
/*     */     } 
/*     */     
/* 334 */     TypeMapper mapper = (TypeMapper)options.get("type-mapper");
/* 335 */     boolean allowObjects = Boolean.TRUE.equals(options.get("allow-objects"));
/* 336 */     boolean isVarArgs = (args.length > 0 && invokingMethod != null) ? isVarArgs(invokingMethod) : false;
/* 337 */     int fixedArgs = (args.length > 0 && invokingMethod != null) ? fixedArgs(invokingMethod) : 0;
/* 338 */     for (int i = 0; i < args.length; i++) {
/*     */ 
/*     */       
/* 341 */       Class<?> paramType = (invokingMethod != null) ? ((isVarArgs && i >= paramTypes.length - 1) ? paramTypes[paramTypes.length - 1].getComponentType() : paramTypes[i]) : null;
/*     */ 
/*     */       
/* 344 */       args[i] = convertArgument(args, i, invokingMethod, mapper, allowObjects, paramType);
/*     */     } 
/*     */     
/* 347 */     Class<?> nativeReturnType = returnType;
/* 348 */     FromNativeConverter resultConverter = null;
/* 349 */     if (NativeMapped.class.isAssignableFrom(returnType)) {
/* 350 */       NativeMappedConverter tc = NativeMappedConverter.getInstance(returnType);
/* 351 */       resultConverter = tc;
/* 352 */       nativeReturnType = tc.nativeType();
/* 353 */     } else if (mapper != null) {
/* 354 */       resultConverter = mapper.getFromNativeConverter(returnType);
/* 355 */       if (resultConverter != null) {
/* 356 */         nativeReturnType = resultConverter.nativeType();
/*     */       }
/*     */     } 
/*     */     
/* 360 */     Object result = invoke(args, nativeReturnType, allowObjects, fixedArgs);
/*     */     
/* 362 */     if (resultConverter != null) {
/*     */       FromNativeContext context;
/* 364 */       if (invokingMethod != null) {
/* 365 */         context = new MethodResultContext(returnType, this, inArgs, invokingMethod);
/*     */       } else {
/* 367 */         context = new FunctionResultContext(returnType, this, inArgs);
/*     */       } 
/* 369 */       result = resultConverter.fromNative(result, context);
/*     */     } 
/*     */ 
/*     */     
/* 373 */     if (inArgs != null) {
/* 374 */       for (int j = 0; j < inArgs.length; j++) {
/* 375 */         Object inArg = inArgs[j];
/* 376 */         if (inArg != null)
/*     */         {
/* 378 */           if (inArg instanceof Structure) {
/* 379 */             if (!(inArg instanceof Structure.ByValue)) {
/* 380 */               ((Structure)inArg).autoRead();
/*     */             }
/* 382 */           } else if (args[j] instanceof PostCallRead) {
/* 383 */             ((PostCallRead)args[j]).read();
/* 384 */             if (args[j] instanceof PointerArray) {
/* 385 */               PointerArray array = (PointerArray)args[j];
/* 386 */               if (Structure.ByReference[].class.isAssignableFrom(inArg.getClass())) {
/* 387 */                 Class<? extends Structure> type = (Class)inArg.getClass().getComponentType();
/* 388 */                 Structure[] ss = (Structure[])inArg;
/* 389 */                 for (int si = 0; si < ss.length; si++) {
/* 390 */                   Pointer p = array.getPointer((Native.POINTER_SIZE * si));
/* 391 */                   ss[si] = Structure.updateStructureByReference((Class)type, ss[si], p);
/*     */                 } 
/*     */               } 
/*     */             } 
/* 395 */           } else if (Structure[].class.isAssignableFrom(inArg.getClass())) {
/* 396 */             Structure.autoRead((Structure[])inArg);
/*     */           } 
/*     */         }
/*     */       } 
/*     */     }
/* 401 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   Object invoke(Object[] args, Class<?> returnType, boolean allowObjects) {
/* 406 */     return invoke(args, returnType, allowObjects, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   Object invoke(Object[] args, Class<?> returnType, boolean allowObjects, int fixedArgs) {
/* 411 */     Object result = null;
/* 412 */     int callFlags = this.callFlags | (fixedArgs & 0x3) << 7;
/* 413 */     if (returnType == null || returnType == void.class || returnType == Void.class) {
/* 414 */       Native.invokeVoid(this, this.peer, callFlags, args);
/* 415 */       result = null;
/* 416 */     } else if (returnType == boolean.class || returnType == Boolean.class) {
/* 417 */       result = valueOf((Native.invokeInt(this, this.peer, callFlags, args) != 0));
/* 418 */     } else if (returnType == byte.class || returnType == Byte.class) {
/* 419 */       result = Byte.valueOf((byte)Native.invokeInt(this, this.peer, callFlags, args));
/* 420 */     } else if (returnType == short.class || returnType == Short.class) {
/* 421 */       result = Short.valueOf((short)Native.invokeInt(this, this.peer, callFlags, args));
/* 422 */     } else if (returnType == char.class || returnType == Character.class) {
/* 423 */       result = Character.valueOf((char)Native.invokeInt(this, this.peer, callFlags, args));
/* 424 */     } else if (returnType == int.class || returnType == Integer.class) {
/* 425 */       result = Integer.valueOf(Native.invokeInt(this, this.peer, callFlags, args));
/* 426 */     } else if (returnType == long.class || returnType == Long.class) {
/* 427 */       result = Long.valueOf(Native.invokeLong(this, this.peer, callFlags, args));
/* 428 */     } else if (returnType == float.class || returnType == Float.class) {
/* 429 */       result = Float.valueOf(Native.invokeFloat(this, this.peer, callFlags, args));
/* 430 */     } else if (returnType == double.class || returnType == Double.class) {
/* 431 */       result = Double.valueOf(Native.invokeDouble(this, this.peer, callFlags, args));
/* 432 */     } else if (returnType == String.class) {
/* 433 */       result = invokeString(callFlags, args, false);
/* 434 */     } else if (returnType == WString.class) {
/* 435 */       String s = invokeString(callFlags, args, true);
/* 436 */       if (s != null)
/* 437 */         result = new WString(s); 
/*     */     } else {
/* 439 */       if (Pointer.class.isAssignableFrom(returnType))
/* 440 */         return invokePointer(callFlags, args); 
/* 441 */       if (Structure.class.isAssignableFrom(returnType)) {
/* 442 */         if (Structure.ByValue.class.isAssignableFrom(returnType)) {
/*     */           
/* 444 */           Structure s = Native.invokeStructure(this, this.peer, callFlags, args, 
/* 445 */               (Structure)Structure.newInstance(returnType));
/* 446 */           s.autoRead();
/* 447 */           result = s;
/*     */         } else {
/* 449 */           result = invokePointer(callFlags, args);
/* 450 */           if (result != null) {
/* 451 */             Structure s = (Structure)Structure.newInstance(returnType, (Pointer)result);
/* 452 */             s.conditionalAutoRead();
/* 453 */             result = s;
/*     */           } 
/*     */         } 
/* 456 */       } else if (Callback.class.isAssignableFrom(returnType)) {
/* 457 */         result = invokePointer(callFlags, args);
/* 458 */         if (result != null) {
/* 459 */           result = CallbackReference.getCallback(returnType, (Pointer)result);
/*     */         }
/* 461 */       } else if (returnType == String[].class) {
/* 462 */         Pointer p = invokePointer(callFlags, args);
/* 463 */         if (p != null) {
/* 464 */           result = p.getStringArray(0L, this.encoding);
/*     */         }
/* 466 */       } else if (returnType == WString[].class) {
/* 467 */         Pointer p = invokePointer(callFlags, args);
/* 468 */         if (p != null) {
/* 469 */           String[] arr = p.getWideStringArray(0L);
/* 470 */           WString[] warr = new WString[arr.length];
/* 471 */           for (int i = 0; i < arr.length; i++) {
/* 472 */             warr[i] = new WString(arr[i]);
/*     */           }
/* 474 */           result = warr;
/*     */         } 
/* 476 */       } else if (returnType == Pointer[].class) {
/* 477 */         Pointer p = invokePointer(callFlags, args);
/* 478 */         if (p != null) {
/* 479 */           result = p.getPointerArray(0L);
/*     */         }
/* 481 */       } else if (allowObjects) {
/* 482 */         result = Native.invokeObject(this, this.peer, callFlags, args);
/* 483 */         if (result != null && 
/* 484 */           !returnType.isAssignableFrom(result.getClass())) {
/* 485 */           throw new ClassCastException("Return type " + returnType + " does not match result " + result
/*     */               
/* 487 */               .getClass());
/*     */         }
/*     */       } else {
/* 490 */         throw new IllegalArgumentException("Unsupported return type " + returnType + " in function " + getName());
/*     */       } 
/* 492 */     }  return result;
/*     */   }
/*     */   
/*     */   private Pointer invokePointer(int callFlags, Object[] args) {
/* 496 */     long ptr = Native.invokePointer(this, this.peer, callFlags, args);
/* 497 */     return (ptr == 0L) ? null : new Pointer(ptr);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Object convertArgument(Object[] args, int index, Method invokingMethod, TypeMapper mapper, boolean allowObjects, Class<?> expectedType) {
/* 503 */     Object arg = args[index];
/* 504 */     if (arg != null) {
/* 505 */       Class<?> type = arg.getClass();
/* 506 */       ToNativeConverter converter = null;
/* 507 */       if (NativeMapped.class.isAssignableFrom(type)) {
/* 508 */         converter = NativeMappedConverter.getInstance(type);
/* 509 */       } else if (mapper != null) {
/* 510 */         converter = mapper.getToNativeConverter(type);
/*     */       } 
/* 512 */       if (converter != null) {
/*     */         ToNativeContext context;
/* 514 */         if (invokingMethod != null) {
/* 515 */           context = new MethodParameterContext(this, args, index, invokingMethod);
/*     */         } else {
/*     */           
/* 518 */           context = new FunctionParameterContext(this, args, index);
/*     */         } 
/* 520 */         arg = converter.toNative(arg, context);
/*     */       } 
/*     */     } 
/* 523 */     if (arg == null || isPrimitiveArray(arg.getClass())) {
/* 524 */       return arg;
/*     */     }
/*     */     
/* 527 */     Class<?> argClass = arg.getClass();
/*     */     
/* 529 */     if (arg instanceof Structure) {
/* 530 */       Structure struct = (Structure)arg;
/* 531 */       struct.autoWrite();
/* 532 */       if (struct instanceof Structure.ByValue) {
/*     */         
/* 534 */         Class<?> ptype = struct.getClass();
/* 535 */         if (invokingMethod != null) {
/* 536 */           Class<?>[] ptypes = invokingMethod.getParameterTypes();
/* 537 */           if (IS_VARARGS.isVarArgs(invokingMethod)) {
/* 538 */             if (index < ptypes.length - 1) {
/* 539 */               ptype = ptypes[index];
/*     */             } else {
/* 541 */               Class<?> etype = ptypes[ptypes.length - 1].getComponentType();
/* 542 */               if (etype != Object.class) {
/* 543 */                 ptype = etype;
/*     */               }
/*     */             } 
/*     */           } else {
/* 547 */             ptype = ptypes[index];
/*     */           } 
/*     */         } 
/* 550 */         if (Structure.ByValue.class.isAssignableFrom(ptype)) {
/* 551 */           return struct;
/*     */         }
/*     */       } 
/* 554 */       return struct.getPointer();
/* 555 */     }  if (arg instanceof Callback)
/*     */     {
/* 557 */       return CallbackReference.getFunctionPointer((Callback)arg); } 
/* 558 */     if (arg instanceof String)
/*     */     {
/*     */ 
/*     */ 
/*     */       
/* 563 */       return (new NativeString((String)arg, false)).getPointer(); } 
/* 564 */     if (arg instanceof WString)
/*     */     {
/* 566 */       return (new NativeString(arg.toString(), true)).getPointer(); } 
/* 567 */     if (arg instanceof Boolean)
/*     */     {
/*     */       
/* 570 */       return Boolean.TRUE.equals(arg) ? INTEGER_TRUE : INTEGER_FALSE; } 
/* 571 */     if (String[].class == argClass)
/* 572 */       return new StringArray((String[])arg, this.encoding); 
/* 573 */     if (WString[].class == argClass)
/* 574 */       return new StringArray((WString[])arg); 
/* 575 */     if (Pointer[].class == argClass)
/* 576 */       return new PointerArray((Pointer[])arg); 
/* 577 */     if (NativeMapped[].class.isAssignableFrom(argClass))
/* 578 */       return new NativeMappedArray((NativeMapped[])arg); 
/* 579 */     if (Structure[].class.isAssignableFrom(argClass)) {
/*     */ 
/*     */       
/* 582 */       Structure[] ss = (Structure[])arg;
/* 583 */       Class<?> type = argClass.getComponentType();
/* 584 */       boolean byRef = Structure.ByReference.class.isAssignableFrom(type);
/* 585 */       if (expectedType != null && 
/* 586 */         !Structure.ByReference[].class.isAssignableFrom(expectedType)) {
/* 587 */         if (byRef) {
/* 588 */           throw new IllegalArgumentException("Function " + getName() + " declared Structure[] at parameter " + index + " but array of " + type + " was passed");
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 593 */         for (int i = 0; i < ss.length; i++) {
/* 594 */           if (ss[i] instanceof Structure.ByReference) {
/* 595 */             throw new IllegalArgumentException("Function " + getName() + " declared Structure[] at parameter " + index + " but element " + i + " is of Structure.ByReference type");
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 603 */       if (byRef) {
/* 604 */         Structure.autoWrite(ss);
/* 605 */         Pointer[] pointers = new Pointer[ss.length + 1];
/* 606 */         for (int i = 0; i < ss.length; i++) {
/* 607 */           pointers[i] = (ss[i] != null) ? ss[i].getPointer() : null;
/*     */         }
/* 609 */         return new PointerArray(pointers);
/* 610 */       }  if (ss.length == 0)
/* 611 */         throw new IllegalArgumentException("Structure array must have non-zero length"); 
/* 612 */       if (ss[0] == null) {
/* 613 */         Structure.newInstance(type).toArray(ss);
/* 614 */         return ss[0].getPointer();
/*     */       } 
/* 616 */       Structure.autoWrite(ss);
/* 617 */       return ss[0].getPointer();
/*     */     } 
/* 619 */     if (argClass.isArray())
/* 620 */       throw new IllegalArgumentException("Unsupported array argument type: " + argClass
/* 621 */           .getComponentType()); 
/* 622 */     if (allowObjects)
/* 623 */       return arg; 
/* 624 */     if (!Native.isSupportedNativeType(arg.getClass())) {
/* 625 */       throw new IllegalArgumentException("Unsupported argument type " + arg
/* 626 */           .getClass().getName() + " at parameter " + index + " of function " + 
/*     */           
/* 628 */           getName());
/*     */     }
/* 630 */     return arg;
/*     */   }
/*     */   
/*     */   private boolean isPrimitiveArray(Class<?> argClass) {
/* 634 */     return (argClass.isArray() && argClass
/* 635 */       .getComponentType().isPrimitive());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void invoke(Object[] args) {
/* 645 */     invoke(Void.class, args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String invokeString(int callFlags, Object[] args, boolean wide) {
/* 660 */     Pointer ptr = invokePointer(callFlags, args);
/* 661 */     String s = null;
/* 662 */     if (ptr != null) {
/* 663 */       if (wide) {
/* 664 */         s = ptr.getWideString(0L);
/*     */       } else {
/*     */         
/* 667 */         s = ptr.getString(0L, this.encoding);
/*     */       } 
/*     */     }
/* 670 */     return s;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 676 */     if (this.library != null) {
/* 677 */       return "native function " + this.functionName + "(" + this.library.getName() + ")@0x" + 
/* 678 */         Long.toHexString(this.peer);
/*     */     }
/* 680 */     return "native function@0x" + Long.toHexString(this.peer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object invokeObject(Object[] args) {
/* 687 */     return invoke(Object.class, args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Pointer invokePointer(Object[] args) {
/* 694 */     return (Pointer)invoke(Pointer.class, args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String invokeString(Object[] args, boolean wide) {
/* 705 */     Object o = invoke(wide ? WString.class : String.class, args);
/* 706 */     return (o != null) ? o.toString() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int invokeInt(Object[] args) {
/* 713 */     return ((Integer)invoke(Integer.class, args)).intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long invokeLong(Object[] args) {
/* 719 */     return ((Long)invoke(Long.class, args)).longValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public float invokeFloat(Object[] args) {
/* 725 */     return ((Float)invoke(Float.class, args)).floatValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double invokeDouble(Object[] args) {
/* 731 */     return ((Double)invoke(Double.class, args)).doubleValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void invokeVoid(Object[] args) {
/* 737 */     invoke(Void.class, args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 745 */     if (o == this) return true; 
/* 746 */     if (o == null) return false; 
/* 747 */     if (o.getClass() == getClass()) {
/* 748 */       Function other = (Function)o;
/* 749 */       return (other.callFlags == this.callFlags && other.options
/* 750 */         .equals(this.options) && other.peer == this.peer);
/*     */     } 
/*     */     
/* 753 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 761 */     return this.callFlags + this.options.hashCode() + super.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Object[] concatenateVarArgs(Object[] inArgs) {
/* 771 */     if (inArgs != null && inArgs.length > 0) {
/* 772 */       Object lastArg = inArgs[inArgs.length - 1];
/* 773 */       Class<?> argType = (lastArg != null) ? lastArg.getClass() : null;
/* 774 */       if (argType != null && argType.isArray()) {
/* 775 */         Object[] varArgs = (Object[])lastArg;
/*     */         
/* 777 */         for (int i = 0; i < varArgs.length; i++) {
/* 778 */           if (varArgs[i] instanceof Float) {
/* 779 */             varArgs[i] = Double.valueOf(((Float)varArgs[i]).floatValue());
/*     */           }
/*     */         } 
/* 782 */         Object[] fullArgs = new Object[inArgs.length + varArgs.length];
/* 783 */         System.arraycopy(inArgs, 0, fullArgs, 0, inArgs.length - 1);
/* 784 */         System.arraycopy(varArgs, 0, fullArgs, inArgs.length - 1, varArgs.length);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 790 */         fullArgs[fullArgs.length - 1] = null;
/* 791 */         inArgs = fullArgs;
/*     */       } 
/*     */     } 
/* 794 */     return inArgs;
/*     */   }
/*     */ 
/*     */   
/*     */   static boolean isVarArgs(Method m) {
/* 799 */     return IS_VARARGS.isVarArgs(m);
/*     */   }
/*     */ 
/*     */   
/*     */   static int fixedArgs(Method m) {
/* 804 */     return IS_VARARGS.fixedArgs(m);
/*     */   }
/*     */   public static interface PostCallRead {
/*     */     void read(); }
/*     */   
/*     */   private static class NativeMappedArray extends Memory implements PostCallRead { public NativeMappedArray(NativeMapped[] arg) {
/* 810 */       super(Native.getNativeSize(arg.getClass(), arg));
/* 811 */       this.original = arg;
/* 812 */       setValue(0L, this.original, this.original.getClass());
/*     */     }
/*     */     private final NativeMapped[] original;
/*     */     public void read() {
/* 816 */       getValue(0L, this.original.getClass(), this.original);
/*     */     } }
/*     */   
/*     */   private static class PointerArray extends Memory implements PostCallRead {
/*     */     private final Pointer[] original;
/*     */     
/*     */     public PointerArray(Pointer[] arg) {
/* 823 */       super((Native.POINTER_SIZE * (arg.length + 1)));
/* 824 */       this.original = arg;
/* 825 */       for (int i = 0; i < arg.length; i++) {
/* 826 */         setPointer((i * Native.POINTER_SIZE), arg[i]);
/*     */       }
/* 828 */       setPointer((Native.POINTER_SIZE * arg.length), (Pointer)null);
/*     */     }
/*     */     
/*     */     public void read() {
/* 832 */       read(0L, this.original, 0, this.original.length);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static Boolean valueOf(boolean b) {
/* 838 */     return b ? Boolean.TRUE : Boolean.FALSE;
/*     */   }
/*     */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\com\sun\jna\Function.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */