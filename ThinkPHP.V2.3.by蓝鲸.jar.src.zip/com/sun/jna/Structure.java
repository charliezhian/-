/*      */ package com.sun.jna;
/*      */ 
/*      */ import java.lang.annotation.Documented;
/*      */ import java.lang.annotation.ElementType;
/*      */ import java.lang.annotation.Retention;
/*      */ import java.lang.annotation.RetentionPolicy;
/*      */ import java.lang.annotation.Target;
/*      */ import java.lang.reflect.Array;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.nio.Buffer;
/*      */ import java.util.AbstractCollection;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.WeakHashMap;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class Structure
/*      */ {
/*  114 */   private static final Logger LOG = Logger.getLogger(Structure.class.getName());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int ALIGN_DEFAULT = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int ALIGN_NONE = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int ALIGN_GNUC = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int ALIGN_MSVC = 3;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final int CALCULATE_SIZE = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  147 */   static final Map<Class<?>, LayoutInfo> layoutInfo = new WeakHashMap<Class<?>, LayoutInfo>();
/*  148 */   static final Map<Class<?>, List<String>> fieldOrder = new WeakHashMap<Class<?>, List<String>>();
/*      */   
/*      */   private Pointer memory;
/*      */   
/*  152 */   private int size = -1;
/*      */   
/*      */   private int alignType;
/*      */   
/*      */   private String encoding;
/*      */   private int actualAlignType;
/*      */   private int structAlignment;
/*      */   private Map<String, StructField> structFields;
/*  160 */   private final Map<String, Object> nativeStrings = new HashMap<String, Object>();
/*      */   
/*      */   private TypeMapper typeMapper;
/*      */   
/*      */   private long typeInfo;
/*      */   
/*      */   private boolean autoRead = true;
/*      */   private boolean autoWrite = true;
/*      */   private Structure[] array;
/*      */   private boolean readCalled;
/*      */   
/*      */   protected Structure() {
/*  172 */     this(0);
/*      */   }
/*      */   
/*      */   protected Structure(TypeMapper mapper) {
/*  176 */     this(null, 0, mapper);
/*      */   }
/*      */   
/*      */   protected Structure(int alignType) {
/*  180 */     this((Pointer)null, alignType);
/*      */   }
/*      */   
/*      */   protected Structure(int alignType, TypeMapper mapper) {
/*  184 */     this(null, alignType, mapper);
/*      */   }
/*      */ 
/*      */   
/*      */   protected Structure(Pointer p) {
/*  189 */     this(p, 0);
/*      */   }
/*      */   
/*      */   protected Structure(Pointer p, int alignType) {
/*  193 */     this(p, alignType, null);
/*      */   }
/*      */   
/*      */   protected Structure(Pointer p, int alignType, TypeMapper mapper) {
/*  197 */     setAlignType(alignType);
/*  198 */     setStringEncoding(Native.getStringEncoding(getClass()));
/*  199 */     initializeTypeMapper(mapper);
/*  200 */     validateFields();
/*  201 */     if (p != null) {
/*  202 */       useMemory(p, 0, true);
/*      */     } else {
/*      */       
/*  205 */       allocateMemory(-1);
/*      */     } 
/*  207 */     initializeFields();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Map<String, StructField> fields() {
/*  218 */     return this.structFields;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   TypeMapper getTypeMapper() {
/*  225 */     return this.typeMapper;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void initializeTypeMapper(TypeMapper mapper) {
/*  235 */     if (mapper == null) {
/*  236 */       mapper = Native.getTypeMapper(getClass());
/*      */     }
/*  238 */     this.typeMapper = mapper;
/*  239 */     layoutChanged();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void layoutChanged() {
/*  246 */     if (this.size != -1) {
/*  247 */       this.size = -1;
/*  248 */       if (this.memory instanceof AutoAllocated) {
/*  249 */         this.memory = null;
/*      */       }
/*      */       
/*  252 */       ensureAllocated();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setStringEncoding(String encoding) {
/*  261 */     this.encoding = encoding;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getStringEncoding() {
/*  269 */     return this.encoding;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setAlignType(int alignType) {
/*  278 */     this.alignType = alignType;
/*  279 */     if (alignType == 0) {
/*  280 */       alignType = Native.getStructureAlignment(getClass());
/*  281 */       if (alignType == 0)
/*  282 */         if (Platform.isWindows()) {
/*  283 */           alignType = 3;
/*      */         } else {
/*  285 */           alignType = 2;
/*      */         }  
/*      */     } 
/*  288 */     this.actualAlignType = alignType;
/*  289 */     layoutChanged();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Memory autoAllocate(int size) {
/*  298 */     return new AutoAllocated(size);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void useMemory(Pointer m) {
/*  308 */     useMemory(m, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void useMemory(Pointer m, int offset) {
/*  320 */     useMemory(m, offset, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void useMemory(Pointer m, int offset, boolean force) {
/*      */     try {
/*  336 */       this.nativeStrings.clear();
/*      */       
/*  338 */       if (this instanceof ByValue && !force) {
/*      */ 
/*      */         
/*  341 */         byte[] buf = new byte[size()];
/*  342 */         m.read(0L, buf, 0, buf.length);
/*  343 */         this.memory.write(0L, buf, 0, buf.length);
/*      */       
/*      */       }
/*      */       else {
/*      */         
/*  348 */         this.memory = m.share(offset);
/*  349 */         if (this.size == -1) {
/*  350 */           this.size = calculateSize(false);
/*      */         }
/*  352 */         if (this.size != -1) {
/*  353 */           this.memory = m.share(offset, this.size);
/*      */         }
/*      */       } 
/*  356 */       this.array = null;
/*  357 */       this.readCalled = false;
/*      */     }
/*  359 */     catch (IndexOutOfBoundsException e) {
/*  360 */       throw new IllegalArgumentException("Structure exceeds provided memory bounds", e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void ensureAllocated() {
/*  367 */     ensureAllocated(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void ensureAllocated(boolean avoidFFIType) {
/*  376 */     if (this.memory == null) {
/*  377 */       allocateMemory(avoidFFIType);
/*      */     }
/*  379 */     else if (this.size == -1) {
/*  380 */       this.size = calculateSize(true, avoidFFIType);
/*  381 */       if (!(this.memory instanceof AutoAllocated)) {
/*      */         
/*      */         try {
/*  384 */           this.memory = this.memory.share(0L, this.size);
/*      */         }
/*  386 */         catch (IndexOutOfBoundsException e) {
/*  387 */           throw new IllegalArgumentException("Structure exceeds provided memory bounds", e);
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void allocateMemory() {
/*  397 */     allocateMemory(false);
/*      */   }
/*      */   
/*      */   private void allocateMemory(boolean avoidFFIType) {
/*  401 */     allocateMemory(calculateSize(true, avoidFFIType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void allocateMemory(int size) {
/*  412 */     if (size == -1) {
/*      */       
/*  414 */       size = calculateSize(false);
/*      */     }
/*  416 */     else if (size <= 0) {
/*  417 */       throw new IllegalArgumentException("Structure size must be greater than zero: " + size);
/*      */     } 
/*      */ 
/*      */     
/*  421 */     if (size != -1) {
/*  422 */       if (this.memory == null || this.memory instanceof AutoAllocated)
/*      */       {
/*  424 */         this.memory = autoAllocate(size);
/*      */       }
/*  426 */       this.size = size;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int size() {
/*  434 */     ensureAllocated();
/*  435 */     return this.size;
/*      */   }
/*      */ 
/*      */   
/*      */   public void clear() {
/*  440 */     ensureAllocated();
/*  441 */     this.memory.clear(size());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer getPointer() {
/*  455 */     ensureAllocated();
/*  456 */     return this.memory;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  465 */   private static final ThreadLocal<Map<Pointer, Structure>> reads = new ThreadLocal<Map<Pointer, Structure>>()
/*      */     {
/*      */       protected synchronized Map<Pointer, Structure> initialValue() {
/*  468 */         return new HashMap<Pointer, Structure>();
/*      */       }
/*      */     };
/*      */ 
/*      */ 
/*      */   
/*  474 */   private static final ThreadLocal<Set<Structure>> busy = new ThreadLocal<Set<Structure>>()
/*      */     {
/*      */       protected synchronized Set<Structure> initialValue() {
/*  477 */         return new Structure.StructureSet();
/*      */       }
/*      */     };
/*      */   
/*      */   static class StructureSet
/*      */     extends AbstractCollection<Structure>
/*      */     implements Set<Structure> {
/*      */     Structure[] elements;
/*      */     private int count;
/*      */     
/*      */     private void ensureCapacity(int size) {
/*  488 */       if (this.elements == null) {
/*  489 */         this.elements = new Structure[size * 3 / 2];
/*      */       }
/*  491 */       else if (this.elements.length < size) {
/*  492 */         Structure[] e = new Structure[size * 3 / 2];
/*  493 */         System.arraycopy(this.elements, 0, e, 0, this.elements.length);
/*  494 */         this.elements = e;
/*      */       } 
/*      */     }
/*      */     public Structure[] getElements() {
/*  498 */       return this.elements;
/*      */     }
/*      */     public int size() {
/*  501 */       return this.count;
/*      */     }
/*      */     public boolean contains(Object o) {
/*  504 */       return (indexOf((Structure)o) != -1);
/*      */     }
/*      */     
/*      */     public boolean add(Structure o) {
/*  508 */       if (!contains(o)) {
/*  509 */         ensureCapacity(this.count + 1);
/*  510 */         this.elements[this.count++] = o;
/*      */       } 
/*  512 */       return true;
/*      */     }
/*      */     private int indexOf(Structure s1) {
/*  515 */       for (int i = 0; i < this.count; i++) {
/*  516 */         Structure s2 = this.elements[i];
/*  517 */         if (s1 == s2 || (s1
/*  518 */           .getClass() == s2.getClass() && s1
/*  519 */           .size() == s2.size() && s1
/*  520 */           .getPointer().equals(s2.getPointer()))) {
/*  521 */           return i;
/*      */         }
/*      */       } 
/*  524 */       return -1;
/*      */     }
/*      */     
/*      */     public boolean remove(Object o) {
/*  528 */       int idx = indexOf((Structure)o);
/*  529 */       if (idx != -1) {
/*  530 */         if (--this.count >= 0) {
/*  531 */           this.elements[idx] = this.elements[this.count];
/*  532 */           this.elements[this.count] = null;
/*      */         } 
/*  534 */         return true;
/*      */       } 
/*  536 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Iterator<Structure> iterator() {
/*  543 */       Structure[] e = new Structure[this.count];
/*  544 */       if (this.count > 0) {
/*  545 */         System.arraycopy(this.elements, 0, e, 0, this.count);
/*      */       }
/*  547 */       return Arrays.<Structure>asList(e).iterator();
/*      */     }
/*      */   }
/*      */   
/*      */   static Set<Structure> busy() {
/*  552 */     return busy.get();
/*      */   }
/*      */   static Map<Pointer, Structure> reading() {
/*  555 */     return reads.get();
/*      */   }
/*      */ 
/*      */   
/*      */   void conditionalAutoRead() {
/*  560 */     if (!this.readCalled) {
/*  561 */       autoRead();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void read() {
/*  570 */     if (this.memory == PLACEHOLDER_MEMORY) {
/*      */       return;
/*      */     }
/*  573 */     this.readCalled = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  579 */     ensureAllocated();
/*      */ 
/*      */     
/*  582 */     if (busy().contains(this)) {
/*      */       return;
/*      */     }
/*  585 */     busy().add(this);
/*  586 */     if (this instanceof ByReference) {
/*  587 */       reading().put(getPointer(), this);
/*      */     }
/*      */     try {
/*  590 */       for (StructField structField : fields().values()) {
/*  591 */         readField(structField);
/*      */       }
/*      */     } finally {
/*      */       
/*  595 */       busy().remove(this);
/*  596 */       if (reading().get(getPointer()) == this) {
/*  597 */         reading().remove(getPointer());
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int fieldOffset(String name) {
/*  607 */     ensureAllocated();
/*  608 */     StructField f = fields().get(name);
/*  609 */     if (f == null)
/*  610 */       throw new IllegalArgumentException("No such field: " + name); 
/*  611 */     return f.offset;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object readField(String name) {
/*  621 */     ensureAllocated();
/*  622 */     StructField f = fields().get(name);
/*  623 */     if (f == null)
/*  624 */       throw new IllegalArgumentException("No such field: " + name); 
/*  625 */     return readField(f);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Object getFieldValue(Field field) {
/*      */     try {
/*  635 */       return field.get(this);
/*      */     }
/*  637 */     catch (Exception e) {
/*  638 */       throw new Error("Exception reading field '" + field.getName() + "' in " + getClass(), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setFieldValue(Field field, Object value) {
/*  647 */     setFieldValue(field, value, false);
/*      */   }
/*      */ 
/*      */   
/*      */   private void setFieldValue(Field field, Object value, boolean overrideFinal) {
/*      */     try {
/*  653 */       field.set(this, value);
/*      */     }
/*  655 */     catch (IllegalAccessException e) {
/*  656 */       int modifiers = field.getModifiers();
/*  657 */       if (Modifier.isFinal(modifiers)) {
/*  658 */         if (overrideFinal)
/*      */         {
/*      */           
/*  661 */           throw new UnsupportedOperationException("This VM does not support Structures with final fields (field '" + field.getName() + "' within " + getClass() + ")", e);
/*      */         }
/*  663 */         throw new UnsupportedOperationException("Attempt to write to read-only field '" + field.getName() + "' within " + getClass(), e);
/*      */       } 
/*  665 */       throw new Error("Unexpectedly unable to write to field '" + field.getName() + "' within " + getClass(), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static <T extends Structure> T updateStructureByReference(Class<T> type, T s, Pointer address) {
/*  677 */     if (address == null) {
/*  678 */       s = null;
/*      */     
/*      */     }
/*  681 */     else if (s == null || !address.equals(s.getPointer())) {
/*  682 */       Structure s1 = reading().get(address);
/*  683 */       if (s1 != null && type.equals(s1.getClass())) {
/*  684 */         Structure structure = s1;
/*  685 */         structure.autoRead();
/*      */       } else {
/*      */         
/*  688 */         s = newInstance(type, address);
/*  689 */         s.conditionalAutoRead();
/*      */       } 
/*      */     } else {
/*      */       
/*  693 */       s.autoRead();
/*      */     } 
/*      */     
/*  696 */     return s;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object readField(StructField structField) {
/*      */     Object result;
/*  708 */     int offset = structField.offset;
/*      */ 
/*      */     
/*  711 */     Class<?> fieldType = structField.type;
/*  712 */     FromNativeConverter readConverter = structField.readConverter;
/*  713 */     if (readConverter != null) {
/*  714 */       fieldType = readConverter.nativeType();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  723 */     Object currentValue = (Structure.class.isAssignableFrom(fieldType) || Callback.class.isAssignableFrom(fieldType) || (Platform.HAS_BUFFERS && Buffer.class.isAssignableFrom(fieldType)) || Pointer.class.isAssignableFrom(fieldType) || NativeMapped.class.isAssignableFrom(fieldType) || fieldType.isArray()) ? getFieldValue(structField.field) : null;
/*      */ 
/*      */     
/*  726 */     if (fieldType == String.class) {
/*  727 */       Pointer p = this.memory.getPointer(offset);
/*  728 */       result = (p == null) ? null : p.getString(0L, this.encoding);
/*      */     } else {
/*      */       
/*  731 */       result = this.memory.getValue(offset, fieldType, currentValue);
/*      */     } 
/*  733 */     if (readConverter != null) {
/*  734 */       result = readConverter.fromNative(result, structField.context);
/*  735 */       if (currentValue != null && currentValue.equals(result)) {
/*  736 */         result = currentValue;
/*      */       }
/*      */     } 
/*      */     
/*  740 */     if (fieldType.equals(String.class) || fieldType
/*  741 */       .equals(WString.class)) {
/*  742 */       this.nativeStrings.put(structField.name + ".ptr", this.memory.getPointer(offset));
/*  743 */       this.nativeStrings.put(structField.name + ".val", result);
/*      */     } 
/*      */ 
/*      */     
/*  747 */     setFieldValue(structField.field, result, true);
/*  748 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void write() {
/*  756 */     if (this.memory == PLACEHOLDER_MEMORY) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  763 */     ensureAllocated();
/*      */ 
/*      */     
/*  766 */     if (this instanceof ByValue) {
/*  767 */       getTypeInfo();
/*      */     }
/*      */ 
/*      */     
/*  771 */     if (busy().contains(this)) {
/*      */       return;
/*      */     }
/*  774 */     busy().add(this);
/*      */     
/*      */     try {
/*  777 */       for (StructField sf : fields().values()) {
/*  778 */         if (!sf.isVolatile) {
/*  779 */           writeField(sf);
/*      */         }
/*      */       } 
/*      */     } finally {
/*      */       
/*  784 */       busy().remove(this);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeField(String name) {
/*  794 */     ensureAllocated();
/*  795 */     StructField f = fields().get(name);
/*  796 */     if (f == null)
/*  797 */       throw new IllegalArgumentException("No such field: " + name); 
/*  798 */     writeField(f);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeField(String name, Object value) {
/*  809 */     ensureAllocated();
/*  810 */     StructField structField = fields().get(name);
/*  811 */     if (structField == null)
/*  812 */       throw new IllegalArgumentException("No such field: " + name); 
/*  813 */     setFieldValue(structField.field, value);
/*  814 */     writeField(structField);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void writeField(StructField structField) {
/*  822 */     if (structField.isReadOnly) {
/*      */       return;
/*      */     }
/*      */     
/*  826 */     int offset = structField.offset;
/*      */ 
/*      */     
/*  829 */     Object value = getFieldValue(structField.field);
/*      */ 
/*      */     
/*  832 */     Class<?> fieldType = structField.type;
/*  833 */     ToNativeConverter converter = structField.writeConverter;
/*  834 */     if (converter != null) {
/*  835 */       value = converter.toNative(value, new StructureWriteContext(this, structField.field));
/*  836 */       fieldType = converter.nativeType();
/*      */     } 
/*      */ 
/*      */     
/*  840 */     if (String.class == fieldType || WString.class == fieldType) {
/*      */ 
/*      */       
/*  843 */       boolean wide = (fieldType == WString.class);
/*  844 */       if (value != null) {
/*      */ 
/*      */         
/*  847 */         if (this.nativeStrings.containsKey(structField.name + ".ptr") && value
/*  848 */           .equals(this.nativeStrings.get(structField.name + ".val"))) {
/*      */           return;
/*      */         }
/*      */ 
/*      */         
/*  853 */         NativeString nativeString = wide ? new NativeString(value.toString(), true) : new NativeString(value.toString(), this.encoding);
/*      */ 
/*      */         
/*  856 */         this.nativeStrings.put(structField.name, nativeString);
/*  857 */         value = nativeString.getPointer();
/*      */       } else {
/*      */         
/*  860 */         this.nativeStrings.remove(structField.name);
/*      */       } 
/*  862 */       this.nativeStrings.remove(structField.name + ".ptr");
/*  863 */       this.nativeStrings.remove(structField.name + ".val");
/*      */     } 
/*      */     
/*      */     try {
/*  867 */       this.memory.setValue(offset, value, fieldType);
/*      */     }
/*  869 */     catch (IllegalArgumentException e) {
/*  870 */       String msg = "Structure field \"" + structField.name + "\" was declared as " + structField.type + ((structField.type == fieldType) ? "" : (" (native type " + fieldType + ")")) + ", which is not supported within a Structure";
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  875 */       throw new IllegalArgumentException(msg, e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected List<String> getFieldOrder() {
/*  950 */     List<String> fields = new LinkedList<String>();
/*  951 */     for (Class<?> clazz = getClass(); clazz != Structure.class; clazz = clazz.getSuperclass()) {
/*  952 */       FieldOrder order = clazz.<FieldOrder>getAnnotation(FieldOrder.class);
/*  953 */       if (order != null) {
/*  954 */         fields.addAll(0, Arrays.asList(order.value()));
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  959 */     return Collections.unmodifiableList(fields);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void sortFields(List<Field> fields, List<String> names) {
/*  967 */     for (int i = 0; i < names.size(); i++) {
/*  968 */       String name = names.get(i);
/*  969 */       for (int f = 0; f < fields.size(); f++) {
/*  970 */         Field field = fields.get(f);
/*  971 */         if (name.equals(field.getName())) {
/*  972 */           Collections.swap(fields, i, f);
/*      */           break;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected List<Field> getFieldList() {
/*  984 */     List<Field> flist = new ArrayList<Field>();
/*  985 */     Class<?> cls = getClass();
/*  986 */     for (; !cls.equals(Structure.class); 
/*  987 */       cls = cls.getSuperclass()) {
/*  988 */       List<Field> classFields = new ArrayList<Field>();
/*  989 */       Field[] fields = cls.getDeclaredFields();
/*  990 */       for (int i = 0; i < fields.length; i++) {
/*  991 */         int modifiers = fields[i].getModifiers();
/*  992 */         if (!Modifier.isStatic(modifiers) && Modifier.isPublic(modifiers))
/*      */         {
/*      */           
/*  995 */           classFields.add(fields[i]); } 
/*      */       } 
/*  997 */       flist.addAll(0, classFields);
/*      */     } 
/*  999 */     return flist;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private List<String> fieldOrder() {
/* 1006 */     Class<?> clazz = getClass();
/* 1007 */     synchronized (fieldOrder) {
/* 1008 */       List<String> list = fieldOrder.get(clazz);
/* 1009 */       if (list == null) {
/* 1010 */         list = getFieldOrder();
/* 1011 */         fieldOrder.put(clazz, list);
/*      */       } 
/* 1013 */       return list;
/*      */     } 
/*      */   }
/*      */   
/*      */   public static List<String> createFieldsOrder(List<String> baseFields, String... extraFields) {
/* 1018 */     return createFieldsOrder(baseFields, Arrays.asList(extraFields));
/*      */   }
/*      */   
/*      */   public static List<String> createFieldsOrder(List<String> baseFields, List<String> extraFields) {
/* 1022 */     List<String> fields = new ArrayList<String>(baseFields.size() + extraFields.size());
/* 1023 */     fields.addAll(baseFields);
/* 1024 */     fields.addAll(extraFields);
/* 1025 */     return Collections.unmodifiableList(fields);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<String> createFieldsOrder(String field) {
/* 1033 */     return Collections.unmodifiableList(Collections.singletonList(field));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<String> createFieldsOrder(String... fields) {
/* 1041 */     return Collections.unmodifiableList(Arrays.asList(fields));
/*      */   }
/*      */   
/*      */   private static <T extends Comparable<T>> List<T> sort(Collection<? extends T> c) {
/* 1045 */     List<T> list = new ArrayList<T>(c);
/* 1046 */     Collections.sort(list);
/* 1047 */     return list;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected List<Field> getFields(boolean force) {
/* 1058 */     List<Field> flist = getFieldList();
/* 1059 */     Set<String> names = new HashSet<String>();
/* 1060 */     for (Field f : flist) {
/* 1061 */       names.add(f.getName());
/*      */     }
/*      */     
/* 1064 */     List<String> fieldOrder = fieldOrder();
/* 1065 */     if (fieldOrder.size() != flist.size() && flist.size() > 1) {
/* 1066 */       if (force) {
/* 1067 */         throw new Error("Structure.getFieldOrder() on " + getClass() + (
/* 1068 */             (fieldOrder.size() < flist.size()) ? " does not provide enough" : " provides too many") + " names [" + fieldOrder
/*      */ 
/*      */             
/* 1071 */             .size() + "] (" + 
/*      */             
/* 1073 */             sort(fieldOrder) + ") to match declared fields [" + flist
/* 1074 */             .size() + "] (" + 
/*      */             
/* 1076 */             sort(names) + ")");
/*      */       }
/*      */       
/* 1079 */       return null;
/*      */     } 
/*      */     
/* 1082 */     Set<String> orderedNames = new HashSet<String>(fieldOrder);
/* 1083 */     if (!orderedNames.equals(names)) {
/* 1084 */       throw new Error("Structure.getFieldOrder() on " + getClass() + " returns names (" + 
/*      */           
/* 1086 */           sort(fieldOrder) + ") which do not match declared field names (" + 
/*      */           
/* 1088 */           sort(names) + ")");
/*      */     }
/*      */     
/* 1091 */     sortFields(flist, fieldOrder);
/* 1092 */     return flist;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int calculateSize(boolean force) {
/* 1110 */     return calculateSize(force, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static int size(Class<? extends Structure> type) {
/* 1118 */     return size(type, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static <T extends Structure> int size(Class<T> type, T value) {
/*      */     LayoutInfo info;
/* 1128 */     synchronized (layoutInfo) {
/* 1129 */       info = layoutInfo.get(type);
/*      */     } 
/* 1131 */     int sz = (info != null && !info.variable) ? info.size : -1;
/* 1132 */     if (sz == -1) {
/* 1133 */       if (value == null) {
/* 1134 */         value = newInstance(type, PLACEHOLDER_MEMORY);
/*      */       }
/* 1136 */       sz = value.size();
/*      */     } 
/* 1138 */     return sz;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int calculateSize(boolean force, boolean avoidFFIType) {
/*      */     LayoutInfo info;
/* 1149 */     int size = -1;
/* 1150 */     Class<?> clazz = getClass();
/*      */     
/* 1152 */     synchronized (layoutInfo) {
/* 1153 */       info = layoutInfo.get(clazz);
/*      */     } 
/* 1155 */     if (info == null || this.alignType != info
/* 1156 */       .alignType || this.typeMapper != info
/* 1157 */       .typeMapper) {
/* 1158 */       info = deriveLayout(force, avoidFFIType);
/*      */     }
/* 1160 */     if (info != null) {
/* 1161 */       this.structAlignment = info.alignment;
/* 1162 */       this.structFields = info.fields;
/*      */       
/* 1164 */       if (!info.variable) {
/* 1165 */         synchronized (layoutInfo) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1171 */           if (!layoutInfo.containsKey(clazz) || this.alignType != 0 || this.typeMapper != null)
/*      */           {
/*      */             
/* 1174 */             layoutInfo.put(clazz, info);
/*      */           }
/*      */         } 
/*      */       }
/* 1178 */       size = info.size;
/*      */     } 
/* 1180 */     return size;
/*      */   }
/*      */   
/*      */   private static class LayoutInfo
/*      */   {
/*      */     private LayoutInfo() {}
/*      */     
/* 1187 */     private int size = -1;
/* 1188 */     private int alignment = 1;
/* 1189 */     private final Map<String, Structure.StructField> fields = Collections.synchronizedMap(new LinkedHashMap<String, Structure.StructField>());
/* 1190 */     private int alignType = 0;
/*      */     
/*      */     private TypeMapper typeMapper;
/*      */     private boolean variable;
/*      */     private Structure.StructField typeInfoField;
/*      */   }
/*      */   
/*      */   private void validateField(String name, Class<?> type) {
/* 1198 */     if (this.typeMapper != null) {
/* 1199 */       ToNativeConverter toNative = this.typeMapper.getToNativeConverter(type);
/* 1200 */       if (toNative != null) {
/* 1201 */         validateField(name, toNative.nativeType());
/*      */         return;
/*      */       } 
/*      */     } 
/* 1205 */     if (type.isArray()) {
/* 1206 */       validateField(name, type.getComponentType());
/*      */     } else {
/*      */       
/*      */       try {
/* 1210 */         getNativeSize(type);
/*      */       }
/* 1212 */       catch (IllegalArgumentException e) {
/* 1213 */         String msg = "Invalid Structure field in " + getClass() + ", field name '" + name + "' (" + type + "): " + e.getMessage();
/* 1214 */         throw new IllegalArgumentException(msg, e);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void validateFields() {
/* 1221 */     List<Field> fields = getFieldList();
/* 1222 */     for (Field f : fields) {
/* 1223 */       validateField(f.getName(), f.getType());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private LayoutInfo deriveLayout(boolean force, boolean avoidFFIType) {
/* 1232 */     int calculatedSize = 0;
/* 1233 */     List<Field> fields = getFields(force);
/* 1234 */     if (fields == null) {
/* 1235 */       return null;
/*      */     }
/*      */     
/* 1238 */     LayoutInfo info = new LayoutInfo();
/* 1239 */     info.alignType = this.alignType;
/* 1240 */     info.typeMapper = this.typeMapper;
/*      */     
/* 1242 */     boolean firstField = true;
/* 1243 */     for (Iterator<Field> i = fields.iterator(); i.hasNext(); firstField = false) {
/* 1244 */       Field field = i.next();
/* 1245 */       int modifiers = field.getModifiers();
/*      */       
/* 1247 */       Class<?> type = field.getType();
/* 1248 */       if (type.isArray()) {
/* 1249 */         info.variable = true;
/*      */       }
/* 1251 */       StructField structField = new StructField();
/* 1252 */       structField.isVolatile = Modifier.isVolatile(modifiers);
/* 1253 */       structField.isReadOnly = Modifier.isFinal(modifiers);
/* 1254 */       if (structField.isReadOnly) {
/* 1255 */         if (!Platform.RO_FIELDS) {
/* 1256 */           throw new IllegalArgumentException("This VM does not support read-only fields (field '" + field
/* 1257 */               .getName() + "' within " + getClass() + ")");
/*      */         }
/*      */ 
/*      */         
/* 1261 */         field.setAccessible(true);
/*      */       } 
/* 1263 */       structField.field = field;
/* 1264 */       structField.name = field.getName();
/* 1265 */       structField.type = type;
/*      */ 
/*      */       
/* 1268 */       if (Callback.class.isAssignableFrom(type) && !type.isInterface()) {
/* 1269 */         throw new IllegalArgumentException("Structure Callback field '" + field
/* 1270 */             .getName() + "' must be an interface");
/*      */       }
/*      */       
/* 1273 */       if (type.isArray() && Structure.class
/* 1274 */         .equals(type.getComponentType())) {
/* 1275 */         String msg = "Nested Structure arrays must use a derived Structure type so that the size of the elements can be determined";
/*      */ 
/*      */         
/* 1278 */         throw new IllegalArgumentException(msg);
/*      */       } 
/*      */       
/* 1281 */       int fieldAlignment = 1;
/* 1282 */       if (Modifier.isPublic(field.getModifiers())) {
/*      */ 
/*      */ 
/*      */         
/* 1286 */         Object value = getFieldValue(structField.field);
/* 1287 */         if (value == null && type.isArray()) {
/* 1288 */           if (force) {
/* 1289 */             throw new IllegalStateException("Array fields must be initialized");
/*      */           }
/*      */           
/* 1292 */           return null;
/*      */         } 
/* 1294 */         Class<?> nativeType = type;
/* 1295 */         if (NativeMapped.class.isAssignableFrom(type)) {
/* 1296 */           NativeMappedConverter tc = NativeMappedConverter.getInstance(type);
/* 1297 */           nativeType = tc.nativeType();
/* 1298 */           structField.writeConverter = tc;
/* 1299 */           structField.readConverter = tc;
/* 1300 */           structField.context = new StructureReadContext(this, field);
/*      */         }
/* 1302 */         else if (this.typeMapper != null) {
/* 1303 */           ToNativeConverter writeConverter = this.typeMapper.getToNativeConverter(type);
/* 1304 */           FromNativeConverter readConverter = this.typeMapper.getFromNativeConverter(type);
/* 1305 */           if (writeConverter != null && readConverter != null) {
/* 1306 */             value = writeConverter.toNative(value, new StructureWriteContext(this, structField.field));
/*      */             
/* 1308 */             nativeType = (value != null) ? value.getClass() : Pointer.class;
/* 1309 */             structField.writeConverter = writeConverter;
/* 1310 */             structField.readConverter = readConverter;
/* 1311 */             structField.context = new StructureReadContext(this, field);
/*      */           }
/* 1313 */           else if (writeConverter != null || readConverter != null) {
/* 1314 */             String msg = "Structures require bidirectional type conversion for " + type;
/* 1315 */             throw new IllegalArgumentException(msg);
/*      */           } 
/*      */         } 
/*      */         
/* 1319 */         if (value == null) {
/* 1320 */           value = initializeField(structField.field, type);
/*      */         }
/*      */         
/*      */         try {
/* 1324 */           structField.size = getNativeSize(nativeType, value);
/* 1325 */           fieldAlignment = getNativeAlignment(nativeType, value, firstField);
/*      */         }
/* 1327 */         catch (IllegalArgumentException e) {
/*      */           
/* 1329 */           if (!force && this.typeMapper == null) {
/* 1330 */             return null;
/*      */           }
/* 1332 */           String msg = "Invalid Structure field in " + getClass() + ", field name '" + structField.name + "' (" + structField.type + "): " + e.getMessage();
/* 1333 */           throw new IllegalArgumentException(msg, e);
/*      */         } 
/*      */ 
/*      */         
/* 1337 */         if (fieldAlignment == 0) {
/* 1338 */           throw new Error("Field alignment is zero for field '" + structField.name + "' within " + getClass());
/*      */         }
/* 1340 */         info.alignment = Math.max(info.alignment, fieldAlignment);
/* 1341 */         if (calculatedSize % fieldAlignment != 0) {
/* 1342 */           calculatedSize += fieldAlignment - calculatedSize % fieldAlignment;
/*      */         }
/* 1344 */         if (this instanceof Union) {
/* 1345 */           structField.offset = 0;
/* 1346 */           calculatedSize = Math.max(calculatedSize, structField.size);
/*      */         } else {
/*      */           
/* 1349 */           structField.offset = calculatedSize;
/* 1350 */           calculatedSize += structField.size;
/*      */         } 
/*      */ 
/*      */         
/* 1354 */         info.fields.put(structField.name, structField);
/*      */         
/* 1356 */         if (info.typeInfoField == null || 
/* 1357 */           info.typeInfoField.size < structField.size || (
/* 1358 */           info.typeInfoField.size == structField.size && Structure.class
/* 1359 */           .isAssignableFrom(structField.type))) {
/* 1360 */           info.typeInfoField = structField;
/*      */         }
/*      */       } 
/*      */     } 
/* 1364 */     if (calculatedSize > 0) {
/* 1365 */       int size = addPadding(calculatedSize, info.alignment);
/*      */       
/* 1367 */       if (this instanceof ByValue && !avoidFFIType) {
/* 1368 */         getTypeInfo();
/*      */       }
/* 1370 */       info.size = size;
/* 1371 */       return info;
/*      */     } 
/*      */     
/* 1374 */     throw new IllegalArgumentException("Structure " + getClass() + " has unknown or zero size (ensure all fields are public)");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void initializeFields() {
/* 1386 */     List<Field> flist = getFieldList();
/* 1387 */     for (Field f : flist) {
/*      */       try {
/* 1389 */         Object o = f.get(this);
/* 1390 */         if (o == null) {
/* 1391 */           initializeField(f, f.getType());
/*      */         }
/*      */       }
/* 1394 */       catch (Exception e) {
/* 1395 */         throw new Error("Exception reading field '" + f.getName() + "' in " + getClass(), e);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private Object initializeField(Field field, Class<?> type) {
/* 1401 */     Object value = null;
/* 1402 */     if (Structure.class.isAssignableFrom(type) && 
/* 1403 */       !ByReference.class.isAssignableFrom(type)) {
/*      */       try {
/* 1405 */         value = newInstance(type, PLACEHOLDER_MEMORY);
/* 1406 */         setFieldValue(field, value);
/*      */       }
/* 1408 */       catch (IllegalArgumentException e) {
/* 1409 */         String msg = "Can't determine size of nested structure";
/* 1410 */         throw new IllegalArgumentException(msg, e);
/*      */       }
/*      */     
/* 1413 */     } else if (NativeMapped.class.isAssignableFrom(type)) {
/* 1414 */       NativeMappedConverter tc = NativeMappedConverter.getInstance(type);
/* 1415 */       value = tc.defaultValue();
/* 1416 */       setFieldValue(field, value);
/*      */     } 
/* 1418 */     return value;
/*      */   }
/*      */   
/*      */   private int addPadding(int calculatedSize) {
/* 1422 */     return addPadding(calculatedSize, this.structAlignment);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private int addPadding(int calculatedSize, int alignment) {
/* 1428 */     if (this.actualAlignType != 1 && 
/* 1429 */       calculatedSize % alignment != 0) {
/* 1430 */       calculatedSize += alignment - calculatedSize % alignment;
/*      */     }
/*      */     
/* 1433 */     return calculatedSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int getStructAlignment() {
/* 1440 */     if (this.size == -1)
/*      */     {
/* 1442 */       calculateSize(true);
/*      */     }
/* 1444 */     return this.structAlignment;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int getNativeAlignment(Class<?> type, Object value, boolean isFirstElement) {
/* 1458 */     int alignment = 1;
/* 1459 */     if (NativeMapped.class.isAssignableFrom(type)) {
/* 1460 */       NativeMappedConverter tc = NativeMappedConverter.getInstance(type);
/* 1461 */       type = tc.nativeType();
/* 1462 */       value = tc.toNative(value, new ToNativeContext());
/*      */     } 
/* 1464 */     int size = Native.getNativeSize(type, value);
/* 1465 */     if (type.isPrimitive() || Long.class == type || Integer.class == type || Short.class == type || Character.class == type || Byte.class == type || Boolean.class == type || Float.class == type || Double.class == type) {
/*      */ 
/*      */ 
/*      */       
/* 1469 */       alignment = size;
/*      */     }
/* 1471 */     else if ((Pointer.class.isAssignableFrom(type) && !Function.class.isAssignableFrom(type)) || (Platform.HAS_BUFFERS && Buffer.class
/* 1472 */       .isAssignableFrom(type)) || Callback.class
/* 1473 */       .isAssignableFrom(type) || WString.class == type || String.class == type) {
/*      */ 
/*      */       
/* 1476 */       alignment = Native.POINTER_SIZE;
/*      */     }
/* 1478 */     else if (Structure.class.isAssignableFrom(type)) {
/* 1479 */       if (ByReference.class.isAssignableFrom(type)) {
/* 1480 */         alignment = Native.POINTER_SIZE;
/*      */       } else {
/*      */         
/* 1483 */         if (value == null)
/* 1484 */           value = newInstance(type, PLACEHOLDER_MEMORY); 
/* 1485 */         alignment = ((Structure)value).getStructAlignment();
/*      */       }
/*      */     
/* 1488 */     } else if (type.isArray()) {
/* 1489 */       alignment = getNativeAlignment(type.getComponentType(), null, isFirstElement);
/*      */     } else {
/*      */       
/* 1492 */       throw new IllegalArgumentException("Type " + type + " has unknown native alignment");
/*      */     } 
/*      */     
/* 1495 */     if (this.actualAlignType == 1) {
/* 1496 */       alignment = 1;
/*      */     }
/* 1498 */     else if (this.actualAlignType == 3) {
/* 1499 */       alignment = Math.min(8, alignment);
/*      */     }
/* 1501 */     else if (this.actualAlignType == 2) {
/*      */ 
/*      */       
/* 1504 */       if (!isFirstElement || !Platform.isMac() || !Platform.isPPC()) {
/* 1505 */         alignment = Math.min(Native.MAX_ALIGNMENT, alignment);
/*      */       }
/* 1507 */       if (!isFirstElement && Platform.isAIX() && (type == double.class || type == Double.class)) {
/* 1508 */         alignment = 4;
/*      */       }
/*      */     } 
/* 1511 */     return alignment;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1521 */     return toString(Boolean.getBoolean("jna.dump_memory"));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString(boolean debug) {
/* 1530 */     return toString(0, true, debug);
/*      */   }
/*      */   
/*      */   private String format(Class<?> type) {
/* 1534 */     String s = type.getName();
/* 1535 */     int dot = s.lastIndexOf(".");
/* 1536 */     return s.substring(dot + 1);
/*      */   }
/*      */   
/*      */   private String toString(int indent, boolean showContents, boolean dumpMemory) {
/* 1540 */     ensureAllocated();
/* 1541 */     String LS = System.getProperty("line.separator");
/* 1542 */     String name = format(getClass()) + "(" + getPointer() + ")";
/* 1543 */     if (!(getPointer() instanceof Memory)) {
/* 1544 */       name = name + " (" + size() + " bytes)";
/*      */     }
/* 1546 */     String prefix = "";
/* 1547 */     for (int idx = 0; idx < indent; idx++) {
/* 1548 */       prefix = prefix + "  ";
/*      */     }
/* 1550 */     String contents = LS;
/* 1551 */     if (!showContents) {
/* 1552 */       contents = "...}";
/*      */     } else {
/* 1554 */       for (Iterator<StructField> i = fields().values().iterator(); i.hasNext(); ) {
/* 1555 */         StructField sf = i.next();
/* 1556 */         Object value = getFieldValue(sf.field);
/* 1557 */         String type = format(sf.type);
/* 1558 */         String index = "";
/* 1559 */         contents = contents + prefix;
/* 1560 */         if (sf.type.isArray() && value != null) {
/* 1561 */           type = format(sf.type.getComponentType());
/* 1562 */           index = "[" + Array.getLength(value) + "]";
/*      */         } 
/* 1564 */         contents = contents + String.format("  %s %s%s@0x%X", new Object[] { type, sf.name, index, Integer.valueOf(sf.offset) });
/* 1565 */         if (value instanceof Structure) {
/* 1566 */           value = ((Structure)value).toString(indent + 1, !(value instanceof ByReference), dumpMemory);
/*      */         }
/* 1568 */         contents = contents + "=";
/* 1569 */         if (value instanceof Long) {
/* 1570 */           contents = contents + String.format("0x%08X", new Object[] { value });
/*      */         }
/* 1572 */         else if (value instanceof Integer) {
/* 1573 */           contents = contents + String.format("0x%04X", new Object[] { value });
/*      */         }
/* 1575 */         else if (value instanceof Short) {
/* 1576 */           contents = contents + String.format("0x%02X", new Object[] { value });
/*      */         }
/* 1578 */         else if (value instanceof Byte) {
/* 1579 */           contents = contents + String.format("0x%01X", new Object[] { value });
/*      */         } else {
/*      */           
/* 1582 */           contents = contents + String.valueOf(value).trim();
/*      */         } 
/* 1584 */         contents = contents + LS;
/* 1585 */         if (!i.hasNext())
/* 1586 */           contents = contents + prefix + "}"; 
/*      */       } 
/* 1588 */     }  if (indent == 0 && dumpMemory) {
/* 1589 */       int BYTES_PER_ROW = 4;
/* 1590 */       contents = contents + LS + "memory dump" + LS;
/* 1591 */       byte[] buf = getPointer().getByteArray(0L, size());
/* 1592 */       for (int i = 0; i < buf.length; i++) {
/* 1593 */         if (i % 4 == 0) contents = contents + "["; 
/* 1594 */         if (buf[i] >= 0 && buf[i] < 16)
/* 1595 */           contents = contents + "0"; 
/* 1596 */         contents = contents + Integer.toHexString(buf[i] & 0xFF);
/* 1597 */         if (i % 4 == 3 && i < buf.length - 1)
/* 1598 */           contents = contents + "]" + LS; 
/*      */       } 
/* 1600 */       contents = contents + "]";
/*      */     } 
/* 1602 */     return name + " {" + contents;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Structure[] toArray(Structure[] array) {
/* 1614 */     ensureAllocated();
/* 1615 */     if (this.memory instanceof AutoAllocated) {
/*      */       
/* 1617 */       Memory m = (Memory)this.memory;
/* 1618 */       int requiredSize = array.length * size();
/* 1619 */       if (m.size() < requiredSize) {
/* 1620 */         useMemory(autoAllocate(requiredSize));
/*      */       }
/*      */     } 
/*      */     
/* 1624 */     array[0] = this;
/* 1625 */     int size = size();
/* 1626 */     for (int i = 1; i < array.length; i++) {
/* 1627 */       array[i] = newInstance(getClass(), this.memory.share((i * size), size));
/* 1628 */       array[i].conditionalAutoRead();
/*      */     } 
/*      */     
/* 1631 */     if (!(this instanceof ByValue))
/*      */     {
/* 1633 */       this.array = array;
/*      */     }
/*      */     
/* 1636 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Structure[] toArray(int size) {
/* 1649 */     return toArray((Structure[])Array.newInstance(getClass(), size));
/*      */   }
/*      */   
/*      */   private Class<?> baseClass() {
/* 1653 */     if ((this instanceof ByReference || this instanceof ByValue) && Structure.class
/*      */       
/* 1655 */       .isAssignableFrom(getClass().getSuperclass())) {
/* 1656 */       return getClass().getSuperclass();
/*      */     }
/* 1658 */     return getClass();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean dataEquals(Structure s) {
/* 1667 */     return dataEquals(s, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean dataEquals(Structure s, boolean clear) {
/* 1677 */     if (clear) {
/* 1678 */       s.getPointer().clear(s.size());
/* 1679 */       s.write();
/* 1680 */       getPointer().clear(size());
/* 1681 */       write();
/*      */     } 
/* 1683 */     byte[] data = s.getPointer().getByteArray(0L, s.size());
/* 1684 */     byte[] ref = getPointer().getByteArray(0L, size());
/* 1685 */     if (data.length == ref.length) {
/* 1686 */       for (int i = 0; i < data.length; i++) {
/* 1687 */         if (data[i] != ref[i]) {
/* 1688 */           return false;
/*      */         }
/*      */       } 
/* 1691 */       return true;
/*      */     } 
/* 1693 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object o) {
/* 1701 */     return (o instanceof Structure && o
/* 1702 */       .getClass() == getClass() && ((Structure)o)
/* 1703 */       .getPointer().equals(getPointer()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/* 1711 */     Pointer p = getPointer();
/* 1712 */     if (p != null) {
/* 1713 */       return getPointer().hashCode();
/*      */     }
/* 1715 */     return getClass().hashCode();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void cacheTypeInfo(Pointer p) {
/* 1722 */     this.typeInfo = p.peer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Pointer getFieldTypeInfo(StructField f) {
/* 1730 */     Class<?> type = f.type;
/* 1731 */     Object value = getFieldValue(f.field);
/* 1732 */     if (this.typeMapper != null) {
/* 1733 */       ToNativeConverter nc = this.typeMapper.getToNativeConverter(type);
/* 1734 */       if (nc != null) {
/* 1735 */         type = nc.nativeType();
/* 1736 */         value = nc.toNative(value, new ToNativeContext());
/*      */       } 
/*      */     } 
/* 1739 */     return FFIType.get(value, type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Pointer getTypeInfo() {
/* 1746 */     Pointer p = getTypeInfo(this);
/* 1747 */     cacheTypeInfo(p);
/* 1748 */     return p;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAutoSynch(boolean auto) {
/* 1772 */     setAutoRead(auto);
/* 1773 */     setAutoWrite(auto);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAutoRead(boolean auto) {
/* 1781 */     this.autoRead = auto;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getAutoRead() {
/* 1789 */     return this.autoRead;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAutoWrite(boolean auto) {
/* 1797 */     this.autoWrite = auto;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getAutoWrite() {
/* 1805 */     return this.autoWrite;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Pointer getTypeInfo(Object obj) {
/* 1813 */     return FFIType.get(obj);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static <T extends Structure> T newInstance(Class<T> type, long init) {
/*      */     try {
/* 1822 */       T s = newInstance(type, (init == 0L) ? PLACEHOLDER_MEMORY : new Pointer(init));
/* 1823 */       if (init != 0L) {
/* 1824 */         s.conditionalAutoRead();
/*      */       }
/* 1826 */       return s;
/*      */     }
/* 1828 */     catch (Throwable e) {
/* 1829 */       LOG.log(Level.WARNING, "JNA: Error creating structure", e);
/* 1830 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Structure> T newInstance(Class<T> type, Pointer init) throws IllegalArgumentException {
/*      */     try {
/* 1843 */       Constructor<T> ctor = type.getConstructor(new Class[] { Pointer.class });
/* 1844 */       return ctor.newInstance(new Object[] { init });
/*      */     }
/* 1846 */     catch (NoSuchMethodException noSuchMethodException) {
/*      */ 
/*      */     
/* 1849 */     } catch (SecurityException securityException) {
/*      */ 
/*      */     
/* 1852 */     } catch (InstantiationException e) {
/* 1853 */       String msg = "Can't instantiate " + type;
/* 1854 */       throw new IllegalArgumentException(msg, e);
/*      */     }
/* 1856 */     catch (IllegalAccessException e) {
/* 1857 */       String msg = "Instantiation of " + type + " (Pointer) not allowed, is it public?";
/* 1858 */       throw new IllegalArgumentException(msg, e);
/*      */     }
/* 1860 */     catch (InvocationTargetException e) {
/* 1861 */       String msg = "Exception thrown while instantiating an instance of " + type;
/* 1862 */       throw new IllegalArgumentException(msg, e);
/*      */     } 
/* 1864 */     T s = newInstance(type);
/* 1865 */     if (init != PLACEHOLDER_MEMORY) {
/* 1866 */       s.useMemory(init);
/*      */     }
/* 1868 */     return s;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Structure> T newInstance(Class<T> type) throws IllegalArgumentException {
/* 1878 */     Structure structure = Klass.<Structure>newInstance(type);
/* 1879 */     if (structure instanceof ByValue) {
/* 1880 */       structure.allocateMemory();
/*      */     }
/* 1882 */     return (T)structure;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   StructField typeInfoField() {
/*      */     LayoutInfo info;
/* 1891 */     synchronized (layoutInfo) {
/* 1892 */       info = layoutInfo.get(getClass());
/*      */     } 
/* 1894 */     if (info != null) {
/* 1895 */       return info.typeInfoField;
/*      */     }
/* 1897 */     return null;
/*      */   }
/*      */   
/*      */   protected static class StructField {
/*      */     public String name;
/*      */     public Class<?> type;
/*      */     public Field field;
/* 1904 */     public int size = -1;
/* 1905 */     public int offset = -1;
/*      */     public boolean isVolatile;
/*      */     public boolean isReadOnly;
/*      */     public FromNativeConverter readConverter;
/*      */     public ToNativeConverter writeConverter;
/*      */     public FromNativeContext context;
/*      */     
/*      */     public String toString() {
/* 1913 */       return this.name + "@" + this.offset + "[" + this.size + "] (" + this.type + ")";
/*      */     }
/*      */   }
/*      */   
/*      */   @FieldOrder({"size", "alignment", "type", "elements"})
/*      */   static class FFIType
/*      */     extends Structure {
/*      */     public static class size_t
/*      */       extends IntegerType {
/*      */       private static final long serialVersionUID = 1L;
/*      */       
/*      */       public size_t() {
/* 1925 */         this(0L); } public size_t(long value) {
/* 1926 */         super(Native.SIZE_T_SIZE, value);
/*      */       }
/*      */     }
/* 1929 */     private static final Map<Object, Object> typeInfoMap = new WeakHashMap<Object, Object>(); private static final int FFI_TYPE_STRUCT = 13;
/*      */     public size_t size;
/*      */     public short alignment;
/*      */     public short type;
/*      */     public Pointer elements;
/*      */     
/*      */     private static class FFITypes {
/*      */       private static Pointer ffi_type_void;
/*      */       private static Pointer ffi_type_float;
/*      */       private static Pointer ffi_type_double;
/*      */       private static Pointer ffi_type_longdouble;
/*      */       private static Pointer ffi_type_uint8;
/*      */       private static Pointer ffi_type_sint8;
/*      */       private static Pointer ffi_type_uint16;
/*      */       private static Pointer ffi_type_sint16;
/*      */       private static Pointer ffi_type_uint32;
/*      */       private static Pointer ffi_type_sint32;
/*      */       private static Pointer ffi_type_uint64;
/*      */       private static Pointer ffi_type_sint64;
/*      */       private static Pointer ffi_type_pointer; }
/*      */     
/*      */     static {
/* 1951 */       if (Native.POINTER_SIZE == 0)
/* 1952 */         throw new Error("Native library not initialized"); 
/* 1953 */       if (FFITypes.ffi_type_void == null)
/* 1954 */         throw new Error("FFI types not initialized"); 
/* 1955 */       typeInfoMap.put(void.class, FFITypes.ffi_type_void);
/* 1956 */       typeInfoMap.put(Void.class, FFITypes.ffi_type_void);
/* 1957 */       typeInfoMap.put(float.class, FFITypes.ffi_type_float);
/* 1958 */       typeInfoMap.put(Float.class, FFITypes.ffi_type_float);
/* 1959 */       typeInfoMap.put(double.class, FFITypes.ffi_type_double);
/* 1960 */       typeInfoMap.put(Double.class, FFITypes.ffi_type_double);
/* 1961 */       typeInfoMap.put(long.class, FFITypes.ffi_type_sint64);
/* 1962 */       typeInfoMap.put(Long.class, FFITypes.ffi_type_sint64);
/* 1963 */       typeInfoMap.put(int.class, FFITypes.ffi_type_sint32);
/* 1964 */       typeInfoMap.put(Integer.class, FFITypes.ffi_type_sint32);
/* 1965 */       typeInfoMap.put(short.class, FFITypes.ffi_type_sint16);
/* 1966 */       typeInfoMap.put(Short.class, FFITypes.ffi_type_sint16);
/*      */       
/* 1968 */       Pointer ctype = (Native.WCHAR_SIZE == 2) ? FFITypes.ffi_type_uint16 : FFITypes.ffi_type_uint32;
/* 1969 */       typeInfoMap.put(char.class, ctype);
/* 1970 */       typeInfoMap.put(Character.class, ctype);
/* 1971 */       typeInfoMap.put(byte.class, FFITypes.ffi_type_sint8);
/* 1972 */       typeInfoMap.put(Byte.class, FFITypes.ffi_type_sint8);
/* 1973 */       typeInfoMap.put(Pointer.class, FFITypes.ffi_type_pointer);
/* 1974 */       typeInfoMap.put(String.class, FFITypes.ffi_type_pointer);
/* 1975 */       typeInfoMap.put(WString.class, FFITypes.ffi_type_pointer);
/* 1976 */       typeInfoMap.put(boolean.class, FFITypes.ffi_type_uint32);
/* 1977 */       typeInfoMap.put(Boolean.class, FFITypes.ffi_type_uint32);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private FFIType(Structure ref) {
/*      */       Pointer[] els;
/* 1984 */       this.type = 13;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1989 */       ref.ensureAllocated(true);
/*      */       
/* 1991 */       if (ref instanceof Union) {
/* 1992 */         Structure.StructField sf = ((Union)ref).typeInfoField();
/*      */         
/* 1994 */         els = new Pointer[] { get(ref.getFieldValue(sf.field), sf.type), null };
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 1999 */         els = new Pointer[ref.fields().size() + 1];
/* 2000 */         int idx = 0;
/* 2001 */         for (Structure.StructField sf : ref.fields().values()) {
/* 2002 */           els[idx++] = ref.getFieldTypeInfo(sf);
/*      */         }
/*      */       } 
/* 2005 */       init(els);
/*      */     }
/*      */     private FFIType(Object array, Class<?> type) {
/*      */       this.type = 13;
/* 2009 */       int length = Array.getLength(array);
/* 2010 */       Pointer[] els = new Pointer[length + 1];
/* 2011 */       Pointer p = get((Object)null, type.getComponentType());
/* 2012 */       for (int i = 0; i < length; i++) {
/* 2013 */         els[i] = p;
/*      */       }
/* 2015 */       init(els);
/*      */     }
/*      */     
/*      */     private void init(Pointer[] els) {
/* 2019 */       this.elements = new Memory((Native.POINTER_SIZE * els.length));
/* 2020 */       this.elements.write(0L, els, 0, els.length);
/* 2021 */       write();
/*      */     }
/*      */ 
/*      */     
/*      */     static Pointer get(Object obj) {
/* 2026 */       if (obj == null)
/* 2027 */         return FFITypes.ffi_type_pointer; 
/* 2028 */       if (obj instanceof Class)
/* 2029 */         return get((Object)null, (Class)obj); 
/* 2030 */       return get(obj, obj.getClass());
/*      */     }
/*      */     
/*      */     private static Pointer get(Object obj, Class<?> cls) {
/* 2034 */       TypeMapper mapper = Native.getTypeMapper(cls);
/* 2035 */       if (mapper != null) {
/* 2036 */         ToNativeConverter nc = mapper.getToNativeConverter(cls);
/* 2037 */         if (nc != null) {
/* 2038 */           cls = nc.nativeType();
/*      */         }
/*      */       } 
/* 2041 */       synchronized (typeInfoMap) {
/* 2042 */         Object o = typeInfoMap.get(cls);
/* 2043 */         if (o instanceof Pointer) {
/* 2044 */           return (Pointer)o;
/*      */         }
/* 2046 */         if (o instanceof FFIType) {
/* 2047 */           return ((FFIType)o).getPointer();
/*      */         }
/* 2049 */         if ((Platform.HAS_BUFFERS && Buffer.class.isAssignableFrom(cls)) || Callback.class
/* 2050 */           .isAssignableFrom(cls)) {
/* 2051 */           typeInfoMap.put(cls, FFITypes.ffi_type_pointer);
/* 2052 */           return FFITypes.ffi_type_pointer;
/*      */         } 
/* 2054 */         if (Structure.class.isAssignableFrom(cls)) {
/* 2055 */           if (obj == null) obj = newInstance(cls, Structure.PLACEHOLDER_MEMORY); 
/* 2056 */           if (Structure.ByReference.class.isAssignableFrom(cls)) {
/* 2057 */             typeInfoMap.put(cls, FFITypes.ffi_type_pointer);
/* 2058 */             return FFITypes.ffi_type_pointer;
/*      */           } 
/* 2060 */           FFIType type = new FFIType((Structure)obj);
/* 2061 */           typeInfoMap.put(cls, type);
/* 2062 */           return type.getPointer();
/*      */         } 
/* 2064 */         if (NativeMapped.class.isAssignableFrom(cls)) {
/* 2065 */           NativeMappedConverter c = NativeMappedConverter.getInstance(cls);
/* 2066 */           return get(c.toNative(obj, new ToNativeContext()), c.nativeType());
/*      */         } 
/* 2068 */         if (cls.isArray()) {
/* 2069 */           FFIType type = new FFIType(obj, cls);
/*      */           
/* 2071 */           typeInfoMap.put(obj, type);
/* 2072 */           return type.getPointer();
/*      */         } 
/* 2074 */         throw new IllegalArgumentException("Unsupported type " + cls);
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   private static class AutoAllocated extends Memory {
/*      */     public AutoAllocated(int size) {
/* 2081 */       super(size);
/*      */       
/* 2083 */       clear();
/*      */     }
/*      */     
/*      */     public String toString() {
/* 2087 */       return "auto-" + super.toString();
/*      */     }
/*      */   }
/*      */   
/*      */   private static void structureArrayCheck(Structure[] ss) {
/* 2092 */     if (ByReference[].class.isAssignableFrom(ss.getClass())) {
/*      */       return;
/*      */     }
/* 2095 */     Pointer base = ss[0].getPointer();
/* 2096 */     int size = ss[0].size();
/* 2097 */     for (int si = 1; si < ss.length; si++) {
/* 2098 */       if ((ss[si].getPointer()).peer != base.peer + (size * si)) {
/* 2099 */         String msg = "Structure array elements must use contiguous memory (bad backing address at Structure array index " + si + ")";
/*      */         
/* 2101 */         throw new IllegalArgumentException(msg);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void autoRead(Structure[] ss) {
/* 2107 */     structureArrayCheck(ss);
/* 2108 */     if ((ss[0]).array == ss) {
/* 2109 */       ss[0].autoRead();
/*      */     } else {
/*      */       
/* 2112 */       for (int si = 0; si < ss.length; si++) {
/* 2113 */         if (ss[si] != null) {
/* 2114 */           ss[si].autoRead();
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public void autoRead() {
/* 2121 */     if (getAutoRead()) {
/* 2122 */       read();
/* 2123 */       if (this.array != null) {
/* 2124 */         for (int i = 1; i < this.array.length; i++) {
/* 2125 */           this.array[i].autoRead();
/*      */         }
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void autoWrite(Structure[] ss) {
/* 2132 */     structureArrayCheck(ss);
/* 2133 */     if ((ss[0]).array == ss) {
/* 2134 */       ss[0].autoWrite();
/*      */     } else {
/*      */       
/* 2137 */       for (int si = 0; si < ss.length; si++) {
/* 2138 */         if (ss[si] != null) {
/* 2139 */           ss[si].autoWrite();
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public void autoWrite() {
/* 2146 */     if (getAutoWrite()) {
/* 2147 */       write();
/* 2148 */       if (this.array != null) {
/* 2149 */         for (int i = 1; i < this.array.length; i++) {
/* 2150 */           this.array[i].autoWrite();
/*      */         }
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int getNativeSize(Class<?> nativeType) {
/* 2162 */     return getNativeSize(nativeType, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int getNativeSize(Class<?> nativeType, Object value) {
/* 2172 */     return Native.getNativeSize(nativeType, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2178 */   private static final Pointer PLACEHOLDER_MEMORY = new Pointer(0L) {
/*      */       public Pointer share(long offset, long sz) {
/* 2180 */         return this;
/*      */       }
/*      */     };
/*      */ 
/*      */ 
/*      */   
/*      */   static void validate(Class<? extends Structure> cls) {
/*      */     try {
/* 2188 */       cls.getConstructor(new Class[0]);
/*      */       return;
/* 2190 */     } catch (NoSuchMethodException noSuchMethodException) {
/*      */     
/* 2192 */     } catch (SecurityException securityException) {}
/*      */     
/* 2194 */     throw new IllegalArgumentException("No suitable constructor found for class: " + cls.getName());
/*      */   }
/*      */   
/*      */   @Documented
/*      */   @Retention(RetentionPolicy.RUNTIME)
/*      */   @Target({ElementType.TYPE})
/*      */   public static @interface FieldOrder {
/*      */     String[] value();
/*      */   }
/*      */   
/*      */   public static interface ByReference {}
/*      */   
/*      */   public static interface ByValue {}
/*      */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\com\sun\jna\Structure.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */