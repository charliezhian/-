package com.sun.jna;

import java.lang.reflect.Method;

public interface FunctionMapper {
  String getFunctionName(NativeLibrary paramNativeLibrary, Method paramMethod);
}


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\com\sun\jna\FunctionMapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */