/*      */ package com.sun.jna.platform;
/*      */ 
/*      */ import com.sun.jna.Memory;
/*      */ import com.sun.jna.Native;
/*      */ import com.sun.jna.NativeLong;
/*      */ import com.sun.jna.Platform;
/*      */ import com.sun.jna.Pointer;
/*      */ import com.sun.jna.platform.unix.X11;
/*      */ import com.sun.jna.platform.win32.GDI32;
/*      */ import com.sun.jna.platform.win32.Kernel32;
/*      */ import com.sun.jna.platform.win32.Psapi;
/*      */ import com.sun.jna.platform.win32.User32;
/*      */ import com.sun.jna.platform.win32.Win32Exception;
/*      */ import com.sun.jna.platform.win32.WinDef;
/*      */ import com.sun.jna.platform.win32.WinGDI;
/*      */ import com.sun.jna.platform.win32.WinNT;
/*      */ import com.sun.jna.platform.win32.WinUser;
/*      */ import com.sun.jna.ptr.ByteByReference;
/*      */ import com.sun.jna.ptr.IntByReference;
/*      */ import com.sun.jna.ptr.PointerByReference;
/*      */ import java.awt.AWTEvent;
/*      */ import java.awt.AlphaComposite;
/*      */ import java.awt.BorderLayout;
/*      */ import java.awt.Color;
/*      */ import java.awt.Component;
/*      */ import java.awt.Container;
/*      */ import java.awt.Dialog;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.Frame;
/*      */ import java.awt.Graphics;
/*      */ import java.awt.Graphics2D;
/*      */ import java.awt.GraphicsConfiguration;
/*      */ import java.awt.GraphicsDevice;
/*      */ import java.awt.GraphicsEnvironment;
/*      */ import java.awt.Point;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.Shape;
/*      */ import java.awt.Toolkit;
/*      */ import java.awt.Window;
/*      */ import java.awt.event.AWTEventListener;
/*      */ import java.awt.event.ComponentEvent;
/*      */ import java.awt.event.ComponentListener;
/*      */ import java.awt.event.ContainerEvent;
/*      */ import java.awt.event.HierarchyEvent;
/*      */ import java.awt.event.HierarchyListener;
/*      */ import java.awt.event.MouseEvent;
/*      */ import java.awt.event.WindowAdapter;
/*      */ import java.awt.event.WindowEvent;
/*      */ import java.awt.geom.Area;
/*      */ import java.awt.geom.PathIterator;
/*      */ import java.awt.image.BufferedImage;
/*      */ import java.awt.image.Raster;
/*      */ import java.lang.reflect.Method;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ import javax.swing.Icon;
/*      */ import javax.swing.JComponent;
/*      */ import javax.swing.JLayeredPane;
/*      */ import javax.swing.JPanel;
/*      */ import javax.swing.JRootPane;
/*      */ import javax.swing.RootPaneContainer;
/*      */ import javax.swing.SwingUtilities;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class WindowUtils
/*      */ {
/*  164 */   private static final Logger LOG = Logger.getLogger(WindowUtils.class.getName());
/*      */   
/*      */   private static final String TRANSPARENT_OLD_BG = "transparent-old-bg";
/*      */   
/*      */   private static final String TRANSPARENT_OLD_OPAQUE = "transparent-old-opaque";
/*      */   
/*      */   private static final String TRANSPARENT_ALPHA = "transparent-alpha";
/*  171 */   public static final Shape MASK_NONE = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class HeavyweightForcer
/*      */     extends Window
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final boolean packed;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HeavyweightForcer(Window parent) {
/*  193 */       super(parent);
/*  194 */       pack();
/*  195 */       this.packed = true;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isVisible() {
/*  203 */       return this.packed;
/*      */     }
/*      */ 
/*      */     
/*      */     public Rectangle getBounds() {
/*  208 */       return getOwner().getBounds();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   protected static class RepaintTrigger
/*      */     extends JComponent
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     
/*      */     protected class Listener
/*      */       extends WindowAdapter
/*      */       implements ComponentListener, HierarchyListener, AWTEventListener
/*      */     {
/*      */       public void windowOpened(WindowEvent e) {
/*  224 */         WindowUtils.RepaintTrigger.this.repaint();
/*      */       }
/*      */ 
/*      */       
/*      */       public void componentHidden(ComponentEvent e) {}
/*      */ 
/*      */       
/*      */       public void componentMoved(ComponentEvent e) {}
/*      */ 
/*      */       
/*      */       public void componentResized(ComponentEvent e) {
/*  235 */         WindowUtils.RepaintTrigger.this.setSize(WindowUtils.RepaintTrigger.this.getParent().getSize());
/*  236 */         WindowUtils.RepaintTrigger.this.repaint();
/*      */       }
/*      */ 
/*      */       
/*      */       public void componentShown(ComponentEvent e) {
/*  241 */         WindowUtils.RepaintTrigger.this.repaint();
/*      */       }
/*      */ 
/*      */       
/*      */       public void hierarchyChanged(HierarchyEvent e) {
/*  246 */         WindowUtils.RepaintTrigger.this.repaint();
/*      */       }
/*      */ 
/*      */       
/*      */       public void eventDispatched(AWTEvent e) {
/*  251 */         if (e instanceof MouseEvent) {
/*  252 */           Component src = ((MouseEvent)e).getComponent();
/*  253 */           if (src != null && 
/*  254 */             SwingUtilities.isDescendingFrom(src, WindowUtils.RepaintTrigger.this.content)) {
/*  255 */             MouseEvent me = SwingUtilities.convertMouseEvent(src, (MouseEvent)e, WindowUtils.RepaintTrigger.this.content);
/*  256 */             Component c = SwingUtilities.getDeepestComponentAt(WindowUtils.RepaintTrigger.this.content, me.getX(), me.getY());
/*  257 */             if (c != null) {
/*  258 */               WindowUtils.RepaintTrigger.this.setCursor(c.getCursor());
/*      */             }
/*      */           } 
/*      */         } 
/*      */       }
/*      */     }
/*      */     
/*  265 */     private final Listener listener = createListener(); private final JComponent content;
/*      */     private Rectangle dirty;
/*      */     
/*      */     public RepaintTrigger(JComponent content) {
/*  269 */       this.content = content;
/*      */     }
/*      */ 
/*      */     
/*      */     public void addNotify() {
/*  274 */       super.addNotify();
/*  275 */       Window w = SwingUtilities.getWindowAncestor(this);
/*  276 */       setSize(getParent().getSize());
/*  277 */       w.addComponentListener(this.listener);
/*  278 */       w.addWindowListener(this.listener);
/*  279 */       Toolkit.getDefaultToolkit().addAWTEventListener(this.listener, 48L);
/*      */     }
/*      */ 
/*      */     
/*      */     public void removeNotify() {
/*  284 */       Toolkit.getDefaultToolkit().removeAWTEventListener(this.listener);
/*  285 */       Window w = SwingUtilities.getWindowAncestor(this);
/*  286 */       w.removeComponentListener(this.listener);
/*  287 */       w.removeWindowListener(this.listener);
/*  288 */       super.removeNotify();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     protected void paintComponent(Graphics g) {
/*  294 */       Rectangle bounds = g.getClipBounds();
/*  295 */       if (this.dirty == null || !this.dirty.contains(bounds)) {
/*  296 */         if (this.dirty == null) {
/*  297 */           this.dirty = bounds;
/*      */         } else {
/*      */           
/*  300 */           this.dirty = this.dirty.union(bounds);
/*      */         } 
/*  302 */         this.content.repaint(this.dirty);
/*      */       } else {
/*      */         
/*  305 */         this.dirty = null;
/*      */       } 
/*      */     }
/*      */     
/*      */     protected Listener createListener() {
/*  310 */       return new Listener();
/*      */     }
/*      */   }
/*      */   
/*      */   public static abstract class NativeWindowUtils {
/*      */     protected abstract class TransparentContentPane
/*      */       extends JPanel implements AWTEventListener {
/*      */       private static final long serialVersionUID = 1L;
/*      */       private boolean transparent;
/*      */       
/*      */       public TransparentContentPane(Container oldContent) {
/*  321 */         super(new BorderLayout());
/*  322 */         add(oldContent, "Center");
/*  323 */         setTransparent(true);
/*  324 */         if (oldContent instanceof JPanel) {
/*  325 */           ((JComponent)oldContent).setOpaque(false);
/*      */         }
/*      */       }
/*      */       
/*      */       public void addNotify() {
/*  330 */         super.addNotify();
/*  331 */         Toolkit.getDefaultToolkit().addAWTEventListener(this, 2L);
/*      */       }
/*      */       
/*      */       public void removeNotify() {
/*  335 */         Toolkit.getDefaultToolkit().removeAWTEventListener(this);
/*  336 */         super.removeNotify();
/*      */       }
/*      */       public void setTransparent(boolean transparent) {
/*  339 */         this.transparent = transparent;
/*  340 */         setOpaque(!transparent);
/*  341 */         setDoubleBuffered(!transparent);
/*  342 */         repaint();
/*      */       }
/*      */       
/*      */       public void eventDispatched(AWTEvent e) {
/*  346 */         if (e.getID() == 300 && 
/*  347 */           SwingUtilities.isDescendingFrom(((ContainerEvent)e).getChild(), this)) {
/*  348 */           Component child = ((ContainerEvent)e).getChild();
/*  349 */           WindowUtils.NativeWindowUtils.this.setDoubleBuffered(child, false);
/*      */         } 
/*      */       }
/*      */       
/*      */       public void paint(Graphics gr) {
/*  354 */         if (this.transparent) {
/*  355 */           Rectangle r = gr.getClipBounds();
/*  356 */           int w = r.width;
/*  357 */           int h = r.height;
/*  358 */           if (getWidth() > 0 && getHeight() > 0) {
/*  359 */             BufferedImage buf = new BufferedImage(w, h, 3);
/*      */ 
/*      */             
/*  362 */             Graphics2D g = buf.createGraphics();
/*  363 */             g.setComposite(AlphaComposite.Clear);
/*  364 */             g.fillRect(0, 0, w, h);
/*  365 */             g.dispose();
/*      */             
/*  367 */             g = buf.createGraphics();
/*  368 */             g.translate(-r.x, -r.y);
/*  369 */             super.paint(g);
/*  370 */             g.dispose();
/*      */             
/*  372 */             paintDirect(buf, r);
/*      */           } 
/*      */         } else {
/*      */           
/*  376 */           super.paint(gr);
/*      */         } 
/*      */       }
/*      */ 
/*      */       
/*      */       protected abstract void paintDirect(BufferedImage param2BufferedImage, Rectangle param2Rectangle);
/*      */     }
/*      */ 
/*      */     
/*      */     protected Window getWindow(Component c) {
/*  386 */       return (c instanceof Window) ? (Window)c : 
/*  387 */         SwingUtilities.getWindowAncestor(c);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void whenDisplayable(Component w, final Runnable action) {
/*  394 */       if (w.isDisplayable() && (!WindowUtils.Holder.requiresVisible || w.isVisible())) {
/*  395 */         action.run();
/*      */       }
/*  397 */       else if (WindowUtils.Holder.requiresVisible) {
/*  398 */         getWindow(w).addWindowListener(new WindowAdapter()
/*      */             {
/*      */               public void windowOpened(WindowEvent e) {
/*  401 */                 e.getWindow().removeWindowListener(this);
/*  402 */                 action.run();
/*      */               }
/*      */               
/*      */               public void windowClosed(WindowEvent e) {
/*  406 */                 e.getWindow().removeWindowListener(this);
/*      */               }
/*      */             });
/*      */       
/*      */       }
/*      */       else {
/*      */         
/*  413 */         w.addHierarchyListener(new HierarchyListener()
/*      */             {
/*      */               public void hierarchyChanged(HierarchyEvent e) {
/*  416 */                 if ((e.getChangeFlags() & 0x2L) != 0L && e
/*  417 */                   .getComponent().isDisplayable()) {
/*  418 */                   e.getComponent().removeHierarchyListener(this);
/*  419 */                   action.run();
/*      */                 } 
/*      */               }
/*      */             });
/*      */       } 
/*      */     }
/*      */     
/*      */     protected Raster toRaster(Shape mask) {
/*  427 */       Raster raster = null;
/*  428 */       if (mask != WindowUtils.MASK_NONE) {
/*  429 */         Rectangle bounds = mask.getBounds();
/*  430 */         if (bounds.width > 0 && bounds.height > 0) {
/*  431 */           BufferedImage clip = new BufferedImage(bounds.x + bounds.width, bounds.y + bounds.height, 12);
/*      */ 
/*      */ 
/*      */           
/*  435 */           Graphics2D g = clip.createGraphics();
/*  436 */           g.setColor(Color.black);
/*  437 */           g.fillRect(0, 0, bounds.x + bounds.width, bounds.y + bounds.height);
/*  438 */           g.setColor(Color.white);
/*  439 */           g.fill(mask);
/*  440 */           raster = clip.getRaster();
/*      */         } 
/*      */       } 
/*  443 */       return raster;
/*      */     }
/*      */     
/*      */     protected Raster toRaster(Component c, Icon mask) {
/*  447 */       Raster raster = null;
/*  448 */       if (mask != null) {
/*      */         
/*  450 */         Rectangle bounds = new Rectangle(0, 0, mask.getIconWidth(), mask.getIconHeight());
/*  451 */         BufferedImage clip = new BufferedImage(bounds.width, bounds.height, 2);
/*      */ 
/*      */         
/*  454 */         Graphics2D g = clip.createGraphics();
/*  455 */         g.setComposite(AlphaComposite.Clear);
/*  456 */         g.fillRect(0, 0, bounds.width, bounds.height);
/*  457 */         g.setComposite(AlphaComposite.SrcOver);
/*  458 */         mask.paintIcon(c, g, 0, 0);
/*  459 */         raster = clip.getAlphaRaster();
/*      */       } 
/*  461 */       return raster;
/*      */     }
/*      */     
/*      */     protected Shape toShape(Raster raster) {
/*  465 */       final Area area = new Area(new Rectangle(0, 0, 0, 0));
/*  466 */       RasterRangesUtils.outputOccupiedRanges(raster, new RasterRangesUtils.RangesOutput()
/*      */           {
/*      */             public boolean outputRange(int x, int y, int w, int h) {
/*  469 */               area.add(new Area(new Rectangle(x, y, w, h)));
/*  470 */               return true;
/*      */             }
/*      */           });
/*  473 */       return area;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setWindowAlpha(Window w, float alpha) {}
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isWindowAlphaSupported() {
/*  486 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public GraphicsConfiguration getAlphaCompatibleGraphicsConfiguration() {
/*  492 */       GraphicsEnvironment env = GraphicsEnvironment.getLocalGraphicsEnvironment();
/*  493 */       GraphicsDevice dev = env.getDefaultScreenDevice();
/*  494 */       return dev.getDefaultConfiguration();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setWindowTransparent(Window w, boolean transparent) {}
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void setDoubleBuffered(Component root, boolean buffered) {
/*  507 */       if (root instanceof JComponent) {
/*  508 */         ((JComponent)root).setDoubleBuffered(buffered);
/*      */       }
/*  510 */       if (root instanceof JRootPane && buffered) {
/*  511 */         ((JRootPane)root).setDoubleBuffered(true);
/*      */       }
/*  513 */       else if (root instanceof Container) {
/*  514 */         Component[] kids = ((Container)root).getComponents();
/*  515 */         for (int i = 0; i < kids.length; i++) {
/*  516 */           setDoubleBuffered(kids[i], buffered);
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     protected void setLayersTransparent(Window w, boolean transparent) {
/*  523 */       Color bg = transparent ? new Color(0, 0, 0, 0) : null;
/*  524 */       if (w instanceof RootPaneContainer) {
/*  525 */         RootPaneContainer rpc = (RootPaneContainer)w;
/*  526 */         JRootPane root = rpc.getRootPane();
/*  527 */         JLayeredPane lp = root.getLayeredPane();
/*  528 */         Container c = root.getContentPane();
/*  529 */         JComponent content = (c instanceof JComponent) ? (JComponent)c : null;
/*      */         
/*  531 */         if (transparent) {
/*  532 */           lp.putClientProperty("transparent-old-opaque", Boolean.valueOf(lp.isOpaque()));
/*  533 */           lp.setOpaque(false);
/*  534 */           root.putClientProperty("transparent-old-opaque", Boolean.valueOf(root.isOpaque()));
/*  535 */           root.setOpaque(false);
/*  536 */           if (content != null) {
/*  537 */             content.putClientProperty("transparent-old-opaque", Boolean.valueOf(content.isOpaque()));
/*  538 */             content.setOpaque(false);
/*      */           } 
/*  540 */           root.putClientProperty("transparent-old-bg", root
/*  541 */               .getParent().getBackground());
/*      */         } else {
/*      */           
/*  544 */           lp.setOpaque(Boolean.TRUE.equals(lp.getClientProperty("transparent-old-opaque")));
/*  545 */           lp.putClientProperty("transparent-old-opaque", (Object)null);
/*  546 */           root.setOpaque(Boolean.TRUE.equals(root.getClientProperty("transparent-old-opaque")));
/*  547 */           root.putClientProperty("transparent-old-opaque", (Object)null);
/*  548 */           if (content != null) {
/*  549 */             content.setOpaque(Boolean.TRUE.equals(content.getClientProperty("transparent-old-opaque")));
/*  550 */             content.putClientProperty("transparent-old-opaque", (Object)null);
/*      */           } 
/*  552 */           bg = (Color)root.getClientProperty("transparent-old-bg");
/*  553 */           root.putClientProperty("transparent-old-bg", (Object)null);
/*      */         } 
/*      */       } 
/*  556 */       w.setBackground(bg);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void setMask(Component c, Raster raster) {
/*  563 */       throw new UnsupportedOperationException("Window masking is not available");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void setWindowMask(Component w, Raster raster) {
/*  572 */       if (w.isLightweight())
/*  573 */         throw new IllegalArgumentException("Component must be heavyweight: " + w); 
/*  574 */       setMask(w, raster);
/*      */     }
/*      */ 
/*      */     
/*      */     public void setWindowMask(Component w, Shape mask) {
/*  579 */       setWindowMask(w, toRaster(mask));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setWindowMask(Component w, Icon mask) {
/*  587 */       setWindowMask(w, toRaster(w, mask));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void setForceHeavyweightPopups(Window w, boolean force) {
/*  596 */       if (!(w instanceof WindowUtils.HeavyweightForcer)) {
/*  597 */         Window[] owned = w.getOwnedWindows();
/*  598 */         for (int i = 0; i < owned.length; i++) {
/*  599 */           if (owned[i] instanceof WindowUtils.HeavyweightForcer) {
/*  600 */             if (force)
/*      */               return; 
/*  602 */             owned[i].dispose();
/*      */           } 
/*      */         } 
/*  605 */         Boolean b = Boolean.valueOf(System.getProperty("jna.force_hw_popups", "true"));
/*  606 */         if (force && b.booleanValue()) {
/*  607 */           new WindowUtils.HeavyweightForcer(w);
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected BufferedImage getWindowIcon(WinDef.HWND hwnd) {
/*  626 */       throw new UnsupportedOperationException("This platform is not supported, yet.");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected Dimension getIconSize(WinDef.HICON hIcon) {
/*  642 */       throw new UnsupportedOperationException("This platform is not supported, yet.");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected List<DesktopWindow> getAllWindows(boolean onlyVisibleWindows) {
/*  663 */       throw new UnsupportedOperationException("This platform is not supported, yet.");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected String getWindowTitle(WinDef.HWND hwnd) {
/*  679 */       throw new UnsupportedOperationException("This platform is not supported, yet.");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected String getProcessFilePath(WinDef.HWND hwnd) {
/*  696 */       throw new UnsupportedOperationException("This platform is not supported, yet.");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected Rectangle getWindowLocationAndSize(WinDef.HWND hwnd) {
/*  711 */       throw new UnsupportedOperationException("This platform is not supported, yet.");
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static class Holder
/*      */   {
/*      */     public static boolean requiresVisible;
/*      */     
/*      */     public static final WindowUtils.NativeWindowUtils INSTANCE;
/*      */ 
/*      */     
/*      */     static {
/*  724 */       if (Platform.isWindows()) {
/*  725 */         INSTANCE = new WindowUtils.W32WindowUtils();
/*      */       }
/*  727 */       else if (Platform.isMac()) {
/*  728 */         INSTANCE = new WindowUtils.MacWindowUtils();
/*      */       }
/*  730 */       else if (Platform.isX11()) {
/*  731 */         INSTANCE = new WindowUtils.X11WindowUtils();
/*      */         
/*  733 */         requiresVisible = System.getProperty("java.version").matches("^1\\.4\\..*");
/*      */       } else {
/*      */         
/*  736 */         String os = System.getProperty("os.name");
/*  737 */         throw new UnsupportedOperationException("No support for " + os);
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   private static NativeWindowUtils getInstance() {
/*  743 */     return Holder.INSTANCE;
/*      */   }
/*      */   private static class W32WindowUtils extends NativeWindowUtils { private W32WindowUtils() {}
/*      */     
/*      */     private WinDef.HWND getHWnd(Component w) {
/*  748 */       WinDef.HWND hwnd = new WinDef.HWND();
/*  749 */       hwnd.setPointer(Native.getComponentPointer(w));
/*  750 */       return hwnd;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isWindowAlphaSupported() {
/*  759 */       return Boolean.getBoolean("sun.java2d.noddraw");
/*      */     }
/*      */ 
/*      */     
/*      */     private boolean usingUpdateLayeredWindow(Window w) {
/*  764 */       if (w instanceof RootPaneContainer) {
/*  765 */         JRootPane root = ((RootPaneContainer)w).getRootPane();
/*  766 */         return (root.getClientProperty("transparent-old-bg") != null);
/*      */       } 
/*  768 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void storeAlpha(Window w, byte alpha) {
/*  775 */       if (w instanceof RootPaneContainer) {
/*  776 */         JRootPane root = ((RootPaneContainer)w).getRootPane();
/*  777 */         Byte b = (alpha == -1) ? null : Byte.valueOf(alpha);
/*  778 */         root.putClientProperty("transparent-alpha", b);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     private byte getAlpha(Window w) {
/*  784 */       if (w instanceof RootPaneContainer) {
/*  785 */         JRootPane root = ((RootPaneContainer)w).getRootPane();
/*  786 */         Byte b = (Byte)root.getClientProperty("transparent-alpha");
/*  787 */         if (b != null) {
/*  788 */           return b.byteValue();
/*      */         }
/*      */       } 
/*  791 */       return -1;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setWindowAlpha(final Window w, final float alpha) {
/*  796 */       if (!isWindowAlphaSupported()) {
/*  797 */         throw new UnsupportedOperationException("Set sun.java2d.noddraw=true to enable transparent windows");
/*      */       }
/*  799 */       whenDisplayable(w, new Runnable()
/*      */           {
/*      */             public void run() {
/*  802 */               WinDef.HWND hWnd = WindowUtils.W32WindowUtils.this.getHWnd(w);
/*  803 */               User32 user = User32.INSTANCE;
/*  804 */               int flags = user.GetWindowLong(hWnd, -20);
/*  805 */               byte level = (byte)((int)(255.0F * alpha) & 0xFF);
/*  806 */               if (WindowUtils.W32WindowUtils.this.usingUpdateLayeredWindow(w)) {
/*      */ 
/*      */                 
/*  809 */                 WinUser.BLENDFUNCTION blend = new WinUser.BLENDFUNCTION();
/*  810 */                 blend.SourceConstantAlpha = level;
/*  811 */                 blend.AlphaFormat = 1;
/*  812 */                 user.UpdateLayeredWindow(hWnd, null, null, null, null, null, 0, blend, 2);
/*      */ 
/*      */               
/*      */               }
/*  816 */               else if (alpha == 1.0F) {
/*  817 */                 flags &= 0xFFF7FFFF;
/*  818 */                 user.SetWindowLong(hWnd, -20, flags);
/*      */               } else {
/*      */                 
/*  821 */                 flags |= 0x80000;
/*  822 */                 user.SetWindowLong(hWnd, -20, flags);
/*  823 */                 user.SetLayeredWindowAttributes(hWnd, 0, level, 2);
/*      */               } 
/*      */               
/*  826 */               WindowUtils.W32WindowUtils.this.setForceHeavyweightPopups(w, (alpha != 1.0F));
/*  827 */               WindowUtils.W32WindowUtils.this.storeAlpha(w, level);
/*      */             }
/*      */           });
/*      */     }
/*      */ 
/*      */     
/*      */     private class W32TransparentContentPane
/*      */       extends WindowUtils.NativeWindowUtils.TransparentContentPane
/*      */     {
/*      */       private static final long serialVersionUID = 1L;
/*      */       private WinDef.HDC memDC;
/*      */       private WinDef.HBITMAP hBitmap;
/*      */       private Pointer pbits;
/*      */       private Dimension bitmapSize;
/*      */       
/*      */       public W32TransparentContentPane(Container content) {
/*  843 */         super(content);
/*      */       }
/*      */       private void disposeBackingStore() {
/*  846 */         GDI32 gdi = GDI32.INSTANCE;
/*  847 */         if (this.hBitmap != null) {
/*  848 */           gdi.DeleteObject((WinNT.HANDLE)this.hBitmap);
/*  849 */           this.hBitmap = null;
/*      */         } 
/*  851 */         if (this.memDC != null) {
/*  852 */           gdi.DeleteDC(this.memDC);
/*  853 */           this.memDC = null;
/*      */         } 
/*      */       }
/*      */       
/*      */       public void removeNotify() {
/*  858 */         super.removeNotify();
/*  859 */         disposeBackingStore();
/*      */       }
/*      */       
/*      */       public void setTransparent(boolean transparent) {
/*  863 */         super.setTransparent(transparent);
/*  864 */         if (!transparent) {
/*  865 */           disposeBackingStore();
/*      */         }
/*      */       }
/*      */ 
/*      */       
/*      */       protected void paintDirect(BufferedImage buf, Rectangle bounds) {
/*  871 */         Window win = SwingUtilities.getWindowAncestor(this);
/*  872 */         GDI32 gdi = GDI32.INSTANCE;
/*  873 */         User32 user = User32.INSTANCE;
/*  874 */         int x = bounds.x;
/*  875 */         int y = bounds.y;
/*  876 */         Point origin = SwingUtilities.convertPoint(this, x, y, win);
/*  877 */         int w = bounds.width;
/*  878 */         int h = bounds.height;
/*  879 */         int ww = win.getWidth();
/*  880 */         int wh = win.getHeight();
/*  881 */         WinDef.HDC screenDC = user.GetDC(null);
/*  882 */         WinNT.HANDLE oldBitmap = null;
/*      */         try {
/*  884 */           if (this.memDC == null) {
/*  885 */             this.memDC = gdi.CreateCompatibleDC(screenDC);
/*      */           }
/*  887 */           if (this.hBitmap == null || !win.getSize().equals(this.bitmapSize)) {
/*  888 */             if (this.hBitmap != null) {
/*  889 */               gdi.DeleteObject((WinNT.HANDLE)this.hBitmap);
/*  890 */               this.hBitmap = null;
/*      */             } 
/*  892 */             WinGDI.BITMAPINFO bmi = new WinGDI.BITMAPINFO();
/*  893 */             bmi.bmiHeader.biWidth = ww;
/*  894 */             bmi.bmiHeader.biHeight = wh;
/*  895 */             bmi.bmiHeader.biPlanes = 1;
/*  896 */             bmi.bmiHeader.biBitCount = 32;
/*  897 */             bmi.bmiHeader.biCompression = 0;
/*  898 */             bmi.bmiHeader.biSizeImage = ww * wh * 4;
/*  899 */             PointerByReference ppbits = new PointerByReference();
/*  900 */             this.hBitmap = gdi.CreateDIBSection(this.memDC, bmi, 0, ppbits, null, 0);
/*      */ 
/*      */             
/*  903 */             this.pbits = ppbits.getValue();
/*  904 */             this.bitmapSize = new Dimension(ww, wh);
/*      */           } 
/*  906 */           oldBitmap = gdi.SelectObject(this.memDC, (WinNT.HANDLE)this.hBitmap);
/*  907 */           Raster raster = buf.getData();
/*  908 */           int[] pixel = new int[4];
/*  909 */           int[] bits = new int[w];
/*  910 */           for (int row = 0; row < h; row++) {
/*  911 */             for (int col = 0; col < w; col++) {
/*  912 */               raster.getPixel(col, row, pixel);
/*  913 */               int alpha = (pixel[3] & 0xFF) << 24;
/*  914 */               int red = pixel[2] & 0xFF;
/*  915 */               int green = (pixel[1] & 0xFF) << 8;
/*  916 */               int blue = (pixel[0] & 0xFF) << 16;
/*  917 */               bits[col] = alpha | red | green | blue;
/*      */             } 
/*  919 */             int v = wh - origin.y + row - 1;
/*  920 */             this.pbits.write(((v * ww + origin.x) * 4), bits, 0, bits.length);
/*      */           } 
/*  922 */           WinUser.SIZE winSize = new WinUser.SIZE();
/*  923 */           winSize.cx = win.getWidth();
/*  924 */           winSize.cy = win.getHeight();
/*  925 */           WinDef.POINT winLoc = new WinDef.POINT();
/*  926 */           winLoc.x = win.getX();
/*  927 */           winLoc.y = win.getY();
/*  928 */           WinDef.POINT srcLoc = new WinDef.POINT();
/*  929 */           WinUser.BLENDFUNCTION blend = new WinUser.BLENDFUNCTION();
/*  930 */           WinDef.HWND hWnd = WindowUtils.W32WindowUtils.this.getHWnd(win);
/*      */           
/*  932 */           ByteByReference bref = new ByteByReference();
/*  933 */           IntByReference iref = new IntByReference();
/*  934 */           byte level = WindowUtils.W32WindowUtils.this.getAlpha(win);
/*      */           
/*      */           try {
/*  937 */             if (user.GetLayeredWindowAttributes(hWnd, null, bref, iref) && (iref
/*  938 */               .getValue() & 0x2) != 0) {
/*  939 */               level = bref.getValue();
/*      */             }
/*      */           }
/*  942 */           catch (UnsatisfiedLinkError unsatisfiedLinkError) {}
/*      */           
/*  944 */           blend.SourceConstantAlpha = level;
/*  945 */           blend.AlphaFormat = 1;
/*  946 */           user.UpdateLayeredWindow(hWnd, screenDC, winLoc, winSize, this.memDC, srcLoc, 0, blend, 2);
/*      */         } finally {
/*      */           
/*  949 */           user.ReleaseDC(null, screenDC);
/*  950 */           if (this.memDC != null && oldBitmap != null) {
/*  951 */             gdi.SelectObject(this.memDC, oldBitmap);
/*      */           }
/*      */         } 
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setWindowTransparent(final Window w, final boolean transparent) {
/*  963 */       if (!(w instanceof RootPaneContainer)) {
/*  964 */         throw new IllegalArgumentException("Window must be a RootPaneContainer");
/*      */       }
/*  966 */       if (!isWindowAlphaSupported()) {
/*  967 */         throw new UnsupportedOperationException("Set sun.java2d.noddraw=true to enable transparent windows");
/*      */       }
/*      */       
/*  970 */       boolean isTransparent = (w.getBackground() != null && w.getBackground().getAlpha() == 0);
/*  971 */       if (transparent == isTransparent)
/*      */         return; 
/*  973 */       whenDisplayable(w, new Runnable()
/*      */           {
/*      */             public void run() {
/*  976 */               User32 user = User32.INSTANCE;
/*  977 */               WinDef.HWND hWnd = WindowUtils.W32WindowUtils.this.getHWnd(w);
/*  978 */               int flags = user.GetWindowLong(hWnd, -20);
/*  979 */               JRootPane root = ((RootPaneContainer)w).getRootPane();
/*  980 */               JLayeredPane lp = root.getLayeredPane();
/*  981 */               Container content = root.getContentPane();
/*  982 */               if (content instanceof WindowUtils.W32WindowUtils.W32TransparentContentPane) {
/*  983 */                 ((WindowUtils.W32WindowUtils.W32TransparentContentPane)content).setTransparent(transparent);
/*      */               }
/*  985 */               else if (transparent) {
/*  986 */                 WindowUtils.W32WindowUtils.W32TransparentContentPane w32content = new WindowUtils.W32WindowUtils.W32TransparentContentPane(content);
/*      */                 
/*  988 */                 root.setContentPane(w32content);
/*  989 */                 lp.add(new WindowUtils.RepaintTrigger(w32content), JLayeredPane.DRAG_LAYER);
/*      */               } 
/*      */               
/*  992 */               if (transparent && !WindowUtils.W32WindowUtils.this.usingUpdateLayeredWindow(w)) {
/*  993 */                 flags |= 0x80000;
/*  994 */                 user.SetWindowLong(hWnd, -20, flags);
/*      */               }
/*  996 */               else if (!transparent && WindowUtils.W32WindowUtils.this.usingUpdateLayeredWindow(w)) {
/*  997 */                 flags &= 0xFFF7FFFF;
/*  998 */                 user.SetWindowLong(hWnd, -20, flags);
/*      */               } 
/* 1000 */               WindowUtils.W32WindowUtils.this.setLayersTransparent(w, transparent);
/* 1001 */               WindowUtils.W32WindowUtils.this.setForceHeavyweightPopups(w, transparent);
/* 1002 */               WindowUtils.W32WindowUtils.this.setDoubleBuffered(w, !transparent);
/*      */             }
/*      */           });
/*      */     }
/*      */ 
/*      */     
/*      */     public void setWindowMask(Component w, Shape mask) {
/* 1009 */       if (mask instanceof Area && ((Area)mask).isPolygonal()) {
/* 1010 */         setMask(w, (Area)mask);
/*      */       } else {
/*      */         
/* 1013 */         super.setWindowMask(w, mask);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     private void setWindowRegion(final Component w, final WinDef.HRGN hrgn) {
/* 1019 */       whenDisplayable(w, new Runnable()
/*      */           {
/*      */             public void run() {
/* 1022 */               GDI32 gdi = GDI32.INSTANCE;
/* 1023 */               User32 user = User32.INSTANCE;
/* 1024 */               WinDef.HWND hWnd = WindowUtils.W32WindowUtils.this.getHWnd(w);
/*      */               try {
/* 1026 */                 user.SetWindowRgn(hWnd, hrgn, true);
/* 1027 */                 WindowUtils.W32WindowUtils.this.setForceHeavyweightPopups(WindowUtils.W32WindowUtils.this.getWindow(w), (hrgn != null));
/*      */               } finally {
/*      */                 
/* 1030 */                 gdi.DeleteObject((WinNT.HANDLE)hrgn);
/*      */               } 
/*      */             }
/*      */           });
/*      */     }
/*      */ 
/*      */     
/*      */     private void setMask(Component w, Area area) {
/* 1038 */       GDI32 gdi = GDI32.INSTANCE;
/* 1039 */       PathIterator pi = area.getPathIterator(null);
/* 1040 */       int mode = (pi.getWindingRule() == 1) ? 2 : 1;
/*      */       
/* 1042 */       float[] coords = new float[6];
/* 1043 */       List<WinDef.POINT> points = new ArrayList<WinDef.POINT>();
/* 1044 */       int size = 0;
/* 1045 */       List<Integer> sizes = new ArrayList<Integer>();
/* 1046 */       while (!pi.isDone()) {
/* 1047 */         int type = pi.currentSegment(coords);
/* 1048 */         if (type == 0) {
/* 1049 */           size = 1;
/* 1050 */           points.add(new WinDef.POINT((int)coords[0], (int)coords[1]));
/*      */         }
/* 1052 */         else if (type == 1) {
/* 1053 */           size++;
/* 1054 */           points.add(new WinDef.POINT((int)coords[0], (int)coords[1]));
/*      */         }
/* 1056 */         else if (type == 4) {
/* 1057 */           sizes.add(Integer.valueOf(size));
/*      */         } else {
/*      */           
/* 1060 */           throw new RuntimeException("Area is not polygonal: " + area);
/*      */         } 
/* 1062 */         pi.next();
/*      */       } 
/* 1064 */       WinDef.POINT[] lppt = (WinDef.POINT[])(new WinDef.POINT()).toArray(points.size());
/* 1065 */       WinDef.POINT[] pts = points.<WinDef.POINT>toArray(new WinDef.POINT[points.size()]);
/* 1066 */       for (int i = 0; i < lppt.length; i++) {
/* 1067 */         (lppt[i]).x = (pts[i]).x;
/* 1068 */         (lppt[i]).y = (pts[i]).y;
/*      */       } 
/* 1070 */       int[] counts = new int[sizes.size()];
/* 1071 */       for (int j = 0; j < counts.length; j++) {
/* 1072 */         counts[j] = ((Integer)sizes.get(j)).intValue();
/*      */       }
/* 1074 */       WinDef.HRGN hrgn = gdi.CreatePolyPolygonRgn(lppt, counts, counts.length, mode);
/* 1075 */       setWindowRegion(w, hrgn);
/*      */     }
/*      */ 
/*      */     
/*      */     protected void setMask(Component w, Raster raster) {
/* 1080 */       GDI32 gdi = GDI32.INSTANCE;
/*      */       
/* 1082 */       final WinDef.HRGN region = (raster != null) ? gdi.CreateRectRgn(0, 0, 0, 0) : null;
/* 1083 */       if (region != null) {
/* 1084 */         final WinDef.HRGN tempRgn = gdi.CreateRectRgn(0, 0, 0, 0);
/*      */         try {
/* 1086 */           RasterRangesUtils.outputOccupiedRanges(raster, new RasterRangesUtils.RangesOutput()
/*      */               {
/*      */                 public boolean outputRange(int x, int y, int w, int h) {
/* 1089 */                   GDI32 gdi = GDI32.INSTANCE;
/* 1090 */                   gdi.SetRectRgn(tempRgn, x, y, x + w, y + h);
/* 1091 */                   return (gdi.CombineRgn(region, region, tempRgn, 2) != 0);
/*      */                 }
/*      */               });
/*      */         } finally {
/*      */           
/* 1096 */           gdi.DeleteObject((WinNT.HANDLE)tempRgn);
/*      */         } 
/*      */       } 
/* 1099 */       setWindowRegion(w, region);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public BufferedImage getWindowIcon(WinDef.HWND hwnd) {
/* 1105 */       WinDef.DWORDByReference hIconNumber = new WinDef.DWORDByReference();
/*      */       
/* 1107 */       WinDef.LRESULT result = User32.INSTANCE.SendMessageTimeout(hwnd, 127, new WinDef.WPARAM(1L), new WinDef.LPARAM(0L), 2, 500, hIconNumber);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1112 */       if (result.intValue() == 0)
/*      */       {
/* 1114 */         result = User32.INSTANCE.SendMessageTimeout(hwnd, 127, new WinDef.WPARAM(0L), new WinDef.LPARAM(0L), 2, 500, hIconNumber);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 1119 */       if (result.intValue() == 0)
/*      */       {
/* 1121 */         result = User32.INSTANCE.SendMessageTimeout(hwnd, 127, new WinDef.WPARAM(2L), new WinDef.LPARAM(0L), 2, 500, hIconNumber);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 1126 */       if (result.intValue() == 0) {
/*      */ 
/*      */         
/* 1129 */         result = new WinDef.LRESULT(User32.INSTANCE.GetClassLongPtr(hwnd, -14).intValue());
/* 1130 */         hIconNumber.getValue().setValue(result.intValue());
/*      */       } 
/* 1132 */       if (result.intValue() == 0) {
/*      */ 
/*      */         
/* 1135 */         result = new WinDef.LRESULT(User32.INSTANCE.GetClassLongPtr(hwnd, -34).intValue());
/* 1136 */         hIconNumber.getValue().setValue(result.intValue());
/*      */       } 
/* 1138 */       if (result.intValue() == 0) {
/* 1139 */         return null;
/*      */       }
/*      */ 
/*      */       
/* 1143 */       WinDef.HICON hIcon = new WinDef.HICON(new Pointer(hIconNumber.getValue().longValue()));
/* 1144 */       Dimension iconSize = getIconSize(hIcon);
/* 1145 */       if (iconSize.width == 0 || iconSize.height == 0) {
/* 1146 */         return null;
/*      */       }
/* 1148 */       int width = iconSize.width;
/* 1149 */       int height = iconSize.height;
/* 1150 */       short depth = 24;
/*      */       
/* 1152 */       byte[] lpBitsColor = new byte[width * height * 24 / 8];
/* 1153 */       Memory memory1 = new Memory(lpBitsColor.length);
/* 1154 */       byte[] lpBitsMask = new byte[width * height * 24 / 8];
/* 1155 */       Memory memory2 = new Memory(lpBitsMask.length);
/* 1156 */       WinGDI.BITMAPINFO bitmapInfo = new WinGDI.BITMAPINFO();
/* 1157 */       WinGDI.BITMAPINFOHEADER hdr = new WinGDI.BITMAPINFOHEADER();
/*      */       
/* 1159 */       bitmapInfo.bmiHeader = hdr;
/* 1160 */       hdr.biWidth = width;
/* 1161 */       hdr.biHeight = height;
/* 1162 */       hdr.biPlanes = 1;
/* 1163 */       hdr.biBitCount = 24;
/* 1164 */       hdr.biCompression = 0;
/* 1165 */       hdr.write();
/* 1166 */       bitmapInfo.write();
/*      */       
/* 1168 */       WinDef.HDC hDC = User32.INSTANCE.GetDC(null);
/* 1169 */       WinGDI.ICONINFO iconInfo = new WinGDI.ICONINFO();
/* 1170 */       User32.INSTANCE.GetIconInfo(hIcon, iconInfo);
/* 1171 */       iconInfo.read();
/* 1172 */       GDI32.INSTANCE.GetDIBits(hDC, iconInfo.hbmColor, 0, height, (Pointer)memory1, bitmapInfo, 0);
/*      */       
/* 1174 */       memory1.read(0L, lpBitsColor, 0, lpBitsColor.length);
/* 1175 */       GDI32.INSTANCE.GetDIBits(hDC, iconInfo.hbmMask, 0, height, (Pointer)memory2, bitmapInfo, 0);
/*      */       
/* 1177 */       memory2.read(0L, lpBitsMask, 0, lpBitsMask.length);
/* 1178 */       BufferedImage image = new BufferedImage(width, height, 2);
/*      */ 
/*      */ 
/*      */       
/* 1182 */       int x = 0, y = height - 1; int i;
/* 1183 */       for (i = 0; i < lpBitsColor.length; i += 3) {
/* 1184 */         int b = lpBitsColor[i] & 0xFF;
/* 1185 */         int g = lpBitsColor[i + 1] & 0xFF;
/* 1186 */         int r = lpBitsColor[i + 2] & 0xFF;
/* 1187 */         int a = 255 - lpBitsMask[i] & 0xFF;
/* 1188 */         int argb = a << 24 | r << 16 | g << 8 | b;
/* 1189 */         image.setRGB(x, y, argb);
/* 1190 */         x = (x + 1) % width;
/* 1191 */         if (x == 0) {
/* 1192 */           y--;
/*      */         }
/*      */       } 
/* 1195 */       User32.INSTANCE.ReleaseDC(null, hDC);
/*      */       
/* 1197 */       return image;
/*      */     }
/*      */ 
/*      */     
/*      */     public Dimension getIconSize(WinDef.HICON hIcon) {
/* 1202 */       WinGDI.ICONINFO iconInfo = new WinGDI.ICONINFO();
/*      */       try {
/* 1204 */         if (!User32.INSTANCE.GetIconInfo(hIcon, iconInfo))
/* 1205 */           return new Dimension(); 
/* 1206 */         iconInfo.read();
/*      */         
/* 1208 */         WinGDI.BITMAP bmp = new WinGDI.BITMAP();
/* 1209 */         if (iconInfo.hbmColor != null && iconInfo.hbmColor
/* 1210 */           .getPointer() != Pointer.NULL) {
/* 1211 */           int nWrittenBytes = GDI32.INSTANCE.GetObject((WinNT.HANDLE)iconInfo.hbmColor, bmp
/* 1212 */               .size(), bmp.getPointer());
/* 1213 */           bmp.read();
/* 1214 */           if (nWrittenBytes > 0)
/* 1215 */             return new Dimension(bmp.bmWidth.intValue(), bmp.bmHeight
/* 1216 */                 .intValue()); 
/* 1217 */         } else if (iconInfo.hbmMask != null && iconInfo.hbmMask
/* 1218 */           .getPointer() != Pointer.NULL) {
/* 1219 */           int nWrittenBytes = GDI32.INSTANCE.GetObject((WinNT.HANDLE)iconInfo.hbmMask, bmp
/* 1220 */               .size(), bmp.getPointer());
/* 1221 */           bmp.read();
/* 1222 */           if (nWrittenBytes > 0)
/* 1223 */             return new Dimension(bmp.bmWidth.intValue(), bmp.bmHeight.intValue() / 2); 
/*      */         } 
/*      */       } finally {
/* 1226 */         if (iconInfo.hbmColor != null && iconInfo.hbmColor
/* 1227 */           .getPointer() != Pointer.NULL)
/* 1228 */           GDI32.INSTANCE.DeleteObject((WinNT.HANDLE)iconInfo.hbmColor); 
/* 1229 */         if (iconInfo.hbmMask != null && iconInfo.hbmMask
/* 1230 */           .getPointer() != Pointer.NULL) {
/* 1231 */           GDI32.INSTANCE.DeleteObject((WinNT.HANDLE)iconInfo.hbmMask);
/*      */         }
/*      */       } 
/* 1234 */       return new Dimension();
/*      */     }
/*      */ 
/*      */     
/*      */     public List<DesktopWindow> getAllWindows(final boolean onlyVisibleWindows) {
/* 1239 */       final List<DesktopWindow> result = new LinkedList<DesktopWindow>();
/*      */       
/* 1241 */       WinUser.WNDENUMPROC lpEnumFunc = new WinUser.WNDENUMPROC()
/*      */         {
/*      */           public boolean callback(WinDef.HWND hwnd, Pointer arg1)
/*      */           {
/*      */             try {
/* 1246 */               boolean visible = (!onlyVisibleWindows || User32.INSTANCE.IsWindowVisible(hwnd));
/* 1247 */               if (visible) {
/* 1248 */                 String title = WindowUtils.W32WindowUtils.this.getWindowTitle(hwnd);
/* 1249 */                 String filePath = WindowUtils.W32WindowUtils.this.getProcessFilePath(hwnd);
/* 1250 */                 Rectangle locAndSize = WindowUtils.W32WindowUtils.this.getWindowLocationAndSize(hwnd);
/* 1251 */                 result.add(new DesktopWindow(hwnd, title, filePath, locAndSize));
/*      */               }
/*      */             
/* 1254 */             } catch (Exception e) {
/*      */               
/* 1256 */               e.printStackTrace();
/*      */             } 
/*      */             
/* 1259 */             return true;
/*      */           }
/*      */         };
/*      */       
/* 1263 */       if (!User32.INSTANCE.EnumWindows(lpEnumFunc, null)) {
/* 1264 */         throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */       }
/* 1266 */       return result;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public String getWindowTitle(WinDef.HWND hwnd) {
/* 1272 */       int requiredLength = User32.INSTANCE.GetWindowTextLength(hwnd) + 1;
/* 1273 */       char[] title = new char[requiredLength];
/* 1274 */       int length = User32.INSTANCE.GetWindowText(hwnd, title, title.length);
/*      */ 
/*      */       
/* 1277 */       return Native.toString(Arrays.copyOfRange(title, 0, length));
/*      */     }
/*      */ 
/*      */     
/*      */     public String getProcessFilePath(WinDef.HWND hwnd) {
/* 1282 */       char[] filePath = new char[2048];
/* 1283 */       IntByReference pid = new IntByReference();
/* 1284 */       User32.INSTANCE.GetWindowThreadProcessId(hwnd, pid);
/*      */       
/* 1286 */       WinNT.HANDLE process = Kernel32.INSTANCE.OpenProcess(1040, false, pid
/* 1287 */           .getValue());
/* 1288 */       if (process == null) {
/* 1289 */         if (Kernel32.INSTANCE.GetLastError() != 5) {
/* 1290 */           throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */         }
/*      */         
/* 1293 */         return "";
/*      */       } 
/*      */ 
/*      */       
/*      */       try {
/* 1298 */         int length = Psapi.INSTANCE.GetModuleFileNameExW(process, null, filePath, filePath.length);
/*      */         
/* 1300 */         if (length == 0) {
/* 1301 */           if (Kernel32.INSTANCE.GetLastError() != 6) {
/* 1302 */             throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */           }
/*      */           
/* 1305 */           return "";
/*      */         } 
/*      */         
/* 1308 */         return Native.toString(filePath).trim();
/*      */       } finally {
/* 1310 */         Kernel32.INSTANCE.CloseHandle(process);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public Rectangle getWindowLocationAndSize(WinDef.HWND hwnd) {
/* 1316 */       WinDef.RECT lpRect = new WinDef.RECT();
/* 1317 */       if (!User32.INSTANCE.GetWindowRect(hwnd, lpRect)) {
/* 1318 */         throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */       }
/* 1320 */       return new Rectangle(lpRect.left, lpRect.top, Math.abs(lpRect.right - lpRect.left), 
/* 1321 */           Math.abs(lpRect.bottom - lpRect.top));
/*      */     } }
/*      */   
/*      */   private static class MacWindowUtils extends NativeWindowUtils {
/*      */     private static final String WDRAG = "apple.awt.draggableWindowBackground";
/*      */     
/*      */     public boolean isWindowAlphaSupported() {
/* 1328 */       return true;
/*      */     }
/*      */     private MacWindowUtils() {}
/*      */     private OSXMaskingContentPane installMaskingPane(Window w) {
/*      */       OSXMaskingContentPane content;
/* 1333 */       if (w instanceof RootPaneContainer) {
/*      */         
/* 1335 */         RootPaneContainer rpc = (RootPaneContainer)w;
/* 1336 */         Container oldContent = rpc.getContentPane();
/* 1337 */         if (oldContent instanceof OSXMaskingContentPane) {
/* 1338 */           content = (OSXMaskingContentPane)oldContent;
/*      */         } else {
/*      */           
/* 1341 */           content = new OSXMaskingContentPane(oldContent);
/*      */           
/* 1343 */           rpc.setContentPane(content);
/*      */         } 
/*      */       } else {
/*      */         
/* 1347 */         Component oldContent = (w.getComponentCount() > 0) ? w.getComponent(0) : null;
/* 1348 */         if (oldContent instanceof OSXMaskingContentPane) {
/* 1349 */           content = (OSXMaskingContentPane)oldContent;
/*      */         } else {
/*      */           
/* 1352 */           content = new OSXMaskingContentPane(oldContent);
/* 1353 */           w.add(content);
/*      */         } 
/*      */       } 
/* 1356 */       return content;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setWindowTransparent(Window w, boolean transparent) {
/* 1370 */       boolean isTransparent = (w.getBackground() != null && w.getBackground().getAlpha() == 0);
/* 1371 */       if (transparent != isTransparent) {
/* 1372 */         setBackgroundTransparent(w, transparent, "setWindowTransparent");
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private void fixWindowDragging(Window w, String context) {
/* 1379 */       if (w instanceof RootPaneContainer) {
/* 1380 */         JRootPane p = ((RootPaneContainer)w).getRootPane();
/* 1381 */         Boolean oldDraggable = (Boolean)p.getClientProperty("apple.awt.draggableWindowBackground");
/* 1382 */         if (oldDraggable == null) {
/* 1383 */           p.putClientProperty("apple.awt.draggableWindowBackground", Boolean.FALSE);
/* 1384 */           if (w.isDisplayable()) {
/* 1385 */             WindowUtils.LOG.log(Level.WARNING, "{0}(): To avoid content dragging, {1}() must be called before the window is realized, or apple.awt.draggableWindowBackground must be set to Boolean.FALSE before the window is realized.  If you really want content dragging, set apple.awt.draggableWindowBackground on the window''s root pane to Boolean.TRUE before calling {2}() to hide this message.", new Object[] { context, context, context });
/*      */           }
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setWindowAlpha(final Window w, final float alpha) {
/* 1402 */       if (w instanceof RootPaneContainer) {
/* 1403 */         JRootPane p = ((RootPaneContainer)w).getRootPane();
/* 1404 */         p.putClientProperty("Window.alpha", Float.valueOf(alpha));
/* 1405 */         fixWindowDragging(w, "setWindowAlpha");
/*      */       } 
/* 1407 */       whenDisplayable(w, new Runnable()
/*      */           {
/*      */             
/*      */             public void run()
/*      */             {
/*      */               try {
/* 1413 */                 Method getPeer = w.getClass().getMethod("getPeer", new Class[0]);
/* 1414 */                 Object peer = getPeer.invoke(w, new Object[0]);
/* 1415 */                 Method setAlpha = peer.getClass().getMethod("setAlpha", new Class[] { float.class });
/* 1416 */                 setAlpha.invoke(peer, new Object[] { Float.valueOf(this.val$alpha) });
/*      */               }
/* 1418 */               catch (Exception exception) {}
/*      */             }
/*      */           });
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     protected void setWindowMask(Component w, Raster raster) {
/* 1426 */       if (raster != null) {
/* 1427 */         setWindowMask(w, toShape(raster));
/*      */       } else {
/*      */         
/* 1430 */         setWindowMask(w, new Rectangle(0, 0, w.getWidth(), w
/* 1431 */               .getHeight()));
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void setWindowMask(Component c, Shape shape) {
/* 1437 */       if (c instanceof Window) {
/* 1438 */         Window w = (Window)c;
/* 1439 */         OSXMaskingContentPane content = installMaskingPane(w);
/* 1440 */         content.setMask(shape);
/* 1441 */         setBackgroundTransparent(w, (shape != WindowUtils.MASK_NONE), "setWindowMask");
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private static class OSXMaskingContentPane
/*      */       extends JPanel
/*      */     {
/*      */       private static final long serialVersionUID = 1L;
/*      */       
/*      */       private Shape shape;
/*      */ 
/*      */       
/*      */       public OSXMaskingContentPane(Component oldContent) {
/* 1456 */         super(new BorderLayout());
/* 1457 */         if (oldContent != null) {
/* 1458 */           add(oldContent, "Center");
/*      */         }
/*      */       }
/*      */       
/*      */       public void setMask(Shape shape) {
/* 1463 */         this.shape = shape;
/* 1464 */         repaint();
/*      */       }
/*      */ 
/*      */       
/*      */       public void paint(Graphics graphics) {
/* 1469 */         Graphics2D g = (Graphics2D)graphics.create();
/* 1470 */         g.setComposite(AlphaComposite.Clear);
/* 1471 */         g.fillRect(0, 0, getWidth(), getHeight());
/* 1472 */         g.dispose();
/* 1473 */         if (this.shape != null) {
/* 1474 */           g = (Graphics2D)graphics.create();
/* 1475 */           g.setClip(this.shape);
/* 1476 */           super.paint(g);
/* 1477 */           g.dispose();
/*      */         } else {
/*      */           
/* 1480 */           super.paint(graphics);
/*      */         } 
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     private void setBackgroundTransparent(Window w, boolean transparent, String context) {
/* 1487 */       JRootPane rp = (w instanceof RootPaneContainer) ? ((RootPaneContainer)w).getRootPane() : null;
/* 1488 */       if (transparent) {
/* 1489 */         if (rp != null) {
/* 1490 */           rp.putClientProperty("transparent-old-bg", w.getBackground());
/*      */         }
/* 1492 */         w.setBackground(new Color(0, 0, 0, 0));
/*      */       
/*      */       }
/* 1495 */       else if (rp != null) {
/* 1496 */         Color bg = (Color)rp.getClientProperty("transparent-old-bg");
/*      */ 
/*      */ 
/*      */         
/* 1500 */         if (bg != null) {
/* 1501 */           bg = new Color(bg.getRed(), bg.getGreen(), bg.getBlue(), bg.getAlpha());
/*      */         }
/* 1503 */         w.setBackground(bg);
/* 1504 */         rp.putClientProperty("transparent-old-bg", (Object)null);
/*      */       } else {
/*      */         
/* 1507 */         w.setBackground((Color)null);
/*      */       } 
/*      */       
/* 1510 */       fixWindowDragging(w, context);
/*      */     } }
/*      */   
/*      */   private static class X11WindowUtils extends NativeWindowUtils {
/*      */     private boolean didCheck;
/*      */     
/*      */     private static X11.Pixmap createBitmap(X11.Display dpy, X11.Window win, Raster raster) {
/* 1517 */       X11 x11 = X11.INSTANCE;
/* 1518 */       Rectangle bounds = raster.getBounds();
/* 1519 */       int width = bounds.x + bounds.width;
/* 1520 */       int height = bounds.y + bounds.height;
/* 1521 */       X11.Pixmap pm = x11.XCreatePixmap(dpy, (X11.Drawable)win, width, height, 1);
/* 1522 */       X11.GC gc = x11.XCreateGC(dpy, (X11.Drawable)pm, new NativeLong(0L), null);
/* 1523 */       if (gc == null) {
/* 1524 */         return null;
/*      */       }
/* 1526 */       x11.XSetForeground(dpy, gc, new NativeLong(0L));
/* 1527 */       x11.XFillRectangle(dpy, (X11.Drawable)pm, gc, 0, 0, width, height);
/* 1528 */       final List<Rectangle> rlist = new ArrayList<Rectangle>();
/*      */       try {
/* 1530 */         RasterRangesUtils.outputOccupiedRanges(raster, new RasterRangesUtils.RangesOutput()
/*      */             {
/*      */               public boolean outputRange(int x, int y, int w, int h) {
/* 1533 */                 rlist.add(new Rectangle(x, y, w, h));
/* 1534 */                 return true;
/*      */               }
/*      */             });
/*      */         
/* 1538 */         X11.XRectangle[] rects = (X11.XRectangle[])(new X11.XRectangle()).toArray(rlist.size());
/* 1539 */         for (int i = 0; i < rects.length; i++) {
/* 1540 */           Rectangle r = rlist.get(i);
/* 1541 */           (rects[i]).x = (short)r.x;
/* 1542 */           (rects[i]).y = (short)r.y;
/* 1543 */           (rects[i]).width = (short)r.width;
/* 1544 */           (rects[i]).height = (short)r.height;
/*      */           
/* 1546 */           Pointer p = rects[i].getPointer();
/* 1547 */           p.setShort(0L, (short)r.x);
/* 1548 */           p.setShort(2L, (short)r.y);
/* 1549 */           p.setShort(4L, (short)r.width);
/* 1550 */           p.setShort(6L, (short)r.height);
/* 1551 */           rects[i].setAutoSynch(false);
/*      */         } 
/*      */         
/* 1554 */         int UNMASKED = 1;
/* 1555 */         x11.XSetForeground(dpy, gc, new NativeLong(1L));
/* 1556 */         x11.XFillRectangles(dpy, (X11.Drawable)pm, gc, rects, rects.length);
/*      */       } finally {
/*      */         
/* 1559 */         x11.XFreeGC(dpy, gc);
/*      */       } 
/* 1561 */       return pm;
/*      */     }
/*      */ 
/*      */     
/* 1565 */     private long[] alphaVisualIDs = new long[0]; private static final long OPAQUE = 4294967295L;
/*      */     private static final String OPACITY = "_NET_WM_WINDOW_OPACITY";
/*      */     
/*      */     public boolean isWindowAlphaSupported() {
/* 1569 */       return ((getAlphaVisualIDs()).length > 0);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static long getVisualID(GraphicsConfiguration config) {
/*      */       try {
/* 1578 */         Object o = config.getClass().getMethod("getVisual", (Class[])null).invoke(config, (Object[])null);
/* 1579 */         return ((Number)o).longValue();
/*      */       }
/* 1581 */       catch (Exception e) {
/*      */         
/* 1583 */         e.printStackTrace();
/* 1584 */         return -1L;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public GraphicsConfiguration getAlphaCompatibleGraphicsConfiguration() {
/* 1591 */       if (isWindowAlphaSupported()) {
/*      */         
/* 1593 */         GraphicsEnvironment env = GraphicsEnvironment.getLocalGraphicsEnvironment();
/* 1594 */         GraphicsDevice[] devices = env.getScreenDevices();
/* 1595 */         for (int i = 0; i < devices.length; i++) {
/*      */           
/* 1597 */           GraphicsConfiguration[] configs = devices[i].getConfigurations();
/* 1598 */           for (int j = 0; j < configs.length; j++) {
/* 1599 */             long visualID = getVisualID(configs[j]);
/* 1600 */             long[] ids = getAlphaVisualIDs();
/* 1601 */             for (int k = 0; k < ids.length; k++) {
/* 1602 */               if (visualID == ids[k]) {
/* 1603 */                 return configs[j];
/*      */               }
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/* 1609 */       return super.getAlphaCompatibleGraphicsConfiguration();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private synchronized long[] getAlphaVisualIDs() {
/* 1617 */       if (this.didCheck) {
/* 1618 */         return this.alphaVisualIDs;
/*      */       }
/* 1620 */       this.didCheck = true;
/* 1621 */       X11 x11 = X11.INSTANCE;
/* 1622 */       X11.Display dpy = x11.XOpenDisplay(null);
/* 1623 */       if (dpy == null)
/* 1624 */         return this.alphaVisualIDs; 
/* 1625 */       X11.XVisualInfo info = null;
/*      */       try {
/* 1627 */         int screen = x11.XDefaultScreen(dpy);
/* 1628 */         X11.XVisualInfo template = new X11.XVisualInfo();
/* 1629 */         template.screen = screen;
/* 1630 */         template.depth = 32;
/* 1631 */         template.c_class = 4;
/* 1632 */         NativeLong mask = new NativeLong(14L);
/*      */ 
/*      */         
/* 1635 */         IntByReference pcount = new IntByReference();
/* 1636 */         info = x11.XGetVisualInfo(dpy, mask, template, pcount);
/* 1637 */         if (info != null) {
/* 1638 */           List<X11.VisualID> list = new ArrayList<X11.VisualID>();
/*      */           
/* 1640 */           X11.XVisualInfo[] infos = (X11.XVisualInfo[])info.toArray(pcount.getValue()); int i;
/* 1641 */           for (i = 0; i < infos.length; i++) {
/*      */             
/* 1643 */             X11.Xrender.XRenderPictFormat format = X11.Xrender.INSTANCE.XRenderFindVisualFormat(dpy, (infos[i]).visual);
/*      */             
/* 1645 */             if (format.type == 1 && format.direct.alphaMask != 0)
/*      */             {
/* 1647 */               list.add((infos[i]).visualid);
/*      */             }
/*      */           } 
/* 1650 */           this.alphaVisualIDs = new long[list.size()];
/* 1651 */           for (i = 0; i < this.alphaVisualIDs.length; i++) {
/* 1652 */             this.alphaVisualIDs[i] = ((Number)list.get(i)).longValue();
/*      */           }
/* 1654 */           return this.alphaVisualIDs;
/*      */         } 
/*      */       } finally {
/*      */         
/* 1658 */         if (info != null) {
/* 1659 */           x11.XFree(info.getPointer());
/*      */         }
/* 1661 */         x11.XCloseDisplay(dpy);
/*      */       } 
/* 1663 */       return this.alphaVisualIDs;
/*      */     }
/*      */ 
/*      */     
/*      */     private static X11.Window getContentWindow(Window w, X11.Display dpy, X11.Window win, Point offset) {
/* 1668 */       if ((w instanceof Frame && !((Frame)w).isUndecorated()) || (w instanceof Dialog && 
/* 1669 */         !((Dialog)w).isUndecorated())) {
/* 1670 */         X11 x11 = X11.INSTANCE;
/* 1671 */         X11.WindowByReference rootp = new X11.WindowByReference();
/* 1672 */         X11.WindowByReference parentp = new X11.WindowByReference();
/* 1673 */         PointerByReference childrenp = new PointerByReference();
/* 1674 */         IntByReference countp = new IntByReference();
/* 1675 */         x11.XQueryTree(dpy, win, rootp, parentp, childrenp, countp);
/* 1676 */         Pointer p = childrenp.getValue();
/* 1677 */         int[] ids = p.getIntArray(0L, countp.getValue());
/* 1678 */         int arrayOfInt1[] = ids, i = arrayOfInt1.length; byte b = 0; if (b < i) { int id = arrayOfInt1[b];
/*      */           
/* 1680 */           X11.Window child = new X11.Window(id);
/* 1681 */           X11.XWindowAttributes xwa = new X11.XWindowAttributes();
/* 1682 */           x11.XGetWindowAttributes(dpy, child, xwa);
/* 1683 */           offset.x = -xwa.x;
/* 1684 */           offset.y = -xwa.y;
/* 1685 */           win = child; }
/*      */ 
/*      */         
/* 1688 */         if (p != null) {
/* 1689 */           x11.XFree(p);
/*      */         }
/*      */       } 
/* 1692 */       return win;
/*      */     }
/*      */     
/*      */     private static X11.Window getDrawable(Component w) {
/* 1696 */       int id = (int)Native.getComponentID(w);
/* 1697 */       if (id == 0)
/* 1698 */         return null; 
/* 1699 */       return new X11.Window(id);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setWindowAlpha(final Window w, final float alpha) {
/* 1707 */       if (!isWindowAlphaSupported()) {
/* 1708 */         throw new UnsupportedOperationException("This X11 display does not provide a 32-bit visual");
/*      */       }
/* 1710 */       Runnable action = new Runnable()
/*      */         {
/*      */           public void run() {
/* 1713 */             X11 x11 = X11.INSTANCE;
/* 1714 */             X11.Display dpy = x11.XOpenDisplay(null);
/* 1715 */             if (dpy == null)
/*      */               return; 
/*      */             try {
/* 1718 */               X11.Window win = WindowUtils.X11WindowUtils.getDrawable(w);
/* 1719 */               if (alpha == 1.0F) {
/* 1720 */                 x11.XDeleteProperty(dpy, win, x11
/* 1721 */                     .XInternAtom(dpy, "_NET_WM_WINDOW_OPACITY", false));
/*      */               }
/*      */               else {
/*      */                 
/* 1725 */                 int opacity = (int)((long)(alpha * 4.2949673E9F) & 0xFFFFFFFFFFFFFFFFL);
/* 1726 */                 IntByReference patom = new IntByReference(opacity);
/* 1727 */                 x11.XChangeProperty(dpy, win, x11
/* 1728 */                     .XInternAtom(dpy, "_NET_WM_WINDOW_OPACITY", false), X11.XA_CARDINAL, 32, 0, patom
/*      */ 
/*      */ 
/*      */                     
/* 1732 */                     .getPointer(), 1);
/*      */               } 
/*      */             } finally {
/*      */               
/* 1736 */               x11.XCloseDisplay(dpy);
/*      */             } 
/*      */           }
/*      */         };
/* 1740 */       whenDisplayable(w, action);
/*      */     }
/*      */     private class X11TransparentContentPane extends WindowUtils.NativeWindowUtils.TransparentContentPane { private static final long serialVersionUID = 1L; private Memory buffer;
/*      */       private int[] pixels;
/*      */       private final int[] pixel;
/*      */       
/*      */       public X11TransparentContentPane(Container oldContent) {
/* 1747 */         super(oldContent);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1752 */         this.pixel = new int[4];
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       protected void paintDirect(BufferedImage buf, Rectangle bounds) {
/* 1758 */         Window window = SwingUtilities.getWindowAncestor(this);
/* 1759 */         X11 x11 = X11.INSTANCE;
/* 1760 */         X11.Display dpy = x11.XOpenDisplay(null);
/* 1761 */         X11.Window win = WindowUtils.X11WindowUtils.getDrawable(window);
/* 1762 */         Point offset = new Point();
/* 1763 */         win = WindowUtils.X11WindowUtils.getContentWindow(window, dpy, win, offset);
/* 1764 */         X11.GC gc = x11.XCreateGC(dpy, (X11.Drawable)win, new NativeLong(0L), null);
/*      */         
/* 1766 */         Raster raster = buf.getData();
/* 1767 */         int w = bounds.width;
/* 1768 */         int h = bounds.height;
/* 1769 */         if (this.buffer == null || this.buffer.size() != (w * h * 4)) {
/* 1770 */           this.buffer = new Memory((w * h * 4));
/* 1771 */           this.pixels = new int[w * h];
/*      */         } 
/* 1773 */         for (int y = 0; y < h; y++) {
/* 1774 */           for (int x = 0; x < w; x++) {
/* 1775 */             raster.getPixel(x, y, this.pixel);
/* 1776 */             int alpha = this.pixel[3] & 0xFF;
/* 1777 */             int red = this.pixel[2] & 0xFF;
/* 1778 */             int green = this.pixel[1] & 0xFF;
/* 1779 */             int blue = this.pixel[0] & 0xFF;
/*      */ 
/*      */             
/* 1782 */             this.pixels[y * w + x] = alpha << 24 | blue << 16 | green << 8 | red;
/*      */           } 
/*      */         } 
/* 1785 */         X11.XWindowAttributes xwa = new X11.XWindowAttributes();
/* 1786 */         x11.XGetWindowAttributes(dpy, win, xwa);
/*      */         
/* 1788 */         X11.XImage image = x11.XCreateImage(dpy, xwa.visual, 32, 2, 0, (Pointer)this.buffer, w, h, 32, w * 4);
/*      */         
/* 1790 */         this.buffer.write(0L, this.pixels, 0, this.pixels.length);
/* 1791 */         offset.x += bounds.x;
/* 1792 */         offset.y += bounds.y;
/* 1793 */         x11.XPutImage(dpy, (X11.Drawable)win, gc, image, 0, 0, offset.x, offset.y, w, h);
/*      */         
/* 1795 */         x11.XFree(image.getPointer());
/* 1796 */         x11.XFreeGC(dpy, gc);
/* 1797 */         x11.XCloseDisplay(dpy);
/*      */       } }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setWindowTransparent(final Window w, final boolean transparent) {
/* 1804 */       if (!(w instanceof RootPaneContainer)) {
/* 1805 */         throw new IllegalArgumentException("Window must be a RootPaneContainer");
/*      */       }
/* 1807 */       if (!isWindowAlphaSupported()) {
/* 1808 */         throw new UnsupportedOperationException("This X11 display does not provide a 32-bit visual");
/*      */       }
/*      */       
/* 1811 */       if (!w.getGraphicsConfiguration().equals(getAlphaCompatibleGraphicsConfiguration())) {
/* 1812 */         throw new IllegalArgumentException("Window GraphicsConfiguration '" + w.getGraphicsConfiguration() + "' does not support transparency");
/*      */       }
/*      */       
/* 1815 */       boolean isTransparent = (w.getBackground() != null && w.getBackground().getAlpha() == 0);
/* 1816 */       if (transparent == isTransparent)
/*      */         return; 
/* 1818 */       whenDisplayable(w, new Runnable()
/*      */           {
/*      */             public void run() {
/* 1821 */               JRootPane root = ((RootPaneContainer)w).getRootPane();
/* 1822 */               JLayeredPane lp = root.getLayeredPane();
/* 1823 */               Container content = root.getContentPane();
/* 1824 */               if (content instanceof WindowUtils.X11WindowUtils.X11TransparentContentPane) {
/* 1825 */                 ((WindowUtils.X11WindowUtils.X11TransparentContentPane)content).setTransparent(transparent);
/*      */               }
/* 1827 */               else if (transparent) {
/* 1828 */                 WindowUtils.X11WindowUtils.X11TransparentContentPane x11content = new WindowUtils.X11WindowUtils.X11TransparentContentPane(content);
/*      */                 
/* 1830 */                 root.setContentPane(x11content);
/* 1831 */                 lp.add(new WindowUtils.RepaintTrigger(x11content), JLayeredPane.DRAG_LAYER);
/*      */               } 
/*      */               
/* 1834 */               WindowUtils.X11WindowUtils.this.setLayersTransparent(w, transparent);
/* 1835 */               WindowUtils.X11WindowUtils.this.setForceHeavyweightPopups(w, transparent);
/* 1836 */               WindowUtils.X11WindowUtils.this.setDoubleBuffered(w, !transparent);
/*      */             }
/*      */           });
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void setWindowShape(final Window w, final PixmapSource src) {
/* 1846 */       Runnable action = new Runnable()
/*      */         {
/*      */           public void run() {
/* 1849 */             X11 x11 = X11.INSTANCE;
/* 1850 */             X11.Display dpy = x11.XOpenDisplay(null);
/* 1851 */             if (dpy == null) {
/*      */               return;
/*      */             }
/* 1854 */             X11.Pixmap pm = null;
/*      */             try {
/* 1856 */               X11.Window win = WindowUtils.X11WindowUtils.getDrawable(w);
/* 1857 */               pm = src.getPixmap(dpy, win);
/* 1858 */               X11.Xext ext = X11.Xext.INSTANCE;
/* 1859 */               ext.XShapeCombineMask(dpy, win, 0, 0, 0, (pm == null) ? X11.Pixmap.None : pm, 0);
/*      */             
/*      */             }
/*      */             finally {
/*      */               
/* 1864 */               if (pm != null) {
/* 1865 */                 x11.XFreePixmap(dpy, pm);
/*      */               }
/* 1867 */               x11.XCloseDisplay(dpy);
/*      */             } 
/* 1869 */             WindowUtils.X11WindowUtils.this.setForceHeavyweightPopups(WindowUtils.X11WindowUtils.this.getWindow(w), (pm != null));
/*      */           }
/*      */         };
/* 1872 */       whenDisplayable(w, action);
/*      */     }
/*      */ 
/*      */     
/*      */     protected void setMask(Component w, final Raster raster) {
/* 1877 */       setWindowShape(getWindow(w), new PixmapSource()
/*      */           {
/*      */             public X11.Pixmap getPixmap(X11.Display dpy, X11.Window win) {
/* 1880 */               return (raster != null) ? WindowUtils.X11WindowUtils.createBitmap(dpy, win, raster) : null;
/*      */             }
/*      */           });
/*      */     }
/*      */     
/*      */     private X11WindowUtils() {}
/*      */     
/*      */     private static interface PixmapSource {
/*      */       X11.Pixmap getPixmap(X11.Display param2Display, X11.Window param2Window); }
/*      */   }
/*      */   
/*      */   public static void setWindowMask(Window w, Shape mask) {
/* 1892 */     getInstance().setWindowMask(w, mask);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setComponentMask(Component c, Shape mask) {
/* 1901 */     getInstance().setWindowMask(c, mask);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setWindowMask(Window w, Icon mask) {
/* 1910 */     getInstance().setWindowMask(w, mask);
/*      */   }
/*      */ 
/*      */   
/*      */   public static boolean isWindowAlphaSupported() {
/* 1915 */     return getInstance().isWindowAlphaSupported();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static GraphicsConfiguration getAlphaCompatibleGraphicsConfiguration() {
/* 1923 */     return getInstance().getAlphaCompatibleGraphicsConfiguration();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setWindowAlpha(Window w, float alpha) {
/* 1941 */     getInstance().setWindowAlpha(w, Math.max(0.0F, Math.min(alpha, 1.0F)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setWindowTransparent(Window w, boolean transparent) {
/* 1957 */     getInstance().setWindowTransparent(w, transparent);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage getWindowIcon(WinDef.HWND hwnd) {
/* 1970 */     return getInstance().getWindowIcon(hwnd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Dimension getIconSize(WinDef.HICON hIcon) {
/* 1982 */     return getInstance().getIconSize(hIcon);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<DesktopWindow> getAllWindows(boolean onlyVisibleWindows) {
/* 2000 */     return getInstance().getAllWindows(onlyVisibleWindows);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getWindowTitle(WinDef.HWND hwnd) {
/* 2013 */     return getInstance().getWindowTitle(hwnd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getProcessFilePath(WinDef.HWND hwnd) {
/* 2027 */     return getInstance().getProcessFilePath(hwnd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Rectangle getWindowLocationAndSize(WinDef.HWND hwnd) {
/* 2039 */     return getInstance().getWindowLocationAndSize(hwnd);
/*      */   }
/*      */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\com\sun\jna\platform\WindowUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */