package com.sun.jna.platform.dnd;

import java.awt.Point;
import java.awt.dnd.DropTargetEvent;

public interface DropTargetPainter {
  void paintDropTarget(DropTargetEvent paramDropTargetEvent, int paramInt, Point paramPoint);
}


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\com\sun\jna\platform\dnd\DropTargetPainter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */