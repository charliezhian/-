/*      */ package com.sun.jna.platform.win32;
/*      */ 
/*      */ import com.sun.jna.IntegerType;
/*      */ import com.sun.jna.Native;
/*      */ import com.sun.jna.Pointer;
/*      */ import com.sun.jna.PointerType;
/*      */ import com.sun.jna.Structure;
/*      */ import com.sun.jna.Structure.FieldOrder;
/*      */ import java.awt.Rectangle;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public interface WinDef
/*      */ {
/*      */   public static final int MAX_PATH = 260;
/*      */   
/*      */   public static class WORD
/*      */     extends IntegerType
/*      */     implements Comparable<WORD>
/*      */   {
/*      */     public static final int SIZE = 2;
/*      */     
/*      */     public WORD() {
/*   63 */       this(0L);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public WORD(long value) {
/*   73 */       super(2, value, true);
/*      */     }
/*      */ 
/*      */     
/*      */     public int compareTo(WORD other) {
/*   78 */       return compare(this, other);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class WORDByReference
/*      */     extends com.sun.jna.ptr.ByReference
/*      */   {
/*      */     public WORDByReference() {
/*   91 */       this(new WinDef.WORD(0L));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public WORDByReference(WinDef.WORD value) {
/*  100 */       super(2);
/*  101 */       setValue(value);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setValue(WinDef.WORD value) {
/*  110 */       getPointer().setShort(0L, value.shortValue());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public WinDef.WORD getValue() {
/*  119 */       return new WinDef.WORD(getPointer().getShort(0L));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class DWORD
/*      */     extends IntegerType
/*      */     implements Comparable<DWORD>
/*      */   {
/*      */     public static final int SIZE = 4;
/*      */ 
/*      */ 
/*      */     
/*      */     public DWORD() {
/*  135 */       this(0L);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public DWORD(long value) {
/*  145 */       super(4, value, true);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public WinDef.WORD getLow() {
/*  154 */       return new WinDef.WORD(longValue() & 0xFFFFL);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public WinDef.WORD getHigh() {
/*  163 */       return new WinDef.WORD(longValue() >> 16L & 0xFFFFL);
/*      */     }
/*      */ 
/*      */     
/*      */     public int compareTo(DWORD other) {
/*  168 */       return compare(this, other);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class DWORDByReference
/*      */     extends com.sun.jna.ptr.ByReference
/*      */   {
/*      */     public DWORDByReference() {
/*  181 */       this(new WinDef.DWORD(0L));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public DWORDByReference(WinDef.DWORD value) {
/*  190 */       super(4);
/*  191 */       setValue(value);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setValue(WinDef.DWORD value) {
/*  200 */       getPointer().setInt(0L, value.intValue());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public WinDef.DWORD getValue() {
/*  209 */       return new WinDef.DWORD(getPointer().getInt(0L));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static class LONG
/*      */     extends IntegerType
/*      */     implements Comparable<LONG>
/*      */   {
/*  219 */     public static final int SIZE = Native.LONG_SIZE;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public LONG() {
/*  225 */       this(0L);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public LONG(long value) {
/*  234 */       super(SIZE, value);
/*      */     }
/*      */ 
/*      */     
/*      */     public int compareTo(LONG other) {
/*  239 */       return compare(this, other);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class LONGByReference
/*      */     extends com.sun.jna.ptr.ByReference
/*      */   {
/*      */     public LONGByReference() {
/*  252 */       this(new WinDef.LONG(0L));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public LONGByReference(WinDef.LONG value) {
/*  261 */       super(WinDef.LONG.SIZE);
/*  262 */       setValue(value);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setValue(WinDef.LONG value) {
/*  271 */       getPointer().setInt(0L, value.intValue());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public WinDef.LONG getValue() {
/*  280 */       return new WinDef.LONG(getPointer().getInt(0L));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static class LONGLONG
/*      */     extends IntegerType
/*      */     implements Comparable<LONGLONG>
/*      */   {
/*  290 */     public static final int SIZE = Native.LONG_SIZE * 2;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public LONGLONG() {
/*  296 */       this(0L);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public LONGLONG(long value) {
/*  305 */       super(8, value, false);
/*      */     }
/*      */ 
/*      */     
/*      */     public int compareTo(LONGLONG other) {
/*  310 */       return compare(this, other);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class LONGLONGByReference
/*      */     extends com.sun.jna.ptr.ByReference
/*      */   {
/*      */     public LONGLONGByReference() {
/*  323 */       this(new WinDef.LONGLONG(0L));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public LONGLONGByReference(WinDef.LONGLONG value) {
/*  332 */       super(WinDef.LONGLONG.SIZE);
/*  333 */       setValue(value);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setValue(WinDef.LONGLONG value) {
/*  342 */       getPointer().setLong(0L, value.longValue());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public WinDef.LONGLONG getValue() {
/*  351 */       return new WinDef.LONGLONG(getPointer().getLong(0L));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class HDC
/*      */     extends WinNT.HANDLE
/*      */   {
/*      */     public HDC() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HDC(Pointer p) {
/*  374 */       super(p);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class HICON
/*      */     extends WinNT.HANDLE
/*      */   {
/*      */     public HICON() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HICON(WinNT.HANDLE handle) {
/*  399 */       this(handle.getPointer());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HICON(Pointer p) {
/*  409 */       super(p);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class HCURSOR
/*      */     extends HICON
/*      */   {
/*      */     public HCURSOR() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HCURSOR(Pointer p) {
/*  432 */       super(p);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class HMENU
/*      */     extends WinNT.HANDLE
/*      */   {
/*      */     public HMENU() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HMENU(Pointer p) {
/*  455 */       super(p);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class HPEN
/*      */     extends WinNT.HANDLE
/*      */   {
/*      */     public HPEN() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HPEN(Pointer p) {
/*  478 */       super(p);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class HRSRC
/*      */     extends WinNT.HANDLE
/*      */   {
/*      */     public HRSRC() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HRSRC(Pointer p) {
/*  501 */       super(p);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class HPALETTE
/*      */     extends WinNT.HANDLE
/*      */   {
/*      */     public HPALETTE() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HPALETTE(Pointer p) {
/*  524 */       super(p);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class HBITMAP
/*      */     extends WinNT.HANDLE
/*      */   {
/*      */     public HBITMAP() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HBITMAP(Pointer p) {
/*  547 */       super(p);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class HRGN
/*      */     extends WinNT.HANDLE
/*      */   {
/*      */     public HRGN() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HRGN(Pointer p) {
/*  570 */       super(p);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class HWND
/*      */     extends WinNT.HANDLE
/*      */   {
/*      */     public HWND() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HWND(Pointer p) {
/*  593 */       super(p);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class HINSTANCE
/*      */     extends WinNT.HANDLE {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class HMODULE
/*      */     extends HINSTANCE {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class HFONT
/*      */     extends WinNT.HANDLE
/*      */   {
/*      */     public HFONT() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HFONT(Pointer p) {
/*  630 */       super(p);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class LPARAM
/*      */     extends BaseTSD.LONG_PTR
/*      */   {
/*      */     public LPARAM() {
/*  643 */       this(0L);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public LPARAM(long value) {
/*  653 */       super(value);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class LRESULT
/*      */     extends BaseTSD.LONG_PTR
/*      */   {
/*      */     public LRESULT() {
/*  666 */       this(0L);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public LRESULT(long value) {
/*  676 */       super(value);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class INT_PTR
/*      */     extends IntegerType
/*      */   {
/*      */     public INT_PTR() {
/*  687 */       super(Native.POINTER_SIZE);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public INT_PTR(long value) {
/*  697 */       super(Native.POINTER_SIZE, value);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Pointer toPointer() {
/*  706 */       return Pointer.createConstant(longValue());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class UINT_PTR
/*      */     extends IntegerType
/*      */   {
/*      */     public UINT_PTR() {
/*  719 */       super(Native.POINTER_SIZE);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public UINT_PTR(long value) {
/*  729 */       super(Native.POINTER_SIZE, value, true);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Pointer toPointer() {
/*  738 */       return Pointer.createConstant(longValue());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class WPARAM
/*      */     extends UINT_PTR
/*      */   {
/*      */     public WPARAM() {
/*  751 */       this(0L);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public WPARAM(long value) {
/*  761 */       super(value);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @FieldOrder({"left", "top", "right", "bottom"})
/*      */   public static class RECT
/*      */     extends Structure
/*      */   {
/*      */     public int left;
/*      */ 
/*      */ 
/*      */     
/*      */     public int top;
/*      */ 
/*      */ 
/*      */     
/*      */     public int right;
/*      */ 
/*      */     
/*      */     public int bottom;
/*      */ 
/*      */ 
/*      */     
/*      */     public Rectangle toRectangle() {
/*  788 */       return new Rectangle(this.left, this.top, this.right - this.left, this.bottom - this.top);
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/*  793 */       return "[(" + this.left + "," + this.top + ")(" + this.right + "," + this.bottom + ")]";
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static class ULONG
/*      */     extends IntegerType
/*      */     implements Comparable<ULONG>
/*      */   {
/*  803 */     public static final int SIZE = Native.LONG_SIZE;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ULONG() {
/*  809 */       this(0L);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ULONG(long value) {
/*  819 */       super(SIZE, value, true);
/*      */     }
/*      */ 
/*      */     
/*      */     public int compareTo(ULONG other) {
/*  824 */       return compare(this, other);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class ULONGByReference
/*      */     extends com.sun.jna.ptr.ByReference
/*      */   {
/*      */     public ULONGByReference() {
/*  837 */       this(new WinDef.ULONG(0L));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ULONGByReference(WinDef.ULONG value) {
/*  846 */       super(WinDef.ULONG.SIZE);
/*  847 */       setValue(value);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setValue(WinDef.ULONG value) {
/*  856 */       getPointer().setInt(0L, value.intValue());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public WinDef.ULONG getValue() {
/*  865 */       return new WinDef.ULONG(getPointer().getInt(0L));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static class ULONGLONG
/*      */     extends IntegerType
/*      */     implements Comparable<ULONGLONG>
/*      */   {
/*  875 */     public static final int SIZE = Native.LONG_SIZE * 2;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ULONGLONG() {
/*  881 */       this(0L);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ULONGLONG(long value) {
/*  890 */       super(SIZE, value, true);
/*      */     }
/*      */ 
/*      */     
/*      */     public int compareTo(ULONGLONG other) {
/*  895 */       return compare(this, other);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class ULONGLONGByReference
/*      */     extends com.sun.jna.ptr.ByReference
/*      */   {
/*      */     public ULONGLONGByReference() {
/*  908 */       this(new WinDef.ULONGLONG(0L));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ULONGLONGByReference(WinDef.ULONGLONG value) {
/*  917 */       super(WinDef.ULONGLONG.SIZE);
/*  918 */       setValue(value);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setValue(WinDef.ULONGLONG value) {
/*  927 */       getPointer().setLong(0L, value.longValue());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public WinDef.ULONGLONG getValue() {
/*  936 */       return new WinDef.ULONGLONG(getPointer().getLong(0L));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class DWORDLONG
/*      */     extends IntegerType
/*      */     implements Comparable<DWORDLONG>
/*      */   {
/*      */     public static final int SIZE = 8;
/*      */ 
/*      */ 
/*      */     
/*      */     public DWORDLONG() {
/*  952 */       this(0L);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public DWORDLONG(long value) {
/*  962 */       super(8, value, true);
/*      */     }
/*      */ 
/*      */     
/*      */     public int compareTo(DWORDLONG other) {
/*  967 */       return compare(this, other);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class HBRUSH
/*      */     extends WinNT.HANDLE
/*      */   {
/*      */     public HBRUSH() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HBRUSH(Pointer p) {
/*  990 */       super(p);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class ATOM
/*      */     extends WORD
/*      */   {
/*      */     public ATOM() {
/* 1003 */       this(0L);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ATOM(long value) {
/* 1013 */       super(value);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class PVOID
/*      */     extends PointerType
/*      */   {
/*      */     public PVOID() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public PVOID(Pointer pointer) {
/* 1032 */       super(pointer);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class LPVOID
/*      */     extends PointerType
/*      */   {
/*      */     public LPVOID() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public LPVOID(Pointer p) {
/* 1053 */       super(p);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   @FieldOrder({"x", "y"})
/*      */   public static class POINT
/*      */     extends Structure
/*      */   {
/*      */     public int x;
/*      */     public int y;
/*      */     
/*      */     public static class ByReference
/*      */       extends POINT
/*      */       implements Structure.ByReference
/*      */     {
/*      */       public ByReference() {}
/*      */       
/*      */       public ByReference(Pointer memory) {
/* 1072 */         super(memory);
/*      */       }
/*      */       
/*      */       public ByReference(int x, int y) {
/* 1076 */         super(x, y);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public static class ByValue
/*      */       extends POINT
/*      */       implements Structure.ByValue
/*      */     {
/*      */       public ByValue() {}
/*      */ 
/*      */       
/*      */       public ByValue(Pointer memory) {
/* 1090 */         super(memory);
/*      */       }
/*      */       
/*      */       public ByValue(int x, int y) {
/* 1094 */         super(x, y);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public POINT() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public POINT(Pointer memory) {
/* 1117 */       super(memory);
/* 1118 */       read();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public POINT(int x, int y) {
/* 1130 */       this.x = x;
/* 1131 */       this.y = y;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class USHORT
/*      */     extends IntegerType
/*      */     implements Comparable<USHORT>
/*      */   {
/*      */     public static final int SIZE = 2;
/*      */ 
/*      */ 
/*      */     
/*      */     public USHORT() {
/* 1147 */       this(0L);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public USHORT(long value) {
/* 1157 */       super(2, value, true);
/*      */     }
/*      */ 
/*      */     
/*      */     public int compareTo(USHORT other) {
/* 1162 */       return compare(this, other);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class USHORTByReference
/*      */     extends com.sun.jna.ptr.ByReference
/*      */   {
/*      */     public USHORTByReference() {
/* 1175 */       this(new WinDef.USHORT(0L));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public USHORTByReference(WinDef.USHORT value) {
/* 1184 */       super(2);
/* 1185 */       setValue(value);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public USHORTByReference(short value) {
/* 1194 */       super(2);
/* 1195 */       setValue(new WinDef.USHORT(value));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setValue(WinDef.USHORT value) {
/* 1204 */       getPointer().setShort(0L, value.shortValue());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public WinDef.USHORT getValue() {
/* 1213 */       return new WinDef.USHORT(getPointer().getShort(0L));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class SHORT
/*      */     extends IntegerType
/*      */     implements Comparable<SHORT>
/*      */   {
/*      */     public static final int SIZE = 2;
/*      */ 
/*      */ 
/*      */     
/*      */     public SHORT() {
/* 1229 */       this(0L);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public SHORT(long value) {
/* 1239 */       super(2, value, false);
/*      */     }
/*      */ 
/*      */     
/*      */     public int compareTo(SHORT other) {
/* 1244 */       return compare(this, other);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class UINT
/*      */     extends IntegerType
/*      */     implements Comparable<UINT>
/*      */   {
/*      */     public static final int SIZE = 4;
/*      */ 
/*      */ 
/*      */     
/*      */     public UINT() {
/* 1260 */       this(0L);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public UINT(long value) {
/* 1270 */       super(4, value, true);
/*      */     }
/*      */ 
/*      */     
/*      */     public int compareTo(UINT other) {
/* 1275 */       return compare(this, other);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class UINTByReference
/*      */     extends com.sun.jna.ptr.ByReference
/*      */   {
/*      */     public UINTByReference() {
/* 1288 */       this(new WinDef.UINT(0L));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public UINTByReference(WinDef.UINT value) {
/* 1297 */       super(4);
/* 1298 */       setValue(value);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setValue(WinDef.UINT value) {
/* 1307 */       getPointer().setInt(0L, value.intValue());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public WinDef.UINT getValue() {
/* 1316 */       return new WinDef.UINT(getPointer().getInt(0L));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class SCODE
/*      */     extends ULONG
/*      */   {
/*      */     public SCODE() {
/* 1329 */       this(0L);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public SCODE(long value) {
/* 1339 */       super(value);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class SCODEByReference
/*      */     extends com.sun.jna.ptr.ByReference
/*      */   {
/*      */     public SCODEByReference() {
/* 1352 */       this(new WinDef.SCODE(0L));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public SCODEByReference(WinDef.SCODE value) {
/* 1361 */       super(WinDef.SCODE.SIZE);
/* 1362 */       setValue(value);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setValue(WinDef.SCODE value) {
/* 1371 */       getPointer().setInt(0L, value.intValue());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public WinDef.SCODE getValue() {
/* 1380 */       return new WinDef.SCODE(getPointer().getInt(0L));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class LCID
/*      */     extends DWORD
/*      */   {
/*      */     public LCID() {
/* 1393 */       super(0L);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public LCID(long value) {
/* 1402 */       super(value);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class BOOL
/*      */     extends IntegerType
/*      */     implements Comparable<BOOL>
/*      */   {
/*      */     public static final int SIZE = 4;
/*      */ 
/*      */ 
/*      */     
/*      */     public BOOL() {
/* 1418 */       this(0L);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public BOOL(boolean value) {
/* 1427 */       this(value ? 1L : 0L);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public BOOL(long value) {
/* 1436 */       super(4, value, false);
/* 1437 */       assert value == 0L || value == 1L;
/*      */     }
/*      */     
/*      */     public boolean booleanValue() {
/* 1441 */       if (intValue() > 0) {
/* 1442 */         return true;
/*      */       }
/* 1444 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1450 */       return Boolean.toString(booleanValue());
/*      */     }
/*      */ 
/*      */     
/*      */     public int compareTo(BOOL other) {
/* 1455 */       return compare(this, other);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static int compare(BOOL v1, BOOL v2) {
/* 1472 */       if (v1 == v2)
/* 1473 */         return 0; 
/* 1474 */       if (v1 == null)
/* 1475 */         return 1; 
/* 1476 */       if (v2 == null) {
/* 1477 */         return -1;
/*      */       }
/* 1479 */       return compare(v1.booleanValue(), v2.booleanValue());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static int compare(BOOL v1, boolean v2) {
/* 1495 */       if (v1 == null) {
/* 1496 */         return 1;
/*      */       }
/* 1498 */       return compare(v1.booleanValue(), v2);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public static int compare(boolean v1, boolean v2) {
/* 1504 */       if (v1 == v2)
/* 1505 */         return 0; 
/* 1506 */       if (v1) {
/* 1507 */         return 1;
/*      */       }
/* 1509 */       return -1;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class BOOLByReference
/*      */     extends com.sun.jna.ptr.ByReference
/*      */   {
/*      */     public BOOLByReference() {
/* 1523 */       this(new WinDef.BOOL(0L));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public BOOLByReference(WinDef.BOOL value) {
/* 1532 */       super(4);
/* 1533 */       setValue(value);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setValue(WinDef.BOOL value) {
/* 1542 */       getPointer().setInt(0L, value.intValue());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public WinDef.BOOL getValue() {
/* 1551 */       return new WinDef.BOOL(getPointer().getInt(0L));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class UCHAR
/*      */     extends IntegerType
/*      */     implements Comparable<UCHAR>
/*      */   {
/*      */     public static final int SIZE = 1;
/*      */ 
/*      */ 
/*      */     
/*      */     public UCHAR() {
/* 1567 */       this(0L);
/*      */     }
/*      */     
/*      */     public UCHAR(char ch) {
/* 1571 */       this((ch & 0xFF));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public UCHAR(long value) {
/* 1580 */       super(1, value, true);
/*      */     }
/*      */ 
/*      */     
/*      */     public int compareTo(UCHAR other) {
/* 1585 */       return compare(this, other);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class BYTE
/*      */     extends UCHAR
/*      */   {
/*      */     public BYTE() {
/* 1598 */       this(0L);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public BYTE(long value) {
/* 1607 */       super(value);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class CHAR
/*      */     extends IntegerType
/*      */     implements Comparable<CHAR>
/*      */   {
/*      */     public static final int SIZE = 1;
/*      */ 
/*      */ 
/*      */     
/*      */     public CHAR() {
/* 1623 */       this(0L);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public CHAR(byte ch) {
/* 1632 */       this((ch & 0xFF));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public CHAR(long value) {
/* 1641 */       super(1, value, false);
/*      */     }
/*      */ 
/*      */     
/*      */     public int compareTo(CHAR other) {
/* 1646 */       return compare(this, other);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class CHARByReference
/*      */     extends com.sun.jna.ptr.ByReference
/*      */   {
/*      */     public CHARByReference() {
/* 1659 */       this(new WinDef.CHAR(0L));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public CHARByReference(WinDef.CHAR value) {
/* 1668 */       super(1);
/* 1669 */       setValue(value);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setValue(WinDef.CHAR value) {
/* 1678 */       getPointer().setByte(0L, value.byteValue());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public WinDef.CHAR getValue() {
/* 1687 */       return new WinDef.CHAR(getPointer().getChar(0L));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class HGLRC
/*      */     extends WinNT.HANDLE
/*      */   {
/*      */     public HGLRC() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HGLRC(Pointer p) {
/* 1710 */       super(p);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class HGLRCByReference
/*      */     extends WinNT.HANDLEByReference
/*      */   {
/*      */     public HGLRCByReference() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HGLRCByReference(WinDef.HGLRC h) {
/* 1733 */       super(h);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\com\sun\jna\platform\win32\WinDef.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */