/*     */ package com.sun.jna.platform.win32;
/*     */ 
/*     */ import com.sun.jna.Pointer;
/*     */ import com.sun.jna.PointerType;
/*     */ import com.sun.jna.Structure;
/*     */ import com.sun.jna.Structure.FieldOrder;
/*     */ import java.security.SecureRandom;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface Guid
/*     */ {
/*  42 */   public static final IID IID_NULL = new IID();
/*     */   
/*     */   @FieldOrder({"Data1", "Data2", "Data3", "Data4"})
/*     */   public static class GUID
/*     */     extends Structure {
/*     */     public int Data1;
/*     */     public short Data2;
/*     */     public short Data3;
/*     */     
/*     */     public static class ByValue
/*     */       extends GUID
/*     */       implements Structure.ByValue {
/*     */       public ByValue() {}
/*     */       
/*     */       public ByValue(Guid.GUID guid) {
/*  57 */         super(guid.getPointer());
/*     */         
/*  59 */         this.Data1 = guid.Data1;
/*  60 */         this.Data2 = guid.Data2;
/*  61 */         this.Data3 = guid.Data3;
/*  62 */         this.Data4 = guid.Data4;
/*     */       }
/*     */       public ByValue(Pointer memory) {
/*  65 */         super(memory);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static class ByReference
/*     */       extends GUID
/*     */       implements Structure.ByReference
/*     */     {
/*     */       public ByReference() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public ByReference(Guid.GUID guid) {
/*  90 */         super(guid.getPointer());
/*     */         
/*  92 */         this.Data1 = guid.Data1;
/*  93 */         this.Data2 = guid.Data2;
/*  94 */         this.Data3 = guid.Data3;
/*  95 */         this.Data4 = guid.Data4;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public ByReference(Pointer memory) {
/* 105 */         super(memory);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 119 */     public byte[] Data4 = new byte[8];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public GUID() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public GUID(GUID guid) {
/* 134 */       this.Data1 = guid.Data1;
/* 135 */       this.Data2 = guid.Data2;
/* 136 */       this.Data3 = guid.Data3;
/* 137 */       this.Data4 = guid.Data4;
/*     */       
/* 139 */       writeFieldsToMemory();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public GUID(String guid) {
/* 149 */       this(fromString(guid));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public GUID(byte[] data) {
/* 159 */       this(fromBinary(data));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public GUID(Pointer memory) {
/* 169 */       super(memory);
/* 170 */       read();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 175 */       if (o == null) {
/* 176 */         return false;
/*     */       }
/* 178 */       if (this == o) {
/* 179 */         return true;
/*     */       }
/* 181 */       if (getClass() != o.getClass()) {
/* 182 */         return false;
/*     */       }
/*     */       
/* 185 */       GUID other = (GUID)o;
/* 186 */       return (this.Data1 == other.Data1 && this.Data2 == other.Data2 && this.Data3 == other.Data3 && 
/*     */ 
/*     */         
/* 189 */         Arrays.equals(this.Data4, other.Data4));
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 194 */       return this.Data1 + this.Data2 & 65535 + this.Data3 & 65535 + Arrays.hashCode(this.Data4);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static GUID fromBinary(byte[] data) {
/* 205 */       if (data.length != 16) {
/* 206 */         throw new IllegalArgumentException("Invalid data length: " + data.length);
/*     */       }
/*     */ 
/*     */       
/* 210 */       GUID newGuid = new GUID();
/* 211 */       long data1Temp = (data[0] & 0xFF);
/* 212 */       data1Temp <<= 8L;
/* 213 */       data1Temp |= (data[1] & 0xFF);
/* 214 */       data1Temp <<= 8L;
/* 215 */       data1Temp |= (data[2] & 0xFF);
/* 216 */       data1Temp <<= 8L;
/* 217 */       data1Temp |= (data[3] & 0xFF);
/* 218 */       newGuid.Data1 = (int)data1Temp;
/*     */       
/* 220 */       int data2Temp = data[4] & 0xFF;
/* 221 */       data2Temp <<= 8;
/* 222 */       data2Temp |= data[5] & 0xFF;
/* 223 */       newGuid.Data2 = (short)data2Temp;
/*     */       
/* 225 */       int data3Temp = data[6] & 0xFF;
/* 226 */       data3Temp <<= 8;
/* 227 */       data3Temp |= data[7] & 0xFF;
/* 228 */       newGuid.Data3 = (short)data3Temp;
/*     */       
/* 230 */       newGuid.Data4[0] = data[8];
/* 231 */       newGuid.Data4[1] = data[9];
/* 232 */       newGuid.Data4[2] = data[10];
/* 233 */       newGuid.Data4[3] = data[11];
/* 234 */       newGuid.Data4[4] = data[12];
/* 235 */       newGuid.Data4[5] = data[13];
/* 236 */       newGuid.Data4[6] = data[14];
/* 237 */       newGuid.Data4[7] = data[15];
/*     */       
/* 239 */       newGuid.writeFieldsToMemory();
/*     */       
/* 241 */       return newGuid;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static GUID fromString(String guid) {
/* 252 */       int y = 0;
/* 253 */       char[] _cnewguid = new char[32];
/* 254 */       char[] _cguid = guid.toCharArray();
/* 255 */       byte[] bdata = new byte[16];
/* 256 */       GUID newGuid = new GUID();
/*     */ 
/*     */       
/* 259 */       if (guid.length() > 38) {
/* 260 */         throw new IllegalArgumentException("Invalid guid length: " + guid
/* 261 */             .length());
/*     */       }
/*     */       
/*     */       int i;
/* 265 */       for (i = 0; i < _cguid.length; i++) {
/* 266 */         if (_cguid[i] != '{' && _cguid[i] != '-' && _cguid[i] != '}')
/*     */         {
/* 268 */           _cnewguid[y++] = _cguid[i];
/*     */         }
/*     */       } 
/*     */       
/* 272 */       for (i = 0; i < 32; i += 2) {
/* 273 */         bdata[i / 2] = 
/* 274 */           (byte)((Character.digit(_cnewguid[i], 16) << 4) + Character.digit(_cnewguid[i + 1], 16) & 0xFF);
/*     */       }
/*     */       
/* 277 */       if (bdata.length != 16) {
/* 278 */         throw new IllegalArgumentException("Invalid data length: " + bdata.length);
/*     */       }
/*     */ 
/*     */       
/* 282 */       long data1Temp = (bdata[0] & 0xFF);
/* 283 */       data1Temp <<= 8L;
/* 284 */       data1Temp |= (bdata[1] & 0xFF);
/* 285 */       data1Temp <<= 8L;
/* 286 */       data1Temp |= (bdata[2] & 0xFF);
/* 287 */       data1Temp <<= 8L;
/* 288 */       data1Temp |= (bdata[3] & 0xFF);
/* 289 */       newGuid.Data1 = (int)data1Temp;
/*     */       
/* 291 */       int data2Temp = bdata[4] & 0xFF;
/* 292 */       data2Temp <<= 8;
/* 293 */       data2Temp |= bdata[5] & 0xFF;
/* 294 */       newGuid.Data2 = (short)data2Temp;
/*     */       
/* 296 */       int data3Temp = bdata[6] & 0xFF;
/* 297 */       data3Temp <<= 8;
/* 298 */       data3Temp |= bdata[7] & 0xFF;
/* 299 */       newGuid.Data3 = (short)data3Temp;
/*     */       
/* 301 */       newGuid.Data4[0] = bdata[8];
/* 302 */       newGuid.Data4[1] = bdata[9];
/* 303 */       newGuid.Data4[2] = bdata[10];
/* 304 */       newGuid.Data4[3] = bdata[11];
/* 305 */       newGuid.Data4[4] = bdata[12];
/* 306 */       newGuid.Data4[5] = bdata[13];
/* 307 */       newGuid.Data4[6] = bdata[14];
/* 308 */       newGuid.Data4[7] = bdata[15];
/*     */       
/* 310 */       newGuid.writeFieldsToMemory();
/*     */       
/* 312 */       return newGuid;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static GUID newGuid() {
/* 322 */       SecureRandom ng = new SecureRandom();
/* 323 */       byte[] randomBytes = new byte[16];
/*     */       
/* 325 */       ng.nextBytes(randomBytes);
/* 326 */       randomBytes[6] = (byte)(randomBytes[6] & 0xF);
/* 327 */       randomBytes[6] = (byte)(randomBytes[6] | 0x40);
/* 328 */       randomBytes[8] = (byte)(randomBytes[8] & 0x3F);
/* 329 */       randomBytes[8] = (byte)(randomBytes[8] | 0x80);
/*     */       
/* 331 */       return new GUID(randomBytes);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public byte[] toByteArray() {
/* 340 */       byte[] guid = new byte[16];
/*     */       
/* 342 */       byte[] bytes1 = new byte[4];
/* 343 */       bytes1[0] = (byte)(this.Data1 >> 24);
/* 344 */       bytes1[1] = (byte)(this.Data1 >> 16);
/* 345 */       bytes1[2] = (byte)(this.Data1 >> 8);
/* 346 */       bytes1[3] = (byte)(this.Data1 >> 0);
/*     */       
/* 348 */       byte[] bytes2 = new byte[4];
/* 349 */       bytes2[0] = (byte)(this.Data2 >> 24);
/* 350 */       bytes2[1] = (byte)(this.Data2 >> 16);
/* 351 */       bytes2[2] = (byte)(this.Data2 >> 8);
/* 352 */       bytes2[3] = (byte)(this.Data2 >> 0);
/*     */       
/* 354 */       byte[] bytes3 = new byte[4];
/* 355 */       bytes3[0] = (byte)(this.Data3 >> 24);
/* 356 */       bytes3[1] = (byte)(this.Data3 >> 16);
/* 357 */       bytes3[2] = (byte)(this.Data3 >> 8);
/* 358 */       bytes3[3] = (byte)(this.Data3 >> 0);
/*     */       
/* 360 */       System.arraycopy(bytes1, 0, guid, 0, 4);
/* 361 */       System.arraycopy(bytes2, 2, guid, 4, 2);
/* 362 */       System.arraycopy(bytes3, 2, guid, 6, 2);
/* 363 */       System.arraycopy(this.Data4, 0, guid, 8, 8);
/*     */       
/* 365 */       return guid;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toGuidString() {
/* 375 */       String HEXES = "0123456789ABCDEF";
/* 376 */       byte[] bGuid = toByteArray();
/*     */       
/* 378 */       StringBuilder hexStr = new StringBuilder(2 * bGuid.length);
/* 379 */       hexStr.append("{");
/*     */       
/* 381 */       for (int i = 0; i < bGuid.length; i++) {
/* 382 */         char ch1 = "0123456789ABCDEF".charAt((bGuid[i] & 0xF0) >> 4);
/* 383 */         char ch2 = "0123456789ABCDEF".charAt(bGuid[i] & 0xF);
/* 384 */         hexStr.append(ch1).append(ch2);
/*     */         
/* 386 */         if (i == 3 || i == 5 || i == 7 || i == 9) {
/* 387 */           hexStr.append("-");
/*     */         }
/*     */       } 
/* 390 */       hexStr.append("}");
/* 391 */       return hexStr.toString();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void writeFieldsToMemory() {
/* 398 */       for (String name : getFieldOrder()) {
/* 399 */         writeField(name);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class CLSID
/*     */     extends GUID
/*     */   {
/*     */     public static class ByReference
/*     */       extends Guid.GUID
/*     */     {
/*     */       public ByReference() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public ByReference(Guid.GUID guid) {
/* 432 */         super(guid);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public ByReference(Pointer memory) {
/* 442 */         super(memory);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public CLSID() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public CLSID(String guid) {
/* 459 */       super(guid);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public CLSID(Guid.GUID guid) {
/* 468 */       super(guid);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class REFIID
/*     */     extends PointerType
/*     */   {
/*     */     public REFIID() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public REFIID(Pointer memory) {
/* 514 */       super(memory);
/*     */     }
/*     */     
/*     */     public REFIID(Guid.IID guid) {
/* 518 */       super(guid.getPointer());
/*     */     }
/*     */     
/*     */     public void setValue(Guid.IID value) {
/* 522 */       setPointer(value.getPointer());
/*     */     }
/*     */     
/*     */     public Guid.IID getValue() {
/* 526 */       return new Guid.IID(getPointer());
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 531 */       if (o == null) {
/* 532 */         return false;
/*     */       }
/* 534 */       if (this == o) {
/* 535 */         return true;
/*     */       }
/* 537 */       if (getClass() != o.getClass()) {
/* 538 */         return false;
/*     */       }
/*     */       
/* 541 */       REFIID other = (REFIID)o;
/* 542 */       return getValue().equals(other.getValue());
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 547 */       return getValue().hashCode();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class IID
/*     */     extends GUID
/*     */   {
/*     */     public IID() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public IID(Pointer memory) {
/* 572 */       super(memory);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public IID(String iid) {
/* 581 */       super(iid);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public IID(byte[] data) {
/* 591 */       super(data);
/*     */     }
/*     */     
/*     */     public IID(Guid.GUID guid) {
/* 595 */       this(guid.toGuidString());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\com\sun\jna\platform\win32\Guid.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */