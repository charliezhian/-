/*     */ package com.sun.jna.platform.win32;
/*     */ 
/*     */ import com.sun.jna.Memory;
/*     */ import com.sun.jna.Native;
/*     */ import com.sun.jna.Pointer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PdhUtil
/*     */ {
/*  41 */   private static final int CHAR_TO_BYTES = Boolean.getBoolean("w32.ascii") ? 1 : Native.WCHAR_SIZE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String ENGLISH_COUNTER_KEY = "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Perflib\\009";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String ENGLISH_COUNTER_VALUE = "Counter";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String PdhLookupPerfNameByIndex(String szMachineName, int dwNameIndex) {
/*  64 */     WinDef.DWORDByReference pcchNameBufferSize = new WinDef.DWORDByReference(new WinDef.DWORD(0L));
/*  65 */     int result = Pdh.INSTANCE.PdhLookupPerfNameByIndex(szMachineName, dwNameIndex, null, pcchNameBufferSize);
/*  66 */     if (result != 0 && result != -2147481646) {
/*  67 */       throw new PdhException(result);
/*     */     }
/*     */ 
/*     */     
/*  71 */     if (pcchNameBufferSize.getValue().intValue() < 1) {
/*  72 */       return "";
/*     */     }
/*     */     
/*  75 */     Memory mem = new Memory((pcchNameBufferSize.getValue().intValue() * CHAR_TO_BYTES));
/*  76 */     result = Pdh.INSTANCE.PdhLookupPerfNameByIndex(szMachineName, dwNameIndex, (Pointer)mem, pcchNameBufferSize);
/*     */     
/*  78 */     if (result != 0) {
/*  79 */       throw new PdhException(result);
/*     */     }
/*     */ 
/*     */     
/*  83 */     if (CHAR_TO_BYTES == 1) {
/*  84 */       return mem.getString(0L);
/*     */     }
/*  86 */     return mem.getWideString(0L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int PdhLookupPerfIndexByEnglishName(String szNameBuffer) {
/* 102 */     String[] counters = Advapi32Util.registryGetStringArray(WinReg.HKEY_LOCAL_MACHINE, "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Perflib\\009", "Counter");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 108 */     for (int i = 1; i < counters.length; i += 2) {
/* 109 */       if (counters[i].equals(szNameBuffer)) {
/*     */         try {
/* 111 */           return Integer.parseInt(counters[i - 1]);
/* 112 */         } catch (NumberFormatException e) {
/*     */           
/* 114 */           return 0;
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 119 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PdhEnumObjectItems PdhEnumObjectItems(String szDataSource, String szMachineName, String szObjectName, int dwDetailLevel) {
/* 149 */     List<String> counters = new ArrayList<String>();
/* 150 */     List<String> instances = new ArrayList<String>();
/*     */ 
/*     */     
/* 153 */     WinDef.DWORDByReference pcchCounterListLength = new WinDef.DWORDByReference(new WinDef.DWORD(0L));
/* 154 */     WinDef.DWORDByReference pcchInstanceListLength = new WinDef.DWORDByReference(new WinDef.DWORD(0L));
/* 155 */     int result = Pdh.INSTANCE.PdhEnumObjectItems(szDataSource, szMachineName, szObjectName, null, pcchCounterListLength, null, pcchInstanceListLength, dwDetailLevel, 0);
/*     */     
/* 157 */     if (result != 0 && result != -2147481646) {
/* 158 */       throw new PdhException(result);
/*     */     }
/*     */     
/* 161 */     Memory mszCounterList = null;
/* 162 */     Memory mszInstanceList = null;
/*     */     
/* 164 */     if (pcchCounterListLength.getValue().intValue() > 0) {
/* 165 */       mszCounterList = new Memory((pcchCounterListLength.getValue().intValue() * CHAR_TO_BYTES));
/*     */     }
/*     */     
/* 168 */     if (pcchInstanceListLength.getValue().intValue() > 0) {
/* 169 */       mszInstanceList = new Memory((pcchInstanceListLength.getValue().intValue() * CHAR_TO_BYTES));
/*     */     }
/*     */     
/* 172 */     result = Pdh.INSTANCE.PdhEnumObjectItems(szDataSource, szMachineName, szObjectName, (Pointer)mszCounterList, pcchCounterListLength, (Pointer)mszInstanceList, pcchInstanceListLength, dwDetailLevel, 0);
/*     */ 
/*     */     
/* 175 */     if (result != 0) {
/* 176 */       throw new PdhException(result);
/*     */     }
/*     */ 
/*     */     
/* 180 */     if (mszCounterList != null) {
/* 181 */       int offset = 0;
/* 182 */       while (offset < mszCounterList.size()) {
/* 183 */         String s = null;
/* 184 */         if (CHAR_TO_BYTES == 1) {
/* 185 */           s = mszCounterList.getString(offset);
/*     */         } else {
/* 187 */           s = mszCounterList.getWideString(offset);
/*     */         } 
/*     */         
/* 190 */         if (s.isEmpty()) {
/*     */           break;
/*     */         }
/* 193 */         counters.add(s);
/*     */         
/* 195 */         offset += (s.length() + 1) * CHAR_TO_BYTES;
/*     */       } 
/*     */     } 
/*     */     
/* 199 */     if (mszInstanceList != null) {
/* 200 */       int offset = 0;
/* 201 */       while (offset < mszInstanceList.size()) {
/* 202 */         String s = null;
/* 203 */         if (CHAR_TO_BYTES == 1) {
/* 204 */           s = mszInstanceList.getString(offset);
/*     */         } else {
/* 206 */           s = mszInstanceList.getWideString(offset);
/*     */         } 
/*     */         
/* 209 */         if (s.isEmpty()) {
/*     */           break;
/*     */         }
/* 212 */         instances.add(s);
/*     */         
/* 214 */         offset += (s.length() + 1) * CHAR_TO_BYTES;
/*     */       } 
/*     */     } 
/*     */     
/* 218 */     return new PdhEnumObjectItems(counters, instances);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class PdhEnumObjectItems
/*     */   {
/*     */     private final List<String> counters;
/*     */ 
/*     */     
/*     */     private final List<String> instances;
/*     */ 
/*     */     
/*     */     public PdhEnumObjectItems(List<String> counters, List<String> instances) {
/* 232 */       this.counters = copyAndEmptyListForNullList(counters);
/* 233 */       this.instances = copyAndEmptyListForNullList(instances);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public List<String> getCounters() {
/* 241 */       return this.counters;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public List<String> getInstances() {
/* 249 */       return this.instances;
/*     */     }
/*     */     
/*     */     private List<String> copyAndEmptyListForNullList(List<String> inputList) {
/* 253 */       if (inputList == null) {
/* 254 */         return new ArrayList<String>();
/*     */       }
/* 256 */       return new ArrayList<String>(inputList);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 262 */       return "PdhEnumObjectItems{counters=" + this.counters + ", instances=" + this.instances + '}';
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class PdhException extends RuntimeException {
/*     */     private final int errorCode;
/*     */     
/*     */     public PdhException(int errorCode) {
/* 270 */       super(String.format("Pdh call failed with error code 0x%08X", new Object[] { Integer.valueOf(errorCode) }));
/* 271 */       this.errorCode = errorCode;
/*     */     }
/*     */     
/*     */     public int getErrorCode() {
/* 275 */       return this.errorCode;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\com\sun\jna\platform\win32\PdhUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */