/*      */ package com.sun.jna.platform.win32;
/*      */ 
/*      */ import com.sun.jna.LastErrorException;
/*      */ import com.sun.jna.Memory;
/*      */ import com.sun.jna.Native;
/*      */ import com.sun.jna.Pointer;
/*      */ import com.sun.jna.Structure;
/*      */ import com.sun.jna.ptr.IntByReference;
/*      */ import com.sun.jna.ptr.PointerByReference;
/*      */ import com.sun.jna.win32.W32APITypeMapper;
/*      */ import java.io.File;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.nio.ByteOrder;
/*      */ import java.util.ArrayList;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.TreeMap;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class Kernel32Util
/*      */   implements WinDef
/*      */ {
/*      */   public static final String VOLUME_GUID_PATH_PREFIX = "\\\\?\\Volume{";
/*      */   public static final String VOLUME_GUID_PATH_SUFFIX = "}\\";
/*      */   
/*      */   public static String getComputerName() {
/*   61 */     char[] buffer = new char[WinBase.MAX_COMPUTERNAME_LENGTH + 1];
/*   62 */     IntByReference lpnSize = new IntByReference(buffer.length);
/*   63 */     if (!Kernel32.INSTANCE.GetComputerName(buffer, lpnSize)) {
/*   64 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */     }
/*   66 */     return Native.toString(buffer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void freeLocalMemory(Pointer ptr) {
/*   76 */     Pointer res = Kernel32.INSTANCE.LocalFree(ptr);
/*   77 */     if (res != null) {
/*   78 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void freeGlobalMemory(Pointer ptr) {
/*   89 */     Pointer res = Kernel32.INSTANCE.GlobalFree(ptr);
/*   90 */     if (res != null) {
/*   91 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void closeHandleRefs(WinNT.HANDLEByReference... refs) {
/*  106 */     Win32Exception err = null;
/*  107 */     for (WinNT.HANDLEByReference r : refs) {
/*      */       try {
/*  109 */         closeHandleRef(r);
/*  110 */       } catch (Win32Exception e) {
/*  111 */         if (err == null) {
/*  112 */           err = e;
/*      */         } else {
/*  114 */           err.addSuppressedReflected((Throwable)e);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  119 */     if (err != null) {
/*  120 */       throw err;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void closeHandleRef(WinNT.HANDLEByReference ref) {
/*  130 */     closeHandle((ref == null) ? null : ref.getValue());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void closeHandles(WinNT.HANDLE... handles) {
/*  144 */     Win32Exception err = null;
/*  145 */     for (WinNT.HANDLE h : handles) {
/*      */       try {
/*  147 */         closeHandle(h);
/*  148 */       } catch (Win32Exception e) {
/*  149 */         if (err == null) {
/*  150 */           err = e;
/*      */         } else {
/*  152 */           err.addSuppressedReflected((Throwable)e);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  157 */     if (err != null) {
/*  158 */       throw err;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void closeHandle(WinNT.HANDLE h) {
/*  170 */     if (h == null) {
/*      */       return;
/*      */     }
/*      */     
/*  174 */     if (!Kernel32.INSTANCE.CloseHandle(h)) {
/*  175 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String formatMessage(int code) {
/*  187 */     PointerByReference buffer = new PointerByReference();
/*  188 */     int nLen = Kernel32.INSTANCE.FormatMessage(4864, null, code, 0, buffer, 0, null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  196 */     if (nLen == 0) {
/*  197 */       throw new LastErrorException(Native.getLastError());
/*      */     }
/*      */     
/*  200 */     Pointer ptr = buffer.getValue();
/*      */     try {
/*  202 */       String s = ptr.getWideString(0L);
/*  203 */       return s.trim();
/*      */     } finally {
/*  205 */       freeLocalMemory(ptr);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String formatMessage(WinNT.HRESULT code) {
/*  217 */     return formatMessage(code.intValue());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String formatMessageFromLastErrorCode(int code) {
/*  228 */     return formatMessage(W32Errors.HRESULT_FROM_WIN32(code));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getLastErrorMessage() {
/*  236 */     return formatMessageFromLastErrorCode(Kernel32.INSTANCE
/*  237 */         .GetLastError());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getTempPath() {
/*  246 */     WinDef.DWORD nBufferLength = new WinDef.DWORD(260L);
/*  247 */     char[] buffer = new char[nBufferLength.intValue()];
/*  248 */     if (Kernel32.INSTANCE.GetTempPath(nBufferLength, buffer).intValue() == 0) {
/*  249 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */     }
/*  251 */     return Native.toString(buffer);
/*      */   }
/*      */   
/*      */   public static void deleteFile(String filename) {
/*  255 */     if (!Kernel32.INSTANCE.DeleteFile(filename)) {
/*  256 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<String> getLogicalDriveStrings() {
/*  266 */     WinDef.DWORD dwSize = Kernel32.INSTANCE.GetLogicalDriveStrings(new WinDef.DWORD(0L), null);
/*  267 */     if (dwSize.intValue() <= 0) {
/*  268 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */     }
/*      */     
/*  271 */     char[] buf = new char[dwSize.intValue()];
/*  272 */     dwSize = Kernel32.INSTANCE.GetLogicalDriveStrings(dwSize, buf);
/*  273 */     int bufSize = dwSize.intValue();
/*  274 */     if (bufSize <= 0) {
/*  275 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */     }
/*      */     
/*  278 */     return Native.toStringList(buf, 0, bufSize);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getFileAttributes(String fileName) {
/*  289 */     int fileAttributes = Kernel32.INSTANCE.GetFileAttributes(fileName);
/*  290 */     if (fileAttributes == -1) {
/*  291 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */     }
/*  293 */     return fileAttributes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getFileType(String fileName) throws FileNotFoundException {
/*  303 */     File f = new File(fileName);
/*  304 */     if (!f.exists()) {
/*  305 */       throw new FileNotFoundException(fileName);
/*      */     }
/*      */     
/*  308 */     WinNT.HANDLE hFile = null;
/*  309 */     Win32Exception err = null; try {
/*      */       int rc;
/*  311 */       hFile = Kernel32.INSTANCE.CreateFile(fileName, -2147483648, 1, new WinBase.SECURITY_ATTRIBUTES(), 3, 128, (new WinNT.HANDLEByReference())
/*      */ 
/*      */           
/*  314 */           .getValue());
/*      */       
/*  316 */       if (WinBase.INVALID_HANDLE_VALUE.equals(hFile)) {
/*  317 */         throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */       }
/*      */       
/*  320 */       int type = Kernel32.INSTANCE.GetFileType(hFile);
/*  321 */       switch (type) {
/*      */         case 0:
/*  323 */           rc = Kernel32.INSTANCE.GetLastError();
/*  324 */           switch (rc) {
/*      */             case 0:
/*      */               break;
/*      */           } 
/*  328 */           throw new Win32Exception(rc);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  333 */       return type;
/*      */     }
/*  335 */     catch (Win32Exception e) {
/*  336 */       err = e;
/*  337 */       throw err;
/*      */     } finally {
/*      */       try {
/*  340 */         closeHandle(hFile);
/*  341 */       } catch (Win32Exception e) {
/*  342 */         if (err == null) {
/*  343 */           err = e;
/*      */         } else {
/*  345 */           err.addSuppressedReflected((Throwable)e);
/*      */         } 
/*      */       } 
/*      */       
/*  349 */       if (err != null) {
/*  350 */         throw err;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getDriveType(String rootName) {
/*  360 */     return Kernel32.INSTANCE.GetDriveType(rootName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getEnvironmentVariable(String name) {
/*  372 */     int size = Kernel32.INSTANCE.GetEnvironmentVariable(name, null, 0);
/*  373 */     if (size == 0)
/*  374 */       return null; 
/*  375 */     if (size < 0) {
/*  376 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */     }
/*      */     
/*  379 */     char[] buffer = new char[size];
/*  380 */     size = Kernel32.INSTANCE.GetEnvironmentVariable(name, buffer, buffer.length);
/*      */     
/*  382 */     if (size <= 0) {
/*  383 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */     }
/*  385 */     return Native.toString(buffer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Map<String, String> getEnvironmentVariables() {
/*  397 */     Pointer lpszEnvironmentBlock = Kernel32.INSTANCE.GetEnvironmentStrings();
/*  398 */     if (lpszEnvironmentBlock == null) {
/*  399 */       throw new LastErrorException(Kernel32.INSTANCE.GetLastError());
/*      */     }
/*      */     
/*      */     try {
/*  403 */       return getEnvironmentVariables(lpszEnvironmentBlock, 0L);
/*      */     } finally {
/*  405 */       if (!Kernel32.INSTANCE.FreeEnvironmentStrings(lpszEnvironmentBlock)) {
/*  406 */         throw new LastErrorException(Kernel32.INSTANCE.GetLastError());
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Map<String, String> getEnvironmentVariables(Pointer lpszEnvironmentBlock, long offset) {
/*  423 */     if (lpszEnvironmentBlock == null) {
/*  424 */       return null;
/*      */     }
/*      */     
/*  427 */     Map<String, String> vars = new TreeMap<String, String>();
/*  428 */     boolean asWideChars = isWideCharEnvironmentStringBlock(lpszEnvironmentBlock, offset);
/*  429 */     long stepFactor = asWideChars ? 2L : 1L;
/*  430 */     long curOffset = offset; while (true) {
/*  431 */       String nvp = readEnvironmentStringBlockEntry(lpszEnvironmentBlock, curOffset, asWideChars);
/*  432 */       int len = nvp.length();
/*  433 */       if (len == 0) {
/*      */         break;
/*      */       }
/*      */       
/*  437 */       int pos = nvp.indexOf('=');
/*  438 */       if (pos < 0) {
/*  439 */         throw new IllegalArgumentException("Missing variable value separator in " + nvp);
/*      */       }
/*      */       
/*  442 */       String name = nvp.substring(0, pos), value = nvp.substring(pos + 1);
/*  443 */       vars.put(name, value);
/*      */       
/*  445 */       curOffset += (len + 1) * stepFactor;
/*      */     } 
/*      */     
/*  448 */     return vars;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String readEnvironmentStringBlockEntry(Pointer lpszEnvironmentBlock, long offset, boolean asWideChars) {
/*  464 */     long endOffset = findEnvironmentStringBlockEntryEnd(lpszEnvironmentBlock, offset, asWideChars);
/*  465 */     int dataLen = (int)(endOffset - offset);
/*  466 */     if (dataLen == 0) {
/*  467 */       return "";
/*      */     }
/*      */     
/*  470 */     int charsLen = asWideChars ? (dataLen / 2) : dataLen;
/*  471 */     char[] chars = new char[charsLen];
/*  472 */     long curOffset = offset, stepSize = asWideChars ? 2L : 1L;
/*  473 */     ByteOrder byteOrder = ByteOrder.nativeOrder();
/*  474 */     for (int index = 0; index < chars.length; index++, curOffset += stepSize) {
/*  475 */       byte b = lpszEnvironmentBlock.getByte(curOffset);
/*  476 */       if (asWideChars) {
/*  477 */         byte x = lpszEnvironmentBlock.getByte(curOffset + 1L);
/*  478 */         if (ByteOrder.LITTLE_ENDIAN.equals(byteOrder)) {
/*  479 */           chars[index] = (char)(x << 8 & 0xFF00 | b & 0xFF);
/*      */         } else {
/*  481 */           chars[index] = (char)(b << 8 & 0xFF00 | x & 0xFF);
/*      */         } 
/*      */       } else {
/*  484 */         chars[index] = (char)(b & 0xFF);
/*      */       } 
/*      */     } 
/*      */     
/*  488 */     return new String(chars);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long findEnvironmentStringBlockEntryEnd(Pointer lpszEnvironmentBlock, long offset, boolean asWideChars) {
/*      */     long curOffset;
/*      */     long stepSize;
/*  504 */     for (curOffset = offset, stepSize = asWideChars ? 2L : 1L;; curOffset += stepSize) {
/*  505 */       byte b = lpszEnvironmentBlock.getByte(curOffset);
/*  506 */       if (b == 0) {
/*  507 */         return curOffset;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isWideCharEnvironmentStringBlock(Pointer lpszEnvironmentBlock, long offset) {
/*  540 */     byte b0 = lpszEnvironmentBlock.getByte(offset);
/*  541 */     byte b1 = lpszEnvironmentBlock.getByte(offset + 1L);
/*  542 */     ByteOrder byteOrder = ByteOrder.nativeOrder();
/*  543 */     if (ByteOrder.LITTLE_ENDIAN.equals(byteOrder)) {
/*  544 */       return isWideCharEnvironmentStringBlock(b1);
/*      */     }
/*  546 */     return isWideCharEnvironmentStringBlock(b0);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean isWideCharEnvironmentStringBlock(byte charsetIndicator) {
/*  552 */     if (charsetIndicator != 0) {
/*  553 */       return false;
/*      */     }
/*  555 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int getPrivateProfileInt(String appName, String keyName, int defaultValue, String fileName) {
/*  581 */     return Kernel32.INSTANCE.GetPrivateProfileInt(appName, keyName, defaultValue, fileName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String getPrivateProfileString(String lpAppName, String lpKeyName, String lpDefault, String lpFileName) {
/*  636 */     char[] buffer = new char[1024];
/*  637 */     Kernel32.INSTANCE.GetPrivateProfileString(lpAppName, lpKeyName, lpDefault, buffer, new WinDef.DWORD(buffer.length), lpFileName);
/*      */     
/*  639 */     return Native.toString(buffer);
/*      */   }
/*      */ 
/*      */   
/*      */   public static final void writePrivateProfileString(String appName, String keyName, String string, String fileName) {
/*  644 */     if (!Kernel32.INSTANCE.WritePrivateProfileString(appName, keyName, string, fileName))
/*      */     {
/*  646 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final WinNT.SYSTEM_LOGICAL_PROCESSOR_INFORMATION[] getLogicalProcessorInformation() {
/*      */     Memory memory;
/*  657 */     int sizePerStruct = (new WinNT.SYSTEM_LOGICAL_PROCESSOR_INFORMATION()).size();
/*  658 */     WinDef.DWORDByReference bufferSize = new WinDef.DWORDByReference(new WinDef.DWORD(sizePerStruct));
/*      */ 
/*      */     
/*      */     while (true) {
/*  662 */       memory = new Memory(bufferSize.getValue().intValue());
/*  663 */       if (!Kernel32.INSTANCE.GetLogicalProcessorInformation((Pointer)memory, bufferSize)) {
/*      */         
/*  665 */         int err = Kernel32.INSTANCE.GetLastError();
/*  666 */         if (err != 122)
/*  667 */           throw new Win32Exception(err); 
/*      */         continue;
/*      */       } 
/*      */       break;
/*      */     } 
/*  672 */     WinNT.SYSTEM_LOGICAL_PROCESSOR_INFORMATION firstInformation = new WinNT.SYSTEM_LOGICAL_PROCESSOR_INFORMATION((Pointer)memory);
/*      */     
/*  674 */     int returnedStructCount = bufferSize.getValue().intValue() / sizePerStruct;
/*      */     
/*  676 */     return (WinNT.SYSTEM_LOGICAL_PROCESSOR_INFORMATION[])firstInformation
/*  677 */       .toArray((Structure[])new WinNT.SYSTEM_LOGICAL_PROCESSOR_INFORMATION[returnedStructCount]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String[] getPrivateProfileSection(String appName, String fileName) {
/*  698 */     char[] buffer = new char[32768];
/*  699 */     if (Kernel32.INSTANCE.GetPrivateProfileSection(appName, buffer, new WinDef.DWORD(buffer.length), fileName).intValue() == 0) {
/*  700 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */     }
/*  702 */     return (new String(buffer)).split("\000");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String[] getPrivateProfileSectionNames(String fileName) {
/*  717 */     char[] buffer = new char[65536];
/*  718 */     if (Kernel32.INSTANCE.GetPrivateProfileSectionNames(buffer, new WinDef.DWORD(buffer.length), fileName).intValue() == 0) {
/*  719 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */     }
/*  721 */     return (new String(buffer)).split("\000");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void writePrivateProfileSection(String appName, String[] strings, String fileName) {
/*  734 */     StringBuilder buffer = new StringBuilder();
/*  735 */     for (String string : strings)
/*  736 */       buffer.append(string).append(false); 
/*  737 */     buffer.append(false);
/*  738 */     if (!Kernel32.INSTANCE.WritePrivateProfileSection(appName, buffer.toString(), fileName)) {
/*  739 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final List<String> queryDosDevice(String lpszDeviceName, int maxTargetSize) {
/*  751 */     char[] lpTargetPath = new char[maxTargetSize];
/*  752 */     int dwSize = Kernel32.INSTANCE.QueryDosDevice(lpszDeviceName, lpTargetPath, lpTargetPath.length);
/*  753 */     if (dwSize == 0) {
/*  754 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */     }
/*      */     
/*  757 */     return Native.toStringList(lpTargetPath, 0, dwSize);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final List<String> getVolumePathNamesForVolumeName(String lpszVolumeName) {
/*  767 */     char[] lpszVolumePathNames = new char[261];
/*  768 */     IntByReference lpcchReturnLength = new IntByReference();
/*      */     
/*  770 */     if (!Kernel32.INSTANCE.GetVolumePathNamesForVolumeName(lpszVolumeName, lpszVolumePathNames, lpszVolumePathNames.length, lpcchReturnLength)) {
/*  771 */       int hr = Kernel32.INSTANCE.GetLastError();
/*  772 */       if (hr != 234) {
/*  773 */         throw new Win32Exception(hr);
/*      */       }
/*      */       
/*  776 */       int required = lpcchReturnLength.getValue();
/*  777 */       lpszVolumePathNames = new char[required];
/*      */       
/*  779 */       if (!Kernel32.INSTANCE.GetVolumePathNamesForVolumeName(lpszVolumeName, lpszVolumePathNames, lpszVolumePathNames.length, lpcchReturnLength)) {
/*  780 */         throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */       }
/*      */     } 
/*      */     
/*  784 */     int bufSize = lpcchReturnLength.getValue();
/*  785 */     return Native.toStringList(lpszVolumePathNames, 0, bufSize);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String extractVolumeGUID(String volumeGUIDPath) {
/*  805 */     if (volumeGUIDPath == null || volumeGUIDPath
/*  806 */       .length() <= "\\\\?\\Volume{".length() + "}\\".length() || 
/*  807 */       !volumeGUIDPath.startsWith("\\\\?\\Volume{") || 
/*  808 */       !volumeGUIDPath.endsWith("}\\")) {
/*  809 */       throw new IllegalArgumentException("Bad volume GUID path format: " + volumeGUIDPath);
/*      */     }
/*      */     
/*  812 */     return volumeGUIDPath.substring("\\\\?\\Volume{".length(), volumeGUIDPath.length() - "}\\".length());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String QueryFullProcessImageName(WinNT.HANDLE hProcess, int dwFlags) {
/*  829 */     char[] path = new char[260];
/*  830 */     IntByReference lpdwSize = new IntByReference(path.length);
/*  831 */     if (Kernel32.INSTANCE.QueryFullProcessImageName(hProcess, 0, path, lpdwSize))
/*  832 */       return (new String(path)).substring(0, lpdwSize.getValue()); 
/*  833 */     throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] getResource(String path, String type, String name) {
/*  850 */     WinDef.HMODULE target = Kernel32.INSTANCE.LoadLibraryEx(path, null, 2);
/*      */     
/*  852 */     if (target == null) {
/*  853 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */     }
/*      */     
/*  856 */     Win32Exception err = null;
/*  857 */     Pointer start = null;
/*  858 */     int length = 0;
/*  859 */     byte[] results = null; try {
/*      */       Memory memory1, memory2;
/*  861 */       Pointer t = null;
/*      */       try {
/*  863 */         t = new Pointer(Long.parseLong(type));
/*  864 */       } catch (NumberFormatException e) {
/*  865 */         memory1 = new Memory((Native.WCHAR_SIZE * (type.length() + 1)));
/*  866 */         memory1.setWideString(0L, type);
/*      */       } 
/*      */       
/*  869 */       Pointer n = null;
/*      */       try {
/*  871 */         n = new Pointer(Long.parseLong(name));
/*  872 */       } catch (NumberFormatException e) {
/*  873 */         memory2 = new Memory((Native.WCHAR_SIZE * (name.length() + 1)));
/*  874 */         memory2.setWideString(0L, name);
/*      */       } 
/*      */       
/*  877 */       WinDef.HRSRC hrsrc = Kernel32.INSTANCE.FindResource(target, (Pointer)memory2, (Pointer)memory1);
/*  878 */       if (hrsrc == null) {
/*  879 */         throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */       }
/*      */ 
/*      */       
/*  883 */       WinNT.HANDLE loaded = Kernel32.INSTANCE.LoadResource(target, hrsrc);
/*  884 */       if (loaded == null) {
/*  885 */         throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */       }
/*      */       
/*  888 */       length = Kernel32.INSTANCE.SizeofResource(target, hrsrc);
/*  889 */       if (length == 0) {
/*  890 */         throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  895 */       start = Kernel32.INSTANCE.LockResource(loaded);
/*  896 */       if (start == null) {
/*  897 */         throw new IllegalStateException("LockResource returned null.");
/*      */       }
/*      */       
/*  900 */       results = start.getByteArray(0L, length);
/*  901 */     } catch (Win32Exception we) {
/*  902 */       err = we;
/*      */     } finally {
/*      */       
/*  905 */       if (target != null && 
/*  906 */         !Kernel32.INSTANCE.FreeLibrary(target)) {
/*  907 */         Win32Exception we = new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*  908 */         if (err != null) {
/*  909 */           we.addSuppressedReflected((Throwable)err);
/*      */         }
/*  911 */         throw we;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  916 */     if (err != null) {
/*  917 */       throw err;
/*      */     }
/*      */     
/*  920 */     return results;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Map<String, List<String>> getResourceNames(String path) {
/*  933 */     WinDef.HMODULE target = Kernel32.INSTANCE.LoadLibraryEx(path, null, 2);
/*      */     
/*  935 */     if (target == null) {
/*  936 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */     }
/*      */     
/*  939 */     final List<String> types = new ArrayList<String>();
/*  940 */     final Map<String, List<String>> result = new LinkedHashMap<String, List<String>>();
/*      */     
/*  942 */     WinBase.EnumResTypeProc ertp = new WinBase.EnumResTypeProc()
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public boolean invoke(WinDef.HMODULE module, Pointer type, Pointer lParam)
/*      */         {
/*  950 */           if (Pointer.nativeValue(type) <= 65535L) {
/*  951 */             types.add(Pointer.nativeValue(type) + "");
/*      */           } else {
/*  953 */             types.add(type.getWideString(0L));
/*      */           } 
/*  955 */           return true;
/*      */         }
/*      */       };
/*      */     
/*  959 */     WinBase.EnumResNameProc ernp = new WinBase.EnumResNameProc()
/*      */       {
/*      */         public boolean invoke(WinDef.HMODULE module, Pointer type, Pointer name, Pointer lParam)
/*      */         {
/*  963 */           String typeName = "";
/*      */           
/*  965 */           if (Pointer.nativeValue(type) <= 65535L) {
/*  966 */             typeName = Pointer.nativeValue(type) + "";
/*      */           } else {
/*  968 */             typeName = type.getWideString(0L);
/*      */           } 
/*      */           
/*  971 */           if (Pointer.nativeValue(name) < 65535L) {
/*  972 */             ((List<String>)result.get(typeName)).add(Pointer.nativeValue(name) + "");
/*      */           } else {
/*  974 */             ((List<String>)result.get(typeName)).add(name.getWideString(0L));
/*      */           } 
/*      */           
/*  977 */           return true;
/*      */         }
/*      */       };
/*      */ 
/*      */     
/*  982 */     Win32Exception err = null;
/*      */     try {
/*  984 */       if (!Kernel32.INSTANCE.EnumResourceTypes(target, ertp, null)) {
/*  985 */         throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */       }
/*      */       
/*  988 */       for (String typeName : types) {
/*  989 */         Memory memory; result.put(typeName, new ArrayList<String>());
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  994 */         Pointer pointer = null;
/*      */         try {
/*  996 */           pointer = new Pointer(Long.parseLong(typeName));
/*  997 */         } catch (NumberFormatException e) {
/*  998 */           memory = new Memory((Native.WCHAR_SIZE * (typeName.length() + 1)));
/*  999 */           memory.setWideString(0L, typeName);
/*      */         } 
/*      */         
/* 1002 */         boolean callResult = Kernel32.INSTANCE.EnumResourceNames(target, (Pointer)memory, ernp, null);
/*      */         
/* 1004 */         if (!callResult) {
/* 1005 */           throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */         }
/*      */       } 
/* 1008 */     } catch (Win32Exception e) {
/* 1009 */       err = e;
/*      */     }
/*      */     finally {
/*      */       
/* 1013 */       if (target != null && 
/* 1014 */         !Kernel32.INSTANCE.FreeLibrary(target)) {
/* 1015 */         Win32Exception we = new Win32Exception(Kernel32.INSTANCE.GetLastError());
/* 1016 */         if (err != null) {
/* 1017 */           we.addSuppressedReflected((Throwable)err);
/*      */         }
/* 1019 */         throw we;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1024 */     if (err != null) {
/* 1025 */       throw err;
/*      */     }
/* 1027 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<Tlhelp32.MODULEENTRY32W> getModules(int processID) {
/* 1038 */     WinNT.HANDLE snapshot = Kernel32.INSTANCE.CreateToolhelp32Snapshot(Tlhelp32.TH32CS_SNAPMODULE, new WinDef.DWORD(processID));
/* 1039 */     if (snapshot == null) {
/* 1040 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */     }
/*      */     
/* 1043 */     Win32Exception we = null;
/*      */     try {
/* 1045 */       Tlhelp32.MODULEENTRY32W first = new Tlhelp32.MODULEENTRY32W();
/*      */       
/* 1047 */       if (!Kernel32.INSTANCE.Module32FirstW(snapshot, first)) {
/* 1048 */         throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */       }
/*      */       
/* 1051 */       List<Tlhelp32.MODULEENTRY32W> modules = new ArrayList<Tlhelp32.MODULEENTRY32W>();
/* 1052 */       modules.add(first);
/*      */       
/* 1054 */       Tlhelp32.MODULEENTRY32W next = new Tlhelp32.MODULEENTRY32W();
/* 1055 */       while (Kernel32.INSTANCE.Module32NextW(snapshot, next)) {
/* 1056 */         modules.add(next);
/* 1057 */         next = new Tlhelp32.MODULEENTRY32W();
/*      */       } 
/*      */       
/* 1060 */       int lastError = Kernel32.INSTANCE.GetLastError();
/*      */ 
/*      */ 
/*      */       
/* 1064 */       if (lastError != 0 && lastError != 18) {
/* 1065 */         throw new Win32Exception(lastError);
/*      */       }
/*      */       
/* 1068 */       return modules;
/* 1069 */     } catch (Win32Exception e) {
/* 1070 */       we = e;
/* 1071 */       throw we;
/*      */     } finally {
/*      */       try {
/* 1074 */         closeHandle(snapshot);
/* 1075 */       } catch (Win32Exception e) {
/* 1076 */         if (we == null) {
/* 1077 */           we = e;
/*      */         } else {
/* 1079 */           we.addSuppressedReflected((Throwable)e);
/*      */         } 
/*      */       } 
/*      */       
/* 1083 */       if (we != null) {
/* 1084 */         throw we;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String expandEnvironmentStrings(String input) {
/*      */     Memory resultMemory;
/* 1110 */     if (input == null) {
/* 1111 */       return "";
/*      */     }
/*      */     
/* 1114 */     int resultChars = Kernel32.INSTANCE.ExpandEnvironmentStrings(input, null, 0);
/*      */     
/* 1116 */     if (resultChars == 0) {
/* 1117 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */     }
/*      */ 
/*      */     
/* 1121 */     if (W32APITypeMapper.DEFAULT == W32APITypeMapper.UNICODE) {
/* 1122 */       resultMemory = new Memory((resultChars * Native.WCHAR_SIZE));
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 1127 */       resultMemory = new Memory((resultChars + 1));
/*      */     } 
/* 1129 */     resultChars = Kernel32.INSTANCE.ExpandEnvironmentStrings(input, (Pointer)resultMemory, resultChars);
/*      */     
/* 1131 */     if (resultChars == 0) {
/* 1132 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */     }
/*      */     
/* 1135 */     if (W32APITypeMapper.DEFAULT == W32APITypeMapper.UNICODE) {
/* 1136 */       return resultMemory.getWideString(0L);
/*      */     }
/* 1138 */     return resultMemory.getString(0L);
/*      */   }
/*      */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\com\sun\jna\platform\win32\Kernel32Util.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */