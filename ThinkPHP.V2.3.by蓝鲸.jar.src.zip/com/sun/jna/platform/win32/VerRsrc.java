/*     */ package com.sun.jna.platform.win32;
/*     */ 
/*     */ import com.sun.jna.Pointer;
/*     */ import com.sun.jna.Structure;
/*     */ import com.sun.jna.Structure.FieldOrder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface VerRsrc
/*     */ {
/*     */   @FieldOrder({"dwSignature", "dwStrucVersion", "dwFileVersionMS", "dwFileVersionLS", "dwProductVersionMS", "dwProductVersionLS", "dwFileFlagsMask", "dwFileFlags", "dwFileOS", "dwFileType", "dwFileSubtype", "dwFileDateMS", "dwFileDateLS"})
/*     */   public static class VS_FIXEDFILEINFO
/*     */     extends Structure
/*     */   {
/*     */     public WinDef.DWORD dwSignature;
/*     */     public WinDef.DWORD dwStrucVersion;
/*     */     public WinDef.DWORD dwFileVersionMS;
/*     */     public WinDef.DWORD dwFileVersionLS;
/*     */     public WinDef.DWORD dwProductVersionMS;
/*     */     public WinDef.DWORD dwProductVersionLS;
/*     */     public WinDef.DWORD dwFileFlagsMask;
/*     */     public WinDef.DWORD dwFileFlags;
/*     */     public WinDef.DWORD dwFileOS;
/*     */     public WinDef.DWORD dwFileType;
/*     */     public WinDef.DWORD dwFileSubtype;
/*     */     public WinDef.DWORD dwFileDateMS;
/*     */     public WinDef.DWORD dwFileDateLS;
/*     */     
/*     */     public static class ByReference
/*     */       extends VS_FIXEDFILEINFO
/*     */       implements Structure.ByReference
/*     */     {
/*     */       public ByReference() {}
/*     */       
/*     */       public ByReference(Pointer memory) {
/*  50 */         super(memory);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public VS_FIXEDFILEINFO() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public VS_FIXEDFILEINFO(Pointer memory) {
/* 132 */       super(memory);
/* 133 */       read();
/*     */     }
/*     */     
/*     */     public int getFileVersionMajor() {
/* 137 */       return this.dwFileVersionMS.intValue() >>> 16;
/*     */     }
/*     */     
/*     */     public int getFileVersionMinor() {
/* 141 */       return this.dwFileVersionMS.intValue() & 0xFFFF;
/*     */     }
/*     */     
/*     */     public int getFileVersionRevision() {
/* 145 */       return this.dwFileVersionLS.intValue() >>> 16;
/*     */     }
/*     */     
/*     */     public int getFileVersionBuild() {
/* 149 */       return this.dwFileVersionLS.intValue() & 0xFFFF;
/*     */     }
/*     */     
/*     */     public int getProductVersionMajor() {
/* 153 */       return this.dwProductVersionMS.intValue() >>> 16;
/*     */     }
/*     */     
/*     */     public int getProductVersionMinor() {
/* 157 */       return this.dwProductVersionMS.intValue() & 0xFFFF;
/*     */     }
/*     */     
/*     */     public int getProductVersionRevision() {
/* 161 */       return this.dwProductVersionLS.intValue() >>> 16;
/*     */     }
/*     */     
/*     */     public int getProductVersionBuild() {
/* 165 */       return this.dwProductVersionLS.intValue() & 0xFFFF;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\com\sun\jna\platform\win32\VerRsrc.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */