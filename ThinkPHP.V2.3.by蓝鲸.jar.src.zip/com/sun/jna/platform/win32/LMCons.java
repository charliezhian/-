package com.sun.jna.platform.win32;

public interface LMCons {
  public static final int NETBIOS_NAME_LEN = 16;
  
  public static final int MAX_PREFERRED_LENGTH = -1;
}


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\com\sun\jna\platform\win32\LMCons.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */