/*     */ package com.sun.jna.platform.win32.COM.util;
/*     */ 
/*     */ import com.sun.jna.Pointer;
/*     */ import com.sun.jna.WString;
/*     */ import com.sun.jna.platform.win32.COM.COMException;
/*     */ import com.sun.jna.platform.win32.COM.COMUtils;
/*     */ import com.sun.jna.platform.win32.COM.Dispatch;
/*     */ import com.sun.jna.platform.win32.COM.DispatchListener;
/*     */ import com.sun.jna.platform.win32.COM.IDispatchCallback;
/*     */ import com.sun.jna.platform.win32.COM.Unknown;
/*     */ import com.sun.jna.platform.win32.COM.util.annotation.ComEventCallback;
/*     */ import com.sun.jna.platform.win32.COM.util.annotation.ComInterface;
/*     */ import com.sun.jna.platform.win32.COM.util.annotation.ComMethod;
/*     */ import com.sun.jna.platform.win32.Guid;
/*     */ import com.sun.jna.platform.win32.OaIdl;
/*     */ import com.sun.jna.platform.win32.OleAuto;
/*     */ import com.sun.jna.platform.win32.Variant;
/*     */ import com.sun.jna.platform.win32.WinDef;
/*     */ import com.sun.jna.platform.win32.WinError;
/*     */ import com.sun.jna.platform.win32.WinNT;
/*     */ import com.sun.jna.ptr.IntByReference;
/*     */ import com.sun.jna.ptr.PointerByReference;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CallbackProxy
/*     */   implements IDispatchCallback
/*     */ {
/*     */   private static boolean DEFAULT_BOOLEAN;
/*     */   private static byte DEFAULT_BYTE;
/*     */   private static short DEFAULT_SHORT;
/*     */   private static int DEFAULT_INT;
/*     */   private static long DEFAULT_LONG;
/*     */   private static float DEFAULT_FLOAT;
/*     */   private static double DEFAULT_DOUBLE;
/*     */   ObjectFactory factory;
/*     */   Class<?> comEventCallbackInterface;
/*     */   IComEventCallbackListener comEventCallbackListener;
/*     */   Guid.REFIID listenedToRiid;
/*     */   public DispatchListener dispatchListener;
/*     */   Map<OaIdl.DISPID, Method> dsipIdMap;
/*     */   
/*     */   public CallbackProxy(ObjectFactory factory, Class<?> comEventCallbackInterface, IComEventCallbackListener comEventCallbackListener) {
/*  72 */     this.factory = factory;
/*  73 */     this.comEventCallbackInterface = comEventCallbackInterface;
/*  74 */     this.comEventCallbackListener = comEventCallbackListener;
/*  75 */     this.listenedToRiid = createRIID(comEventCallbackInterface);
/*  76 */     this.dsipIdMap = createDispIdMap(comEventCallbackInterface);
/*  77 */     this.dispatchListener = new DispatchListener(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Guid.REFIID createRIID(Class<?> comEventCallbackInterface) {
/*  88 */     ComInterface comInterfaceAnnotation = comEventCallbackInterface.<ComInterface>getAnnotation(ComInterface.class);
/*  89 */     if (null == comInterfaceAnnotation) {
/*  90 */       throw new COMException("advise: Interface must define a value for either iid via the ComInterface annotation");
/*     */     }
/*     */     
/*  93 */     String iidStr = comInterfaceAnnotation.iid();
/*  94 */     if (null == iidStr || iidStr.isEmpty()) {
/*  95 */       throw new COMException("ComInterface must define a value for iid");
/*     */     }
/*  97 */     return new Guid.REFIID((new Guid.IID(iidStr)).getPointer());
/*     */   }
/*     */   
/*     */   Map<OaIdl.DISPID, Method> createDispIdMap(Class<?> comEventCallbackInterface) {
/* 101 */     Map<OaIdl.DISPID, Method> map = new HashMap<OaIdl.DISPID, Method>();
/*     */     
/* 103 */     for (Method meth : comEventCallbackInterface.getMethods()) {
/* 104 */       ComEventCallback callbackAnnotation = meth.<ComEventCallback>getAnnotation(ComEventCallback.class);
/* 105 */       ComMethod methodAnnotation = meth.<ComMethod>getAnnotation(ComMethod.class);
/* 106 */       if (methodAnnotation != null) {
/* 107 */         int dispId = methodAnnotation.dispId();
/* 108 */         if (-1 == dispId) {
/* 109 */           dispId = fetchDispIdFromName(callbackAnnotation);
/*     */         }
/* 111 */         if (dispId == -1) {
/* 112 */           this.comEventCallbackListener.errorReceivingCallbackEvent("DISPID for " + meth
/* 113 */               .getName() + " not found", null);
/*     */         }
/*     */         
/* 116 */         map.put(new OaIdl.DISPID(dispId), meth);
/* 117 */       } else if (null != callbackAnnotation) {
/* 118 */         int dispId = callbackAnnotation.dispid();
/* 119 */         if (-1 == dispId) {
/* 120 */           dispId = fetchDispIdFromName(callbackAnnotation);
/*     */         }
/* 122 */         if (dispId == -1) {
/* 123 */           this.comEventCallbackListener.errorReceivingCallbackEvent("DISPID for " + meth
/* 124 */               .getName() + " not found", null);
/*     */         }
/*     */         
/* 127 */         map.put(new OaIdl.DISPID(dispId), meth);
/*     */       } 
/*     */     } 
/*     */     
/* 131 */     return map;
/*     */   }
/*     */ 
/*     */   
/*     */   int fetchDispIdFromName(ComEventCallback annotation) {
/* 136 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void invokeOnThread(OaIdl.DISPID dispIdMember, Guid.REFIID riid, WinDef.LCID lcid, WinDef.WORD wFlags, OleAuto.DISPPARAMS.ByReference pDispParams) {
/* 142 */     Variant.VARIANT[] arguments = pDispParams.getArgs();
/*     */     
/* 144 */     Method eventMethod = this.dsipIdMap.get(dispIdMember);
/* 145 */     if (eventMethod == null) {
/* 146 */       this.comEventCallbackListener.errorReceivingCallbackEvent("No method found with dispId = " + dispIdMember, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 187 */     OaIdl.DISPID[] positionMap = pDispParams.getRgdispidNamedArgs();
/*     */     
/* 189 */     Class<?>[] paramTypes = eventMethod.getParameterTypes();
/* 190 */     Object[] params = new Object[paramTypes.length];
/*     */     
/*     */     int i;
/* 193 */     for (i = 0; i < params.length && arguments.length - positionMap.length - i > 0; i++) {
/* 194 */       Class<?> targetClass = paramTypes[i];
/* 195 */       Variant.VARIANT varg = arguments[arguments.length - i - 1];
/* 196 */       params[i] = Convert.toJavaObject(varg, targetClass, this.factory, true, false);
/*     */     } 
/*     */     
/* 199 */     for (i = 0; i < positionMap.length; i++) {
/* 200 */       int targetPosition = positionMap[i].intValue();
/* 201 */       if (targetPosition < params.length) {
/*     */ 
/*     */ 
/*     */         
/* 205 */         Class<?> targetClass = paramTypes[targetPosition];
/* 206 */         Variant.VARIANT varg = arguments[i];
/* 207 */         params[targetPosition] = Convert.toJavaObject(varg, targetClass, this.factory, true, false);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 214 */     for (i = 0; i < params.length; i++) {
/* 215 */       if (params[i] == null && paramTypes[i].isPrimitive()) {
/* 216 */         if (paramTypes[i].equals(boolean.class)) {
/* 217 */           params[i] = Boolean.valueOf(DEFAULT_BOOLEAN);
/* 218 */         } else if (paramTypes[i].equals(byte.class)) {
/* 219 */           params[i] = Byte.valueOf(DEFAULT_BYTE);
/* 220 */         } else if (paramTypes[i].equals(short.class)) {
/* 221 */           params[i] = Short.valueOf(DEFAULT_SHORT);
/* 222 */         } else if (paramTypes[i].equals(int.class)) {
/* 223 */           params[i] = Integer.valueOf(DEFAULT_INT);
/* 224 */         } else if (paramTypes[i].equals(long.class)) {
/* 225 */           params[i] = Long.valueOf(DEFAULT_LONG);
/* 226 */         } else if (paramTypes[i].equals(float.class)) {
/* 227 */           params[i] = Float.valueOf(DEFAULT_FLOAT);
/* 228 */         } else if (paramTypes[i].equals(double.class)) {
/* 229 */           params[i] = Double.valueOf(DEFAULT_DOUBLE);
/*     */         } else {
/* 231 */           throw new IllegalArgumentException("Class type " + paramTypes[i].getName() + " not mapped to primitive default value.");
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/*     */     try {
/* 237 */       eventMethod.invoke(this.comEventCallbackListener, params);
/* 238 */     } catch (Exception e) {
/* 239 */       List<String> decodedClassNames = new ArrayList<String>(params.length);
/* 240 */       for (Object o : params) {
/* 241 */         if (o == null) {
/* 242 */           decodedClassNames.add("NULL");
/*     */         } else {
/* 244 */           decodedClassNames.add(o.getClass().getName());
/*     */         } 
/*     */       } 
/* 247 */       this.comEventCallbackListener.errorReceivingCallbackEvent("Exception invoking method " + eventMethod + " supplied: " + decodedClassNames
/* 248 */           .toString(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Pointer getPointer() {
/* 254 */     return this.dispatchListener.getPointer();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public WinNT.HRESULT GetTypeInfoCount(WinDef.UINTByReference pctinfo) {
/* 260 */     return new WinNT.HRESULT(-2147467263);
/*     */   }
/*     */ 
/*     */   
/*     */   public WinNT.HRESULT GetTypeInfo(WinDef.UINT iTInfo, WinDef.LCID lcid, PointerByReference ppTInfo) {
/* 265 */     return new WinNT.HRESULT(-2147467263);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public WinNT.HRESULT GetIDsOfNames(Guid.REFIID riid, WString[] rgszNames, int cNames, WinDef.LCID lcid, OaIdl.DISPIDByReference rgDispId) {
/* 271 */     return new WinNT.HRESULT(-2147467263);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WinNT.HRESULT Invoke(OaIdl.DISPID dispIdMember, Guid.REFIID riid, WinDef.LCID lcid, WinDef.WORD wFlags, OleAuto.DISPPARAMS.ByReference pDispParams, Variant.VARIANT.ByReference pVarResult, OaIdl.EXCEPINFO.ByReference pExcepInfo, IntByReference puArgErr) {
/* 279 */     assert COMUtils.comIsInitialized() : "Assumption about COM threading broken.";
/*     */     
/* 281 */     invokeOnThread(dispIdMember, riid, lcid, wFlags, pDispParams);
/*     */     
/* 283 */     return WinError.S_OK;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public WinNT.HRESULT QueryInterface(Guid.REFIID refid, PointerByReference ppvObject) {
/* 289 */     if (null == ppvObject)
/* 290 */       return new WinNT.HRESULT(-2147467261); 
/* 291 */     if (refid.equals(this.listenedToRiid)) {
/* 292 */       ppvObject.setValue(getPointer());
/* 293 */       return WinError.S_OK;
/* 294 */     }  if (refid.getValue().equals(Unknown.IID_IUNKNOWN)) {
/* 295 */       ppvObject.setValue(getPointer());
/* 296 */       return WinError.S_OK;
/* 297 */     }  if (refid.getValue().equals(Dispatch.IID_IDISPATCH)) {
/* 298 */       ppvObject.setValue(getPointer());
/* 299 */       return WinError.S_OK;
/*     */     } 
/*     */     
/* 302 */     return new WinNT.HRESULT(-2147467262);
/*     */   }
/*     */   
/*     */   public int AddRef() {
/* 306 */     return 0;
/*     */   }
/*     */   
/*     */   public int Release() {
/* 310 */     return 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\com\sun\jna\platform\win32\CO\\util\CallbackProxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */