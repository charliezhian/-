/*     */ package com.sun.jna.platform.win32.COM.util;
/*     */ 
/*     */ import com.sun.jna.Pointer;
/*     */ import com.sun.jna.WString;
/*     */ import com.sun.jna.platform.win32.COM.COMException;
/*     */ import com.sun.jna.platform.win32.COM.COMUtils;
/*     */ import com.sun.jna.platform.win32.COM.ConnectionPoint;
/*     */ import com.sun.jna.platform.win32.COM.ConnectionPointContainer;
/*     */ import com.sun.jna.platform.win32.COM.Dispatch;
/*     */ import com.sun.jna.platform.win32.COM.IDispatch;
/*     */ import com.sun.jna.platform.win32.COM.IDispatchCallback;
/*     */ import com.sun.jna.platform.win32.COM.IUnknown;
/*     */ import com.sun.jna.platform.win32.COM.IUnknownCallback;
/*     */ import com.sun.jna.platform.win32.COM.util.annotation.ComInterface;
/*     */ import com.sun.jna.platform.win32.COM.util.annotation.ComMethod;
/*     */ import com.sun.jna.platform.win32.COM.util.annotation.ComProperty;
/*     */ import com.sun.jna.platform.win32.Guid;
/*     */ import com.sun.jna.platform.win32.Kernel32Util;
/*     */ import com.sun.jna.platform.win32.OaIdl;
/*     */ import com.sun.jna.platform.win32.OleAuto;
/*     */ import com.sun.jna.platform.win32.Variant;
/*     */ import com.sun.jna.platform.win32.WinDef;
/*     */ import com.sun.jna.platform.win32.WinNT;
/*     */ import com.sun.jna.ptr.IntByReference;
/*     */ import com.sun.jna.ptr.PointerByReference;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProxyObject
/*     */   implements InvocationHandler, IDispatch, IRawDispatchHandle, IConnectionPoint
/*     */ {
/*     */   private long unknownId;
/*     */   private final Class<?> theInterface;
/*     */   private final ObjectFactory factory;
/*     */   private final IDispatch rawDispatch;
/*     */   
/*     */   public ProxyObject(Class<?> theInterface, IDispatch rawDispatch, ObjectFactory factory) {
/*  86 */     this.unknownId = -1L;
/*  87 */     this.rawDispatch = rawDispatch;
/*  88 */     this.theInterface = theInterface;
/*  89 */     this.factory = factory;
/*     */ 
/*     */     
/*  92 */     int n = this.rawDispatch.AddRef();
/*  93 */     getUnknownId();
/*  94 */     factory.register(this);
/*     */   }
/*     */   
/*     */   private long getUnknownId() {
/*  98 */     assert COMUtils.comIsInitialized() : "COM not initialized";
/*     */     
/* 100 */     if (-1L == this.unknownId) {
/*     */       try {
/* 102 */         PointerByReference ppvObject = new PointerByReference();
/*     */         
/* 104 */         Thread current = Thread.currentThread();
/* 105 */         String tn = current.getName();
/*     */         
/* 107 */         Guid.IID iid = IUnknown.IID_IUNKNOWN;
/* 108 */         WinNT.HRESULT hr = getRawDispatch().QueryInterface(new Guid.REFIID(iid), ppvObject);
/*     */         
/* 110 */         if (WinNT.S_OK.equals(hr)) {
/* 111 */           Dispatch dispatch = new Dispatch(ppvObject.getValue());
/* 112 */           this.unknownId = Pointer.nativeValue(dispatch.getPointer());
/*     */ 
/*     */ 
/*     */           
/* 116 */           int i = dispatch.Release();
/*     */         } else {
/* 118 */           String formatMessageFromHR = Kernel32Util.formatMessage(hr);
/* 119 */           throw new COMException("getUnknownId: " + formatMessageFromHR, hr);
/*     */         } 
/* 121 */       } catch (RuntimeException e) {
/*     */         
/* 123 */         if (e instanceof COMException) {
/* 124 */           throw e;
/*     */         }
/* 126 */         throw new COMException("Error occured when trying get Unknown Id ", e);
/*     */       } 
/*     */     }
/*     */     
/* 130 */     return this.unknownId;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void finalize() throws Throwable {
/* 135 */     dispose();
/* 136 */     super.finalize();
/*     */   }
/*     */   
/*     */   public synchronized void dispose() {
/* 140 */     if (((Dispatch)this.rawDispatch).getPointer() != Pointer.NULL) {
/* 141 */       this.rawDispatch.Release();
/* 142 */       ((Dispatch)this.rawDispatch).setPointer(Pointer.NULL);
/* 143 */       this.factory.unregister(this);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public IDispatch getRawDispatch() {
/* 149 */     return this.rawDispatch;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object arg) {
/* 164 */     if (null == arg)
/* 165 */       return false; 
/* 166 */     if (arg instanceof ProxyObject) {
/* 167 */       ProxyObject other = (ProxyObject)arg;
/* 168 */       return (getUnknownId() == other.getUnknownId());
/* 169 */     }  if (Proxy.isProxyClass(arg.getClass())) {
/* 170 */       InvocationHandler handler = Proxy.getInvocationHandler(arg);
/* 171 */       if (handler instanceof ProxyObject) {
/*     */         try {
/* 173 */           ProxyObject other = (ProxyObject)handler;
/* 174 */           return (getUnknownId() == other.getUnknownId());
/* 175 */         } catch (Exception e) {
/*     */ 
/*     */           
/* 178 */           return false;
/*     */         } 
/*     */       }
/* 181 */       return false;
/*     */     } 
/*     */     
/* 184 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 190 */     long id = getUnknownId();
/* 191 */     return (int)(id >>> 32L & 0xFFFFFFFFFFFFFFFFL) + (int)(id & 0xFFFFFFFFFFFFFFFFL);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 196 */     return this.theInterface.getName() + "{unk=" + hashCode() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/* 205 */     boolean declaredAsInterface = (method.getAnnotation(ComMethod.class) != null || method.getAnnotation(ComProperty.class) != null);
/*     */     
/* 207 */     if (!declaredAsInterface && (method.getDeclaringClass().equals(Object.class) || method
/* 208 */       .getDeclaringClass().equals(IRawDispatchHandle.class) || method
/* 209 */       .getDeclaringClass().equals(IUnknown.class) || method
/* 210 */       .getDeclaringClass().equals(IDispatch.class) || method
/* 211 */       .getDeclaringClass().equals(IConnectionPoint.class))) {
/*     */       
/*     */       try {
/* 214 */         return method.invoke(this, args);
/* 215 */       } catch (InvocationTargetException ex) {
/* 216 */         throw ex.getCause();
/*     */       } 
/*     */     }
/*     */     
/* 220 */     Class<?> returnType = method.getReturnType();
/* 221 */     boolean isVoid = void.class.equals(returnType);
/*     */     
/* 223 */     ComProperty prop = method.<ComProperty>getAnnotation(ComProperty.class);
/* 224 */     if (null != prop) {
/* 225 */       int dispId = prop.dispId();
/* 226 */       if (isVoid) {
/* 227 */         if (dispId != -1) {
/* 228 */           setProperty(new OaIdl.DISPID(dispId), args[0]);
/* 229 */           return null;
/*     */         } 
/* 231 */         String str = getMutatorName(method, prop);
/* 232 */         setProperty(str, args[0]);
/* 233 */         return null;
/*     */       } 
/*     */       
/* 236 */       if (dispId != -1) {
/* 237 */         return getProperty(returnType, new OaIdl.DISPID(dispId), args);
/*     */       }
/* 239 */       String propName = getAccessorName(method, prop);
/* 240 */       return getProperty(returnType, propName, args);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 245 */     ComMethod meth = method.<ComMethod>getAnnotation(ComMethod.class);
/* 246 */     if (null != meth) {
/* 247 */       Object[] fullLengthArgs = unfoldWhenVarargs(method, args);
/* 248 */       int dispId = meth.dispId();
/* 249 */       if (dispId != -1) {
/* 250 */         return invokeMethod(returnType, new OaIdl.DISPID(dispId), fullLengthArgs);
/*     */       }
/* 252 */       String methName = getMethodName(method, meth);
/* 253 */       return invokeMethod(returnType, methName, fullLengthArgs);
/*     */     } 
/*     */ 
/*     */     
/* 257 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private ConnectionPoint fetchRawConnectionPoint(Guid.IID iid) {
/* 262 */     assert COMUtils.comIsInitialized() : "COM not initialized";
/*     */ 
/*     */     
/* 265 */     IConnectionPointContainer cpc = queryInterface(IConnectionPointContainer.class);
/* 266 */     Dispatch rawCpcDispatch = (Dispatch)cpc.getRawDispatch();
/* 267 */     ConnectionPointContainer rawCpc = new ConnectionPointContainer(rawCpcDispatch.getPointer());
/*     */ 
/*     */     
/* 270 */     Guid.REFIID adviseRiid = new Guid.REFIID(iid.getPointer());
/* 271 */     PointerByReference ppCp = new PointerByReference();
/* 272 */     WinNT.HRESULT hr = rawCpc.FindConnectionPoint(adviseRiid, ppCp);
/* 273 */     COMUtils.checkRC(hr);
/* 274 */     ConnectionPoint rawCp = new ConnectionPoint(ppCp.getValue());
/* 275 */     return rawCp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IComEventCallbackCookie advise(Class<?> comEventCallbackInterface, IComEventCallbackListener comEventCallbackListener) throws COMException {
/* 282 */     assert COMUtils.comIsInitialized() : "COM not initialized";
/*     */     
/*     */     try {
/* 285 */       ComInterface comInterfaceAnnotation = comEventCallbackInterface.<ComInterface>getAnnotation(ComInterface.class);
/* 286 */       if (null == comInterfaceAnnotation) {
/* 287 */         throw new COMException("advise: Interface must define a value for either iid via the ComInterface annotation");
/*     */       }
/*     */       
/* 290 */       Guid.IID iid = getIID(comInterfaceAnnotation);
/*     */       
/* 292 */       ConnectionPoint rawCp = fetchRawConnectionPoint(iid);
/*     */ 
/*     */       
/* 295 */       IDispatchCallback rawListener = this.factory.createDispatchCallback(comEventCallbackInterface, comEventCallbackListener);
/*     */ 
/*     */       
/* 298 */       comEventCallbackListener.setDispatchCallbackListener(rawListener);
/*     */ 
/*     */       
/* 301 */       WinDef.DWORDByReference pdwCookie = new WinDef.DWORDByReference();
/* 302 */       WinNT.HRESULT hr = rawCp.Advise((IUnknownCallback)rawListener, pdwCookie);
/* 303 */       int n = rawCp.Release();
/*     */       
/* 305 */       COMUtils.checkRC(hr);
/*     */ 
/*     */       
/* 308 */       return new ComEventCallbackCookie(pdwCookie.getValue());
/*     */     }
/* 310 */     catch (RuntimeException e) {
/*     */       
/* 312 */       if (e instanceof COMException) {
/* 313 */         throw e;
/*     */       }
/* 315 */       throw new COMException("Error occured in advise when trying to connect the listener " + comEventCallbackListener, e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void unadvise(Class<?> comEventCallbackInterface, IComEventCallbackCookie cookie) throws COMException {
/* 322 */     assert COMUtils.comIsInitialized() : "COM not initialized";
/*     */     
/*     */     try {
/* 325 */       ComInterface comInterfaceAnnotation = comEventCallbackInterface.<ComInterface>getAnnotation(ComInterface.class);
/* 326 */       if (null == comInterfaceAnnotation) {
/* 327 */         throw new COMException("unadvise: Interface must define a value for iid via the ComInterface annotation");
/*     */       }
/*     */       
/* 330 */       Guid.IID iid = getIID(comInterfaceAnnotation);
/*     */       
/* 332 */       ConnectionPoint rawCp = fetchRawConnectionPoint(iid);
/*     */       
/* 334 */       WinNT.HRESULT hr = rawCp.Unadvise(((ComEventCallbackCookie)cookie).getValue());
/*     */       
/* 336 */       rawCp.Release();
/* 337 */       COMUtils.checkRC(hr);
/*     */     }
/* 339 */     catch (RuntimeException e) {
/*     */       
/* 341 */       if (e instanceof COMException) {
/* 342 */         throw e;
/*     */       }
/* 344 */       throw new COMException("Error occured in unadvise when trying to disconnect the listener from " + this, e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> void setProperty(String name, T value) {
/* 352 */     OaIdl.DISPID dispID = resolveDispId(getRawDispatch(), name);
/* 353 */     setProperty(dispID, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> void setProperty(OaIdl.DISPID dispId, T value) {
/* 358 */     assert COMUtils.comIsInitialized() : "COM not initialized";
/*     */     
/* 360 */     Variant.VARIANT v = Convert.toVariant(value);
/* 361 */     WinNT.HRESULT hr = oleMethod(4, (Variant.VARIANT.ByReference)null, getRawDispatch(), dispId, v);
/* 362 */     Convert.free(v, value);
/* 363 */     COMUtils.checkRC(hr);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T getProperty(Class<T> returnType, String name, Object... args) {
/* 368 */     OaIdl.DISPID dispID = resolveDispId(getRawDispatch(), name);
/* 369 */     return getProperty(returnType, dispID, args);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T getProperty(Class<T> returnType, OaIdl.DISPID dispID, Object... args) {
/*     */     Variant.VARIANT[] vargs;
/* 375 */     if (null == args) {
/* 376 */       vargs = new Variant.VARIANT[0];
/*     */     } else {
/* 378 */       vargs = new Variant.VARIANT[args.length];
/*     */     } 
/* 380 */     for (int i = 0; i < vargs.length; i++) {
/* 381 */       vargs[i] = Convert.toVariant(args[i]);
/*     */     }
/* 383 */     Variant.VARIANT.ByReference result = new Variant.VARIANT.ByReference();
/* 384 */     WinNT.HRESULT hr = oleMethod(2, result, getRawDispatch(), dispID, vargs);
/*     */     
/* 386 */     for (int j = 0; j < vargs.length; j++)
/*     */     {
/* 388 */       Convert.free(vargs[j], args[j]);
/*     */     }
/*     */     
/* 391 */     COMUtils.checkRC(hr);
/*     */     
/* 393 */     return (T)Convert.toJavaObject((Variant.VARIANT)result, returnType, this.factory, false, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T invokeMethod(Class<T> returnType, String name, Object... args) {
/* 398 */     OaIdl.DISPID dispID = resolveDispId(getRawDispatch(), name);
/* 399 */     return invokeMethod(returnType, dispID, args);
/*     */   }
/*     */   
/*     */   public <T> T invokeMethod(Class<T> returnType, OaIdl.DISPID dispID, Object... args) {
/*     */     Variant.VARIANT[] vargs;
/* 404 */     assert COMUtils.comIsInitialized() : "COM not initialized";
/*     */ 
/*     */     
/* 407 */     if (null == args) {
/* 408 */       vargs = new Variant.VARIANT[0];
/*     */     } else {
/* 410 */       vargs = new Variant.VARIANT[args.length];
/*     */     } 
/* 412 */     for (int i = 0; i < vargs.length; i++) {
/* 413 */       vargs[i] = Convert.toVariant(args[i]);
/*     */     }
/* 415 */     Variant.VARIANT.ByReference result = new Variant.VARIANT.ByReference();
/* 416 */     WinNT.HRESULT hr = oleMethod(1, result, getRawDispatch(), dispID, vargs);
/*     */     
/* 418 */     for (int j = 0; j < vargs.length; j++)
/*     */     {
/* 420 */       Convert.free(vargs[j], args[j]);
/*     */     }
/*     */     
/* 423 */     COMUtils.checkRC(hr);
/*     */     
/* 425 */     return (T)Convert.toJavaObject((Variant.VARIANT)result, returnType, this.factory, false, true);
/*     */   }
/*     */   
/*     */   private Object[] unfoldWhenVarargs(Method method, Object[] argParams) {
/* 429 */     if (null == argParams) {
/* 430 */       return null;
/*     */     }
/* 432 */     if (argParams.length == 0 || !method.isVarArgs() || !(argParams[argParams.length - 1] instanceof Object[])) {
/* 433 */       return argParams;
/*     */     }
/*     */     
/* 436 */     Object[] varargs = (Object[])argParams[argParams.length - 1];
/* 437 */     Object[] args = new Object[argParams.length - 1 + varargs.length];
/* 438 */     System.arraycopy(argParams, 0, args, 0, argParams.length - 1);
/* 439 */     System.arraycopy(varargs, 0, args, argParams.length - 1, varargs.length);
/* 440 */     return args;
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T queryInterface(Class<T> comInterface) throws COMException {
/* 445 */     assert COMUtils.comIsInitialized() : "COM not initialized";
/*     */     
/*     */     try {
/* 448 */       ComInterface comInterfaceAnnotation = comInterface.<ComInterface>getAnnotation(ComInterface.class);
/* 449 */       if (null == comInterfaceAnnotation) {
/* 450 */         throw new COMException("queryInterface: Interface must define a value for iid via the ComInterface annotation");
/*     */       }
/*     */       
/* 453 */       Guid.IID iid = getIID(comInterfaceAnnotation);
/* 454 */       PointerByReference ppvObject = new PointerByReference();
/*     */       
/* 456 */       WinNT.HRESULT hr = getRawDispatch().QueryInterface(new Guid.REFIID(iid), ppvObject);
/*     */       
/* 458 */       if (WinNT.S_OK.equals(hr)) {
/* 459 */         Dispatch dispatch = new Dispatch(ppvObject.getValue());
/* 460 */         T t = this.factory.createProxy(comInterface, (IDispatch)dispatch);
/*     */ 
/*     */ 
/*     */         
/* 464 */         int n = dispatch.Release();
/* 465 */         return t;
/*     */       } 
/* 467 */       String formatMessageFromHR = Kernel32Util.formatMessage(hr);
/* 468 */       throw new COMException("queryInterface: " + formatMessageFromHR, hr);
/*     */     }
/* 470 */     catch (RuntimeException e) {
/*     */       
/* 472 */       if (e instanceof COMException) {
/* 473 */         throw e;
/*     */       }
/* 475 */       throw new COMException("Error occured when trying to query for interface " + comInterface.getName(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private Guid.IID getIID(ComInterface annotation) {
/* 481 */     String iidStr = annotation.iid();
/* 482 */     if (null != iidStr && !iidStr.isEmpty()) {
/* 483 */       return new Guid.IID(iidStr);
/*     */     }
/* 485 */     throw new COMException("ComInterface must define a value for iid");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getAccessorName(Method method, ComProperty prop) {
/* 492 */     if (prop.name().isEmpty()) {
/* 493 */       String methName = method.getName();
/* 494 */       if (methName.startsWith("get")) {
/* 495 */         return methName.replaceFirst("get", "");
/*     */       }
/* 497 */       throw new RuntimeException("Property Accessor name must start with 'get', or set the anotation 'name' value");
/*     */     } 
/*     */ 
/*     */     
/* 501 */     return prop.name();
/*     */   }
/*     */ 
/*     */   
/*     */   private String getMutatorName(Method method, ComProperty prop) {
/* 506 */     if (prop.name().isEmpty()) {
/* 507 */       String methName = method.getName();
/* 508 */       if (methName.startsWith("set")) {
/* 509 */         return methName.replaceFirst("set", "");
/*     */       }
/* 511 */       throw new RuntimeException("Property Mutator name must start with 'set', or set the anotation 'name' value");
/*     */     } 
/*     */ 
/*     */     
/* 515 */     return prop.name();
/*     */   }
/*     */ 
/*     */   
/*     */   private String getMethodName(Method method, ComMethod meth) {
/* 520 */     if (meth.name().isEmpty()) {
/* 521 */       String methName = method.getName();
/* 522 */       return methName;
/*     */     } 
/* 524 */     return meth.name();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected OaIdl.DISPID resolveDispId(String name) {
/* 530 */     return resolveDispId(getRawDispatch(), name);
/*     */   }
/*     */ 
/*     */   
/*     */   protected WinNT.HRESULT oleMethod(int nType, Variant.VARIANT.ByReference pvResult, String name, Variant.VARIANT pArg) throws COMException {
/* 535 */     return oleMethod(nType, pvResult, name, new Variant.VARIANT[] { pArg });
/*     */   }
/*     */ 
/*     */   
/*     */   protected WinNT.HRESULT oleMethod(int nType, Variant.VARIANT.ByReference pvResult, OaIdl.DISPID dispId, Variant.VARIANT pArg) throws COMException {
/* 540 */     return oleMethod(nType, pvResult, dispId, new Variant.VARIANT[] { pArg });
/*     */   }
/*     */ 
/*     */   
/*     */   protected WinNT.HRESULT oleMethod(int nType, Variant.VARIANT.ByReference pvResult, String name) throws COMException {
/* 545 */     return oleMethod(nType, pvResult, name, (Variant.VARIANT[])null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected WinNT.HRESULT oleMethod(int nType, Variant.VARIANT.ByReference pvResult, OaIdl.DISPID dispId) throws COMException {
/* 551 */     return oleMethod(nType, pvResult, dispId, (Variant.VARIANT[])null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected WinNT.HRESULT oleMethod(int nType, Variant.VARIANT.ByReference pvResult, String name, Variant.VARIANT[] pArgs) throws COMException {
/* 557 */     return oleMethod(nType, pvResult, resolveDispId(name), pArgs);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected WinNT.HRESULT oleMethod(int nType, Variant.VARIANT.ByReference pvResult, OaIdl.DISPID dispId, Variant.VARIANT[] pArgs) throws COMException {
/* 563 */     return oleMethod(nType, pvResult, getRawDispatch(), dispId, pArgs);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   protected OaIdl.DISPID resolveDispId(IDispatch pDisp, String name) {
/* 568 */     assert COMUtils.comIsInitialized() : "COM not initialized";
/*     */     
/* 570 */     if (pDisp == null) {
/* 571 */       throw new COMException("pDisp (IDispatch) parameter is null!");
/*     */     }
/* 573 */     WString[] ptName = { new WString(name) };
/* 574 */     OaIdl.DISPIDByReference pdispID = new OaIdl.DISPIDByReference();
/*     */     
/* 576 */     WinNT.HRESULT hr = pDisp.GetIDsOfNames(new Guid.REFIID(Guid.IID_NULL), ptName, 1, this.factory
/*     */ 
/*     */ 
/*     */         
/* 580 */         .getLCID(), pdispID);
/*     */ 
/*     */     
/* 583 */     COMUtils.checkRC(hr);
/*     */     
/* 585 */     return pdispID.getValue();
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected WinNT.HRESULT oleMethod(int nType, Variant.VARIANT.ByReference pvResult, IDispatch pDisp, String name, Variant.VARIANT pArg) throws COMException {
/* 591 */     return oleMethod(nType, pvResult, pDisp, name, new Variant.VARIANT[] { pArg });
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected WinNT.HRESULT oleMethod(int nType, Variant.VARIANT.ByReference pvResult, IDispatch pDisp, OaIdl.DISPID dispId, Variant.VARIANT pArg) throws COMException {
/* 597 */     return oleMethod(nType, pvResult, pDisp, dispId, new Variant.VARIANT[] { pArg });
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected WinNT.HRESULT oleMethod(int nType, Variant.VARIANT.ByReference pvResult, IDispatch pDisp, String name) throws COMException {
/* 603 */     return oleMethod(nType, pvResult, pDisp, name, (Variant.VARIANT[])null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected WinNT.HRESULT oleMethod(int nType, Variant.VARIANT.ByReference pvResult, IDispatch pDisp, OaIdl.DISPID dispId) throws COMException {
/* 610 */     return oleMethod(nType, pvResult, pDisp, dispId, (Variant.VARIANT[])null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected WinNT.HRESULT oleMethod(int nType, Variant.VARIANT.ByReference pvResult, IDispatch pDisp, String name, Variant.VARIANT[] pArgs) throws COMException {
/* 617 */     return oleMethod(nType, pvResult, pDisp, resolveDispId(pDisp, name), pArgs);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected WinNT.HRESULT oleMethod(int nType, Variant.VARIANT.ByReference pvResult, IDispatch pDisp, OaIdl.DISPID dispId, Variant.VARIANT[] pArgs) throws COMException {
/*     */     int finalNType;
/* 624 */     assert COMUtils.comIsInitialized() : "COM not initialized";
/*     */     
/* 626 */     if (pDisp == null) {
/* 627 */       throw new COMException("pDisp (IDispatch) parameter is null!");
/*     */     }
/*     */     
/* 630 */     int _argsLen = 0;
/* 631 */     Variant.VARIANT[] _args = null;
/* 632 */     OleAuto.DISPPARAMS.ByReference dp = new OleAuto.DISPPARAMS.ByReference();
/* 633 */     OaIdl.EXCEPINFO.ByReference pExcepInfo = new OaIdl.EXCEPINFO.ByReference();
/* 634 */     IntByReference puArgErr = new IntByReference();
/*     */ 
/*     */     
/* 637 */     if (pArgs != null && pArgs.length > 0) {
/* 638 */       _argsLen = pArgs.length;
/* 639 */       _args = new Variant.VARIANT[_argsLen];
/*     */       
/* 641 */       int revCount = _argsLen;
/* 642 */       for (int i = 0; i < _argsLen; i++) {
/* 643 */         _args[i] = pArgs[--revCount];
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 648 */     if (nType == 4) {
/* 649 */       dp.setRgdispidNamedArgs(new OaIdl.DISPID[] { OaIdl.DISPID_PROPERTYPUT });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 676 */     if (nType == 1 || nType == 2) {
/* 677 */       finalNType = 3;
/*     */     } else {
/* 679 */       finalNType = nType;
/*     */     } 
/*     */ 
/*     */     
/* 683 */     if (_argsLen > 0) {
/* 684 */       dp.setArgs(_args);
/*     */ 
/*     */       
/* 687 */       dp.write();
/*     */     } 
/*     */ 
/*     */     
/* 691 */     WinNT.HRESULT hr = pDisp.Invoke(dispId, new Guid.REFIID(Guid.IID_NULL), this.factory
/*     */ 
/*     */         
/* 694 */         .getLCID(), new WinDef.WORD(finalNType), dp, pvResult, pExcepInfo, puArgErr);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 702 */     COMUtils.checkRC(hr, (OaIdl.EXCEPINFO)pExcepInfo, puArgErr);
/* 703 */     return hr;
/*     */   }
/*     */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\com\sun\jna\platform\win32\CO\\util\ProxyObject.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */