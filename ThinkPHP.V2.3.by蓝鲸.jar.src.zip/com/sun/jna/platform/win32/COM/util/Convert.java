/*     */ package com.sun.jna.platform.win32.COM.util;
/*     */ 
/*     */ import com.sun.jna.platform.win32.COM.Dispatch;
/*     */ import com.sun.jna.platform.win32.COM.IDispatch;
/*     */ import com.sun.jna.platform.win32.COM.IUnknown;
/*     */ import com.sun.jna.platform.win32.OaIdl;
/*     */ import com.sun.jna.platform.win32.OleAuto;
/*     */ import com.sun.jna.platform.win32.Variant;
/*     */ import com.sun.jna.platform.win32.WTypes;
/*     */ import com.sun.jna.platform.win32.WinDef;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Convert
/*     */ {
/*     */   public static Variant.VARIANT toVariant(Object value) {
/*  89 */     if (value instanceof Variant.VARIANT)
/*  90 */       return (Variant.VARIANT)value; 
/*  91 */     if (value instanceof Byte)
/*  92 */       return new Variant.VARIANT(((Byte)value).byteValue()); 
/*  93 */     if (value instanceof Character)
/*  94 */       return new Variant.VARIANT(((Character)value).charValue()); 
/*  95 */     if (value instanceof Short)
/*  96 */       return new Variant.VARIANT(((Short)value).shortValue()); 
/*  97 */     if (value instanceof Integer)
/*  98 */       return new Variant.VARIANT(((Integer)value).intValue()); 
/*  99 */     if (value instanceof Long)
/* 100 */       return new Variant.VARIANT(((Long)value).longValue()); 
/* 101 */     if (value instanceof Float)
/* 102 */       return new Variant.VARIANT(((Float)value).floatValue()); 
/* 103 */     if (value instanceof Double)
/* 104 */       return new Variant.VARIANT(((Double)value).doubleValue()); 
/* 105 */     if (value instanceof String)
/* 106 */       return new Variant.VARIANT((String)value); 
/* 107 */     if (value instanceof Boolean)
/* 108 */       return new Variant.VARIANT(((Boolean)value).booleanValue()); 
/* 109 */     if (value instanceof Dispatch)
/* 110 */       return new Variant.VARIANT((Dispatch)value); 
/* 111 */     if (value instanceof Date)
/* 112 */       return new Variant.VARIANT((Date)value); 
/* 113 */     if (value instanceof Proxy) {
/* 114 */       InvocationHandler ih = Proxy.getInvocationHandler(value);
/* 115 */       ProxyObject pobj = (ProxyObject)ih;
/* 116 */       return new Variant.VARIANT(pobj.getRawDispatch());
/* 117 */     }  if (value instanceof IComEnum) {
/* 118 */       IComEnum enm = (IComEnum)value;
/* 119 */       return new Variant.VARIANT(new WinDef.LONG(enm.getValue()));
/*     */     } 
/* 121 */     Constructor<Variant.VARIANT> constructor = null;
/* 122 */     if (value != null) {
/* 123 */       for (Constructor<Variant.VARIANT> m : (Constructor[])Variant.VARIANT.class.getConstructors()) {
/* 124 */         Class<?>[] parameters = m.getParameterTypes();
/* 125 */         if (parameters.length == 1 && parameters[0]
/* 126 */           .isAssignableFrom(value.getClass())) {
/* 127 */           constructor = m;
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 132 */     if (constructor != null) {
/*     */       try {
/* 134 */         return constructor.newInstance(new Object[] { value });
/* 135 */       } catch (Exception ex) {
/* 136 */         throw new RuntimeException(ex);
/*     */       } 
/*     */     }
/* 139 */     return null;
/*     */   }
/*     */   
/*     */   public static Object toJavaObject(Variant.VARIANT value, Class<?> targetClass, ObjectFactory factory, boolean addReference, boolean freeValue) {
/*     */     Object result;
/* 144 */     if (null == value || value
/* 145 */       .getVarType().intValue() == 0 || value
/* 146 */       .getVarType().intValue() == 1) {
/* 147 */       return null;
/*     */     }
/*     */     
/* 150 */     if (targetClass != null && !targetClass.isAssignableFrom(Object.class)) {
/* 151 */       if (targetClass.isAssignableFrom(value.getClass())) {
/* 152 */         return value;
/*     */       }
/*     */       
/* 155 */       Object vobj = value.getValue();
/* 156 */       if (vobj != null && targetClass.isAssignableFrom(vobj.getClass())) {
/* 157 */         return vobj;
/*     */       }
/*     */     } 
/*     */     
/* 161 */     Variant.VARIANT inputValue = value;
/*     */     
/* 163 */     if (value.getVarType().intValue() == 16396) {
/* 164 */       value = (Variant.VARIANT)value.getValue();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 169 */     if (targetClass == null || targetClass.isAssignableFrom(Object.class)) {
/*     */       
/* 171 */       targetClass = null;
/*     */       
/* 173 */       int varType = value.getVarType().intValue();
/*     */       
/* 175 */       switch (value.getVarType().intValue()) {
/*     */         case 16:
/*     */         case 17:
/* 178 */           targetClass = Byte.class;
/*     */           break;
/*     */         case 2:
/* 181 */           targetClass = Short.class;
/*     */           break;
/*     */         case 18:
/* 184 */           targetClass = Character.class;
/*     */           break;
/*     */         case 3:
/*     */         case 19:
/*     */         case 22:
/*     */         case 23:
/* 190 */           targetClass = Integer.class;
/*     */           break;
/*     */         case 20:
/*     */         case 21:
/* 194 */           targetClass = Long.class;
/*     */           break;
/*     */         case 4:
/* 197 */           targetClass = Float.class;
/*     */           break;
/*     */         case 5:
/* 200 */           targetClass = Double.class;
/*     */           break;
/*     */         case 11:
/* 203 */           targetClass = Boolean.class;
/*     */           break;
/*     */         case 10:
/* 206 */           targetClass = WinDef.SCODE.class;
/*     */           break;
/*     */         case 6:
/* 209 */           targetClass = OaIdl.CURRENCY.class;
/*     */           break;
/*     */         case 7:
/* 212 */           targetClass = Date.class;
/*     */           break;
/*     */         case 8:
/* 215 */           targetClass = String.class;
/*     */           break;
/*     */         case 13:
/* 218 */           targetClass = IUnknown.class;
/*     */           break;
/*     */         case 9:
/* 221 */           targetClass = IDispatch.class;
/*     */           break;
/*     */         case 16396:
/* 224 */           targetClass = Variant.class;
/*     */           break;
/*     */         case 16384:
/* 227 */           targetClass = WinDef.PVOID.class;
/*     */           break;
/*     */         case 16398:
/* 230 */           targetClass = OaIdl.DECIMAL.class;
/*     */           break;
/*     */         
/*     */         default:
/* 234 */           if ((varType & 0x2000) > 0) {
/* 235 */             targetClass = OaIdl.SAFEARRAY.class;
/*     */           }
/*     */           break;
/*     */       } 
/*     */     
/*     */     } 
/* 241 */     if (Byte.class.equals(targetClass) || byte.class.equals(targetClass)) {
/* 242 */       result = Byte.valueOf(value.byteValue());
/* 243 */     } else if (Short.class.equals(targetClass) || short.class.equals(targetClass)) {
/* 244 */       result = Short.valueOf(value.shortValue());
/* 245 */     } else if (Character.class.equals(targetClass) || char.class.equals(targetClass)) {
/* 246 */       result = Character.valueOf((char)value.intValue());
/* 247 */     } else if (Integer.class.equals(targetClass) || int.class.equals(targetClass)) {
/* 248 */       result = Integer.valueOf(value.intValue());
/* 249 */     } else if (Long.class.equals(targetClass) || long.class.equals(targetClass) || IComEnum.class.isAssignableFrom(targetClass)) {
/* 250 */       result = Long.valueOf(value.longValue());
/* 251 */     } else if (Float.class.equals(targetClass) || float.class.equals(targetClass)) {
/* 252 */       result = Float.valueOf(value.floatValue());
/* 253 */     } else if (Double.class.equals(targetClass) || double.class.equals(targetClass)) {
/* 254 */       result = Double.valueOf(value.doubleValue());
/* 255 */     } else if (Boolean.class.equals(targetClass) || boolean.class.equals(targetClass)) {
/* 256 */       result = Boolean.valueOf(value.booleanValue());
/* 257 */     } else if (Date.class.equals(targetClass)) {
/* 258 */       result = value.dateValue();
/* 259 */     } else if (String.class.equals(targetClass)) {
/* 260 */       result = value.stringValue();
/* 261 */     } else if (value.getValue() instanceof Dispatch) {
/* 262 */       Dispatch d = (Dispatch)value.getValue();
/* 263 */       if (targetClass != null && targetClass.isInterface()) {
/* 264 */         Object proxy = factory.createProxy(targetClass, (IDispatch)d);
/*     */ 
/*     */         
/* 267 */         if (!addReference) {
/* 268 */           int i = d.Release();
/*     */         }
/* 270 */         result = proxy;
/*     */       } else {
/* 272 */         result = d;
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */ 
/*     */       
/* 284 */       result = value.getValue();
/*     */     } 
/*     */     
/* 287 */     if (IComEnum.class.isAssignableFrom(targetClass)) {
/* 288 */       result = targetClass.cast(toComEnum(targetClass, result));
/*     */     }
/*     */     
/* 291 */     if (freeValue) {
/* 292 */       free(inputValue, result);
/*     */     }
/*     */     
/* 295 */     return result;
/*     */   }
/*     */   
/*     */   public static <T extends IComEnum> T toComEnum(Class<T> enumType, Object value) {
/*     */     
/* 300 */     try { Method m = enumType.getMethod("values", new Class[0]);
/* 301 */       IComEnum[] arrayOfIComEnum = (IComEnum[])m.invoke(null, new Object[0]);
/* 302 */       for (IComEnum iComEnum : arrayOfIComEnum) {
/* 303 */         if (value.equals(Long.valueOf(iComEnum.getValue()))) {
/* 304 */           return (T)iComEnum;
/*     */         }
/*     */       }  }
/* 307 */     catch (NoSuchMethodException noSuchMethodException) {  }
/* 308 */     catch (IllegalAccessException illegalAccessException) {  }
/* 309 */     catch (IllegalArgumentException illegalArgumentException) {  }
/* 310 */     catch (InvocationTargetException invocationTargetException) {}
/*     */     
/* 312 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void free(Variant.VARIANT variant, Class<?> javaType) {
/* 325 */     if ((javaType == null || !WTypes.BSTR.class.isAssignableFrom(javaType)) && variant != null && variant
/*     */       
/* 327 */       .getVarType().intValue() == 8) {
/* 328 */       Object value = variant.getValue();
/* 329 */       if (value instanceof WTypes.BSTR) {
/* 330 */         OleAuto.INSTANCE.SysFreeString((WTypes.BSTR)value);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void free(Variant.VARIANT variant, Object value) {
/* 345 */     free(variant, (value == null) ? null : value.getClass());
/*     */   }
/*     */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\com\sun\jna\platform\win32\CO\\util\Convert.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */