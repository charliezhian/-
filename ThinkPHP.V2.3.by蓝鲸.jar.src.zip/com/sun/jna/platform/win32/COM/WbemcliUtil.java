/*     */ package com.sun.jna.platform.win32.COM;
/*     */ 
/*     */ import com.sun.jna.Pointer;
/*     */ import com.sun.jna.WString;
/*     */ import com.sun.jna.platform.win32.Ole32;
/*     */ import com.sun.jna.platform.win32.OleAuto;
/*     */ import com.sun.jna.platform.win32.Variant;
/*     */ import com.sun.jna.platform.win32.WinNT;
/*     */ import com.sun.jna.ptr.IntByReference;
/*     */ import java.util.ArrayList;
/*     */ import java.util.EnumMap;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WbemcliUtil
/*     */ {
/*  54 */   public static final WbemcliUtil INSTANCE = new WbemcliUtil();
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String DEFAULT_NAMESPACE = "ROOT\\CIMV2";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private enum NamespaceProperty
/*     */   {
/*  65 */     NAME;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class WmiQuery<T extends Enum<T>>
/*     */   {
/*     */     private String nameSpace;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String wmiClassName;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Class<T> propertyEnum;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public WmiQuery(String nameSpace, String wmiClassName, Class<T> propertyEnum) {
/*  91 */       this.nameSpace = nameSpace;
/*  92 */       this.wmiClassName = wmiClassName;
/*  93 */       this.propertyEnum = propertyEnum;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public WmiQuery(String wmiClassName, Class<T> propertyEnum) {
/* 104 */       this("ROOT\\CIMV2", wmiClassName, propertyEnum);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Class<T> getPropertyEnum() {
/* 111 */       return this.propertyEnum;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getNameSpace() {
/* 118 */       return this.nameSpace;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setNameSpace(String nameSpace) {
/* 126 */       this.nameSpace = nameSpace;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getWmiClassName() {
/* 133 */       return this.wmiClassName;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setWmiClassName(String wmiClassName) {
/* 141 */       this.wmiClassName = wmiClassName;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public WbemcliUtil.WmiResult<T> execute() {
/*     */       try {
/* 152 */         return execute(-1);
/* 153 */       } catch (TimeoutException e) {
/* 154 */         throw new COMException("Got a WMI timeout when infinite wait was specified. This should never happen.");
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public WbemcliUtil.WmiResult<T> execute(int timeout) throws TimeoutException {
/* 175 */       if (((Enum[])getPropertyEnum().getEnumConstants()).length < 1) {
/* 176 */         throw new IllegalArgumentException("The query's property enum has no values.");
/*     */       }
/*     */ 
/*     */       
/* 180 */       Wbemcli.IWbemServices svc = WbemcliUtil.connectServer(getNameSpace());
/*     */ 
/*     */       
/*     */       try {
/* 184 */         Wbemcli.IEnumWbemClassObject enumerator = selectProperties(svc, this);
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */       finally {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 194 */         svc.Release();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static <T extends Enum<T>> Wbemcli.IEnumWbemClassObject selectProperties(Wbemcli.IWbemServices svc, WmiQuery<T> query) {
/* 214 */       Enum[] arrayOfEnum = query.getPropertyEnum().getEnumConstants();
/* 215 */       StringBuilder sb = new StringBuilder("SELECT ");
/*     */       
/* 217 */       sb.append(arrayOfEnum[0].name());
/* 218 */       for (int i = 1; i < arrayOfEnum.length; i++) {
/* 219 */         sb.append(',').append(arrayOfEnum[i].name());
/*     */       }
/* 221 */       sb.append(" FROM ").append(query.getWmiClassName());
/*     */ 
/*     */       
/* 224 */       return svc.ExecQuery("WQL", sb.toString().replaceAll("\\\\", "\\\\\\\\"), 48, null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static <T extends Enum<T>> WbemcliUtil.WmiResult<T> enumerateProperties(Wbemcli.IEnumWbemClassObject enumerator, Class<T> propertyEnum, int timeout) throws TimeoutException {
/* 281 */       WbemcliUtil.INSTANCE.getClass(); WbemcliUtil.WmiResult<T> values = new WbemcliUtil.WmiResult<T>(propertyEnum);
/*     */ 
/*     */       
/* 284 */       Pointer[] pclsObj = new Pointer[1];
/* 285 */       IntByReference uReturn = new IntByReference(0);
/* 286 */       Map<T, WString> wstrMap = new HashMap<T, WString>();
/* 287 */       WinNT.HRESULT hres = null;
/* 288 */       for (Enum enum_ : (Enum[])propertyEnum.getEnumConstants()) {
/* 289 */         wstrMap.put((T)enum_, new WString(enum_.name()));
/*     */       }
/* 291 */       while (enumerator.getPointer() != Pointer.NULL) {
/*     */ 
/*     */         
/* 294 */         hres = enumerator.Next(timeout, pclsObj.length, pclsObj, uReturn);
/*     */         
/* 296 */         if (hres.intValue() == 1 || hres.intValue() == 262149) {
/*     */           break;
/*     */         }
/*     */         
/* 300 */         if (hres.intValue() == 262148) {
/* 301 */           throw new TimeoutException("No results after " + timeout + " ms.");
/*     */         }
/*     */         
/* 304 */         if (COMUtils.FAILED(hres)) {
/* 305 */           throw new COMException("Failed to enumerate results.", hres);
/*     */         }
/*     */         
/* 308 */         Variant.VARIANT.ByReference pVal = new Variant.VARIANT.ByReference();
/* 309 */         IntByReference pType = new IntByReference();
/*     */ 
/*     */         
/* 312 */         Wbemcli.IWbemClassObject clsObj = new Wbemcli.IWbemClassObject(pclsObj[0]);
/* 313 */         for (Enum enum_ : (Enum[])propertyEnum.getEnumConstants()) {
/* 314 */           clsObj.Get(wstrMap.get(enum_), 0, pVal, pType, (IntByReference)null);
/* 315 */           int vtType = ((pVal.getValue() == null) ? Integer.valueOf(1) : pVal.getVarType()).intValue();
/* 316 */           int cimType = pType.getValue();
/* 317 */           switch (vtType) {
/*     */             case 8:
/* 319 */               values.add(vtType, cimType, (T)enum_, pVal.stringValue());
/*     */               break;
/*     */             case 3:
/* 322 */               values.add(vtType, cimType, (T)enum_, Integer.valueOf(pVal.intValue()));
/*     */               break;
/*     */             case 17:
/* 325 */               values.add(vtType, cimType, (T)enum_, Byte.valueOf(pVal.byteValue()));
/*     */               break;
/*     */             case 2:
/* 328 */               values.add(vtType, cimType, (T)enum_, Short.valueOf(pVal.shortValue()));
/*     */               break;
/*     */             case 11:
/* 331 */               values.add(vtType, cimType, (T)enum_, Boolean.valueOf(pVal.booleanValue()));
/*     */               break;
/*     */             case 4:
/* 334 */               values.add(vtType, cimType, (T)enum_, Float.valueOf(pVal.floatValue()));
/*     */               break;
/*     */             case 5:
/* 337 */               values.add(vtType, cimType, (T)enum_, Double.valueOf(pVal.doubleValue()));
/*     */               break;
/*     */             case 1:
/* 340 */               values.add(vtType, cimType, (T)enum_, null);
/*     */               break;
/*     */             
/*     */             default:
/* 344 */               values.add(vtType, cimType, (T)enum_, pVal.getValue()); break;
/*     */           } 
/* 346 */           OleAuto.INSTANCE.VariantClear((Variant.VARIANT)pVal);
/*     */         } 
/* 348 */         clsObj.Release();
/*     */         
/* 350 */         values.incrementResultCount();
/*     */       } 
/* 352 */       return values;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public class WmiResult<T extends Enum<T>>
/*     */   {
/*     */     private Map<T, List<Object>> propertyMap;
/*     */     
/*     */     private Map<T, Integer> vtTypeMap;
/*     */     private Map<T, Integer> cimTypeMap;
/* 363 */     private int resultCount = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public WmiResult(Class<T> propertyEnum) {
/* 370 */       this.propertyMap = new EnumMap<T, List<Object>>(propertyEnum);
/* 371 */       this.vtTypeMap = new EnumMap<T, Integer>(propertyEnum);
/* 372 */       this.cimTypeMap = new EnumMap<T, Integer>(propertyEnum);
/* 373 */       for (Enum enum_ : (Enum[])propertyEnum.getEnumConstants()) {
/* 374 */         this.propertyMap.put((T)enum_, new ArrayList());
/* 375 */         this.vtTypeMap.put((T)enum_, Integer.valueOf(1));
/* 376 */         this.cimTypeMap.put((T)enum_, Integer.valueOf(0));
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Object getValue(T property, int index) {
/* 394 */       return ((List)this.propertyMap.get(property)).get(index);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getVtType(T property) {
/* 407 */       return ((Integer)this.vtTypeMap.get(property)).intValue();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getCIMType(T property) {
/* 419 */       return ((Integer)this.cimTypeMap.get(property)).intValue();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void add(int vtType, int cimType, T property, Object o) {
/* 435 */       ((List<Object>)this.propertyMap.get(property)).add(o);
/* 436 */       if (vtType != 1 && ((Integer)this.vtTypeMap.get(property)).equals(Integer.valueOf(1))) {
/* 437 */         this.vtTypeMap.put(property, Integer.valueOf(vtType));
/*     */       }
/* 439 */       if (((Integer)this.cimTypeMap.get(property)).equals(Integer.valueOf(0))) {
/* 440 */         this.cimTypeMap.put(property, Integer.valueOf(cimType));
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getResultCount() {
/* 448 */       return this.resultCount;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void incrementResultCount() {
/* 455 */       this.resultCount++;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasNamespace(String namespace) {
/* 470 */     String ns = namespace;
/* 471 */     if (namespace.toUpperCase().startsWith("ROOT\\")) {
/* 472 */       ns = namespace.substring(5);
/*     */     }
/*     */     
/* 475 */     WmiQuery<NamespaceProperty> namespaceQuery = new WmiQuery<NamespaceProperty>("ROOT", "__NAMESPACE", NamespaceProperty.class);
/* 476 */     WmiResult<NamespaceProperty> namespaces = namespaceQuery.execute();
/* 477 */     for (int i = 0; i < namespaces.getResultCount(); i++) {
/* 478 */       if (ns.equalsIgnoreCase((String)namespaces.getValue(NamespaceProperty.NAME, i))) {
/* 479 */         return true;
/*     */       }
/*     */     } 
/* 482 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Wbemcli.IWbemServices connectServer(String namespace) {
/* 509 */     Wbemcli.IWbemLocator loc = Wbemcli.IWbemLocator.create();
/* 510 */     if (loc == null) {
/* 511 */       throw new COMException("Failed to create WbemLocator object.");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 518 */     Wbemcli.IWbemServices services = loc.ConnectServer(namespace, (String)null, (String)null, (String)null, 0, (String)null, (Wbemcli.IWbemContext)null);
/*     */ 
/*     */     
/* 521 */     loc.Release();
/*     */ 
/*     */ 
/*     */     
/* 525 */     WinNT.HRESULT hres = Ole32.INSTANCE.CoSetProxyBlanket(services, 10, 0, null, 3, 3, null, 0);
/*     */     
/* 527 */     if (COMUtils.FAILED(hres)) {
/* 528 */       services.Release();
/* 529 */       throw new COMException("Could not set proxy blanket.", hres);
/*     */     } 
/* 531 */     return services;
/*     */   }
/*     */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\com\sun\jna\platform\win32\COM\WbemcliUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */