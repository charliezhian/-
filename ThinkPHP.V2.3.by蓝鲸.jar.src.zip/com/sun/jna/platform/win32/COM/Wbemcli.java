/*     */ package com.sun.jna.platform.win32.COM;
/*     */ 
/*     */ import com.sun.jna.Pointer;
/*     */ import com.sun.jna.WString;
/*     */ import com.sun.jna.platform.win32.Guid;
/*     */ import com.sun.jna.platform.win32.Ole32;
/*     */ import com.sun.jna.platform.win32.OleAuto;
/*     */ import com.sun.jna.platform.win32.Variant;
/*     */ import com.sun.jna.platform.win32.WTypes;
/*     */ import com.sun.jna.platform.win32.WinNT;
/*     */ import com.sun.jna.ptr.IntByReference;
/*     */ import com.sun.jna.ptr.PointerByReference;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface Wbemcli
/*     */ {
/*     */   public static final int WBEM_FLAG_RETURN_IMMEDIATELY = 16;
/*     */   public static final int WBEM_FLAG_FORWARD_ONLY = 32;
/*     */   public static final int WBEM_INFINITE = -1;
/*     */   public static final int WBEM_S_NO_ERROR = 0;
/*     */   public static final int WBEM_S_FALSE = 1;
/*     */   public static final int WBEM_S_TIMEDOUT = 262148;
/*     */   public static final int WBEM_S_NO_MORE_DATA = 262149;
/*     */   public static final int WBEM_E_INVALID_NAMESPACE = -2147217394;
/*     */   public static final int WBEM_E_INVALID_CLASS = -2147217392;
/*     */   public static final int WBEM_E_INVALID_QUERY = -2147217385;
/*     */   public static final int CIM_ILLEGAL = 4095;
/*     */   public static final int CIM_EMPTY = 0;
/*     */   public static final int CIM_SINT8 = 16;
/*     */   public static final int CIM_UINT8 = 17;
/*     */   public static final int CIM_SINT16 = 2;
/*     */   public static final int CIM_UINT16 = 18;
/*     */   public static final int CIM_SINT32 = 3;
/*     */   public static final int CIM_UINT32 = 19;
/*     */   public static final int CIM_SINT64 = 20;
/*     */   public static final int CIM_UINT64 = 21;
/*     */   public static final int CIM_REAL32 = 4;
/*     */   public static final int CIM_REAL64 = 5;
/*     */   public static final int CIM_BOOLEAN = 11;
/*     */   public static final int CIM_STRING = 8;
/*     */   public static final int CIM_DATETIME = 101;
/*     */   public static final int CIM_REFERENCE = 102;
/*     */   public static final int CIM_CHAR16 = 103;
/*     */   public static final int CIM_OBJECT = 13;
/*     */   public static final int CIM_FLAG_ARRAY = 8192;
/*     */   
/*     */   public static class IWbemClassObject
/*     */     extends Unknown
/*     */   {
/*     */     public IWbemClassObject() {}
/*     */     
/*     */     public IWbemClassObject(Pointer pvInstance) {
/*  94 */       super(pvInstance);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public WinNT.HRESULT Get(WString wszName, int lFlags, Variant.VARIANT.ByReference pVal, IntByReference pType, IntByReference plFlavor) {
/* 100 */       return (WinNT.HRESULT)_invokeNativeObject(4, new Object[] {
/* 101 */             getPointer(), wszName, Integer.valueOf(lFlags), pVal, pType, plFlavor }, WinNT.HRESULT.class);
/*     */     }
/*     */ 
/*     */     
/*     */     public WinNT.HRESULT Get(String wszName, int lFlags, Variant.VARIANT.ByReference pVal, IntByReference pType, IntByReference plFlavor) {
/* 106 */       return Get((wszName == null) ? null : new WString(wszName), lFlags, pVal, pType, plFlavor);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class IEnumWbemClassObject
/*     */     extends Unknown
/*     */   {
/*     */     public IEnumWbemClassObject() {}
/*     */ 
/*     */     
/*     */     public IEnumWbemClassObject(Pointer pvInstance) {
/* 119 */       super(pvInstance);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public WinNT.HRESULT Next(int lTimeOut, int uCount, Pointer[] ppObjects, IntByReference puReturned) {
/* 125 */       return (WinNT.HRESULT)_invokeNativeObject(4, new Object[] {
/* 126 */             getPointer(), Integer.valueOf(lTimeOut), Integer.valueOf(uCount), ppObjects, puReturned }, WinNT.HRESULT.class);
/*     */     }
/*     */     
/*     */     public Wbemcli.IWbemClassObject[] Next(int lTimeOut, int uCount) {
/* 130 */       Pointer[] resultArray = new Pointer[uCount];
/* 131 */       IntByReference resultCount = new IntByReference();
/* 132 */       WinNT.HRESULT result = Next(lTimeOut, uCount, resultArray, resultCount);
/* 133 */       COMUtils.checkRC(result);
/* 134 */       Wbemcli.IWbemClassObject[] returnValue = new Wbemcli.IWbemClassObject[resultCount.getValue()];
/* 135 */       for (int i = 0; i < resultCount.getValue(); i++) {
/* 136 */         returnValue[i] = new Wbemcli.IWbemClassObject(resultArray[i]);
/*     */       }
/* 138 */       return returnValue;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class IWbemLocator
/*     */     extends Unknown
/*     */   {
/* 148 */     public static final Guid.CLSID CLSID_WbemLocator = new Guid.CLSID("4590f811-1d3a-11d0-891f-00aa004b2e24");
/* 149 */     public static final Guid.GUID IID_IWbemLocator = new Guid.GUID("dc12a687-737f-11cf-884d-00aa004b2e24");
/*     */ 
/*     */     
/*     */     public IWbemLocator() {}
/*     */     
/*     */     private IWbemLocator(Pointer pvInstance) {
/* 155 */       super(pvInstance);
/*     */     }
/*     */     
/*     */     public static IWbemLocator create() {
/* 159 */       PointerByReference pbr = new PointerByReference();
/*     */       
/* 161 */       WinNT.HRESULT hres = Ole32.INSTANCE.CoCreateInstance((Guid.GUID)CLSID_WbemLocator, null, 1, IID_IWbemLocator, pbr);
/*     */       
/* 163 */       if (COMUtils.FAILED(hres)) {
/* 164 */         return null;
/*     */       }
/*     */       
/* 167 */       return new IWbemLocator(pbr.getValue());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public WinNT.HRESULT ConnectServer(WTypes.BSTR strNetworkResource, WTypes.BSTR strUser, WTypes.BSTR strPassword, WTypes.BSTR strLocale, int lSecurityFlags, WTypes.BSTR strAuthority, Wbemcli.IWbemContext pCtx, PointerByReference ppNamespace) {
/* 173 */       return (WinNT.HRESULT)_invokeNativeObject(3, new Object[] { getPointer(), strNetworkResource, strUser, strPassword, strLocale, 
/* 174 */             Integer.valueOf(lSecurityFlags), strAuthority, pCtx, ppNamespace }, WinNT.HRESULT.class);
/*     */     }
/*     */ 
/*     */     
/*     */     public Wbemcli.IWbemServices ConnectServer(String strNetworkResource, String strUser, String strPassword, String strLocale, int lSecurityFlags, String strAuthority, Wbemcli.IWbemContext pCtx) {
/* 179 */       WTypes.BSTR strNetworkResourceBSTR = OleAuto.INSTANCE.SysAllocString(strNetworkResource);
/* 180 */       WTypes.BSTR strUserBSTR = OleAuto.INSTANCE.SysAllocString(strUser);
/* 181 */       WTypes.BSTR strPasswordBSTR = OleAuto.INSTANCE.SysAllocString(strPassword);
/* 182 */       WTypes.BSTR strLocaleBSTR = OleAuto.INSTANCE.SysAllocString(strLocale);
/* 183 */       WTypes.BSTR strAuthorityBSTR = OleAuto.INSTANCE.SysAllocString(strAuthority);
/*     */       
/* 185 */       PointerByReference pbr = new PointerByReference();
/*     */       
/*     */       try {
/* 188 */         WinNT.HRESULT result = ConnectServer(strNetworkResourceBSTR, strUserBSTR, strPasswordBSTR, strLocaleBSTR, lSecurityFlags, strAuthorityBSTR, pCtx, pbr);
/*     */ 
/*     */         
/* 191 */         COMUtils.checkRC(result);
/*     */         
/* 193 */         return new Wbemcli.IWbemServices(pbr.getValue());
/*     */       } finally {
/* 195 */         OleAuto.INSTANCE.SysFreeString(strNetworkResourceBSTR);
/* 196 */         OleAuto.INSTANCE.SysFreeString(strUserBSTR);
/* 197 */         OleAuto.INSTANCE.SysFreeString(strPasswordBSTR);
/* 198 */         OleAuto.INSTANCE.SysFreeString(strLocaleBSTR);
/* 199 */         OleAuto.INSTANCE.SysFreeString(strAuthorityBSTR);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class IWbemServices
/*     */     extends Unknown
/*     */   {
/*     */     public IWbemServices() {}
/*     */ 
/*     */ 
/*     */     
/*     */     public IWbemServices(Pointer pvInstance) {
/* 214 */       super(pvInstance);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public WinNT.HRESULT ExecQuery(WTypes.BSTR strQueryLanguage, WTypes.BSTR strQuery, int lFlags, Wbemcli.IWbemContext pCtx, PointerByReference ppEnum) {
/* 220 */       return (WinNT.HRESULT)_invokeNativeObject(20, new Object[] {
/* 221 */             getPointer(), strQueryLanguage, strQuery, Integer.valueOf(lFlags), pCtx, ppEnum }, WinNT.HRESULT.class);
/*     */     }
/*     */     
/*     */     public Wbemcli.IEnumWbemClassObject ExecQuery(String strQueryLanguage, String strQuery, int lFlags, Wbemcli.IWbemContext pCtx) {
/* 225 */       WTypes.BSTR strQueryLanguageBSTR = OleAuto.INSTANCE.SysAllocString(strQueryLanguage);
/* 226 */       WTypes.BSTR strQueryBSTR = OleAuto.INSTANCE.SysAllocString(strQuery);
/*     */       try {
/* 228 */         PointerByReference pbr = new PointerByReference();
/*     */         
/* 230 */         WinNT.HRESULT res = ExecQuery(strQueryLanguageBSTR, strQueryBSTR, lFlags, pCtx, pbr);
/*     */         
/* 232 */         COMUtils.checkRC(res);
/*     */         
/* 234 */         return new Wbemcli.IEnumWbemClassObject(pbr.getValue());
/*     */       } finally {
/* 236 */         OleAuto.INSTANCE.SysFreeString(strQueryLanguageBSTR);
/* 237 */         OleAuto.INSTANCE.SysFreeString(strQueryBSTR);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class IWbemContext
/*     */     extends Unknown
/*     */   {
/*     */     public IWbemContext() {}
/*     */ 
/*     */ 
/*     */     
/*     */     public IWbemContext(Pointer pvInstance) {
/* 252 */       super(pvInstance);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\com\sun\jna\platform\win32\COM\Wbemcli.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */