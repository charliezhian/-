package com.sun.jna.platform.win32.COM;

import com.sun.jna.Pointer;

public interface IUnknownCallback extends IUnknown {
  Pointer getPointer();
}


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\com\sun\jna\platform\win32\COM\IUnknownCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */