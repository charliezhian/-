/*     */ package com.sun.jna.platform.win32;
/*     */ 
/*     */ import com.sun.jna.Memory;
/*     */ import com.sun.jna.Pointer;
/*     */ import com.sun.jna.Structure;
/*     */ import com.sun.jna.ptr.IntByReference;
/*     */ import java.io.Closeable;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class W32Service
/*     */   implements Closeable
/*     */ {
/*  55 */   Winsvc.SC_HANDLE _handle = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public W32Service(Winsvc.SC_HANDLE handle) {
/*  64 */     this._handle = handle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/*  72 */     if (this._handle != null) {
/*  73 */       if (!Advapi32.INSTANCE.CloseServiceHandle(this._handle)) {
/*  74 */         throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*     */       }
/*  76 */       this._handle = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void addShutdownPrivilegeToProcess() {
/*  81 */     WinNT.HANDLEByReference hToken = new WinNT.HANDLEByReference();
/*  82 */     WinNT.LUID luid = new WinNT.LUID();
/*  83 */     Advapi32.INSTANCE.OpenProcessToken(Kernel32.INSTANCE.GetCurrentProcess(), 32, hToken);
/*     */     
/*  85 */     Advapi32.INSTANCE.LookupPrivilegeValue("", "SeShutdownPrivilege", luid);
/*  86 */     WinNT.TOKEN_PRIVILEGES tp = new WinNT.TOKEN_PRIVILEGES(1);
/*  87 */     tp.Privileges[0] = new WinNT.LUID_AND_ATTRIBUTES(luid, new WinDef.DWORD(2L));
/*  88 */     Advapi32.INSTANCE.AdjustTokenPrivileges(hToken.getValue(), false, tp, tp.size(), null, new IntByReference());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFailureActions(List<Winsvc.SC_ACTION> actions, int resetPeriod, String rebootMsg, String command) {
/*  99 */     Winsvc.SERVICE_FAILURE_ACTIONS.ByReference actionStruct = new Winsvc.SERVICE_FAILURE_ACTIONS.ByReference();
/* 100 */     actionStruct.dwResetPeriod = resetPeriod;
/* 101 */     actionStruct.lpRebootMsg = rebootMsg;
/* 102 */     actionStruct.lpCommand = command;
/* 103 */     actionStruct.cActions = actions.size();
/*     */     
/* 105 */     actionStruct.lpsaActions = new Winsvc.SC_ACTION.ByReference();
/* 106 */     Winsvc.SC_ACTION[] actionArray = (Winsvc.SC_ACTION[])actionStruct.lpsaActions.toArray(actions.size());
/* 107 */     boolean hasShutdownPrivilege = false;
/* 108 */     int i = 0;
/* 109 */     for (Winsvc.SC_ACTION action : actions) {
/* 110 */       if (!hasShutdownPrivilege && action.type == 2) {
/* 111 */         addShutdownPrivilegeToProcess();
/* 112 */         hasShutdownPrivilege = true;
/*     */       } 
/* 114 */       (actionArray[i]).type = action.type;
/* 115 */       (actionArray[i]).delay = action.delay;
/* 116 */       i++;
/*     */     } 
/*     */     
/* 119 */     if (!Advapi32.INSTANCE.ChangeServiceConfig2(this._handle, 2, actionStruct))
/*     */     {
/* 121 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*     */     }
/*     */   }
/*     */   
/*     */   private Pointer queryServiceConfig2(int type) {
/* 126 */     IntByReference bufferSize = new IntByReference();
/* 127 */     Advapi32.INSTANCE.QueryServiceConfig2(this._handle, type, Pointer.NULL, 0, bufferSize);
/*     */     
/* 129 */     Memory memory = new Memory(bufferSize.getValue());
/*     */     
/* 131 */     if (!Advapi32.INSTANCE.QueryServiceConfig2(this._handle, type, (Pointer)memory, bufferSize.getValue(), new IntByReference()))
/*     */     {
/* 133 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*     */     }
/*     */     
/* 136 */     return (Pointer)memory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Winsvc.SERVICE_FAILURE_ACTIONS getFailureActions() {
/* 145 */     Pointer buffer = queryServiceConfig2(2);
/* 146 */     Winsvc.SERVICE_FAILURE_ACTIONS result = new Winsvc.SERVICE_FAILURE_ACTIONS(buffer);
/* 147 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFailureActionsFlag(boolean flagValue) {
/* 156 */     Winsvc.SERVICE_FAILURE_ACTIONS_FLAG flag = new Winsvc.SERVICE_FAILURE_ACTIONS_FLAG();
/* 157 */     flag.fFailureActionsOnNonCrashFailures = flagValue ? 1 : 0;
/*     */     
/* 159 */     if (!Advapi32.INSTANCE.ChangeServiceConfig2(this._handle, 4, flag))
/*     */     {
/* 161 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getFailureActionsFlag() {
/* 171 */     Pointer buffer = queryServiceConfig2(4);
/* 172 */     Winsvc.SERVICE_FAILURE_ACTIONS_FLAG result = new Winsvc.SERVICE_FAILURE_ACTIONS_FLAG(buffer);
/* 173 */     return (result.fFailureActionsOnNonCrashFailures != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Winsvc.SERVICE_STATUS_PROCESS queryStatus() {
/* 182 */     IntByReference size = new IntByReference();
/*     */     
/* 184 */     Advapi32.INSTANCE.QueryServiceStatusEx(this._handle, 0, null, 0, size);
/*     */ 
/*     */     
/* 187 */     Winsvc.SERVICE_STATUS_PROCESS status = new Winsvc.SERVICE_STATUS_PROCESS(size.getValue());
/* 188 */     if (!Advapi32.INSTANCE.QueryServiceStatusEx(this._handle, 0, status, status
/* 189 */         .size(), size)) {
/* 190 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*     */     }
/*     */     
/* 193 */     return status;
/*     */   }
/*     */   
/*     */   public void startService() {
/* 197 */     waitForNonPendingState();
/*     */     
/* 199 */     if ((queryStatus()).dwCurrentState == 4) {
/*     */       return;
/*     */     }
/* 202 */     if (!Advapi32.INSTANCE.StartService(this._handle, 0, null)) {
/* 203 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*     */     }
/* 205 */     waitForNonPendingState();
/* 206 */     if ((queryStatus()).dwCurrentState != 4) {
/* 207 */       throw new RuntimeException("Unable to start the service");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stopService() {
/* 215 */     stopService(30000L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void stopService(long timeout) {
/* 225 */     long startTime = System.currentTimeMillis();
/* 226 */     waitForNonPendingState();
/*     */     
/* 228 */     if ((queryStatus()).dwCurrentState == 1) {
/*     */       return;
/*     */     }
/* 231 */     Winsvc.SERVICE_STATUS status = new Winsvc.SERVICE_STATUS();
/* 232 */     if (!Advapi32.INSTANCE.ControlService(this._handle, 1, status)) {
/* 233 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 238 */     while (status.dwCurrentState != 1) {
/*     */       try {
/* 240 */         Thread.sleep(status.dwWaitHint);
/* 241 */       } catch (InterruptedException e) {
/* 242 */         throw new RuntimeException(e);
/*     */       } 
/* 244 */       if (!Advapi32.INSTANCE.QueryServiceStatus(this._handle, status)) {
/* 245 */         throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*     */       }
/* 247 */       if (System.currentTimeMillis() - startTime > timeout) {
/* 248 */         throw new RuntimeException(String.format("Service stop exceeded timeout time of %d ms", new Object[] { Long.valueOf(timeout) }));
/*     */       }
/*     */     } 
/* 251 */     waitForNonPendingState();
/* 252 */     if ((queryStatus()).dwCurrentState != 1) {
/* 253 */       throw new RuntimeException("Unable to stop the service");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void continueService() {
/* 261 */     waitForNonPendingState();
/*     */     
/* 263 */     if ((queryStatus()).dwCurrentState == 4) {
/*     */       return;
/*     */     }
/* 266 */     if (!Advapi32.INSTANCE.ControlService(this._handle, 3, new Winsvc.SERVICE_STATUS()))
/*     */     {
/* 268 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*     */     }
/* 270 */     waitForNonPendingState();
/* 271 */     if ((queryStatus()).dwCurrentState != 4) {
/* 272 */       throw new RuntimeException("Unable to continue the service");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void pauseService() {
/* 280 */     waitForNonPendingState();
/*     */     
/* 282 */     if ((queryStatus()).dwCurrentState == 7) {
/*     */       return;
/*     */     }
/* 285 */     if (!Advapi32.INSTANCE.ControlService(this._handle, 2, new Winsvc.SERVICE_STATUS()))
/*     */     {
/* 287 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*     */     }
/* 289 */     waitForNonPendingState();
/* 290 */     if ((queryStatus()).dwCurrentState != 7) {
/* 291 */       throw new RuntimeException("Unable to pause the service");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void waitForNonPendingState() {
/* 300 */     Winsvc.SERVICE_STATUS_PROCESS status = queryStatus();
/*     */     
/* 302 */     int previousCheckPoint = status.dwCheckPoint;
/* 303 */     int checkpointStartTickCount = Kernel32.INSTANCE.GetTickCount();
/*     */     
/* 305 */     while (isPendingState(status.dwCurrentState)) {
/*     */ 
/*     */       
/* 308 */       if (status.dwCheckPoint != previousCheckPoint) {
/* 309 */         previousCheckPoint = status.dwCheckPoint;
/* 310 */         checkpointStartTickCount = Kernel32.INSTANCE.GetTickCount();
/*     */       } 
/*     */ 
/*     */       
/* 314 */       if (Kernel32.INSTANCE.GetTickCount() - checkpointStartTickCount > status.dwWaitHint) {
/* 315 */         throw new RuntimeException("Timeout waiting for service to change to a non-pending state.");
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 322 */       int dwWaitTime = status.dwWaitHint / 10;
/*     */       
/* 324 */       if (dwWaitTime < 1000) {
/* 325 */         dwWaitTime = 1000;
/* 326 */       } else if (dwWaitTime > 10000) {
/* 327 */         dwWaitTime = 10000;
/*     */       } 
/*     */       try {
/* 330 */         Thread.sleep(dwWaitTime);
/* 331 */       } catch (InterruptedException e) {
/* 332 */         throw new RuntimeException(e);
/*     */       } 
/*     */       
/* 335 */       status = queryStatus();
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isPendingState(int state) {
/* 340 */     switch (state) {
/*     */       case 2:
/*     */       case 3:
/*     */       case 5:
/*     */       case 6:
/* 345 */         return true;
/*     */     } 
/* 347 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Winsvc.SC_HANDLE getHandle() {
/* 357 */     return this._handle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Winsvc.ENUM_SERVICE_STATUS[] enumDependentServices(int dwServiceState) {
/* 386 */     IntByReference pcbBytesNeeded = new IntByReference(0);
/* 387 */     IntByReference lpServicesReturned = new IntByReference(0);
/* 388 */     Advapi32.INSTANCE.EnumDependentServices(this._handle, dwServiceState, Pointer.NULL, 0, pcbBytesNeeded, lpServicesReturned);
/* 389 */     int lastError = Kernel32.INSTANCE.GetLastError();
/* 390 */     if (lastError != 234) {
/* 391 */       throw new Win32Exception(lastError);
/*     */     }
/* 393 */     Memory buffer = new Memory(pcbBytesNeeded.getValue());
/* 394 */     boolean result = Advapi32.INSTANCE.EnumDependentServices(this._handle, dwServiceState, (Pointer)buffer, (int)buffer.size(), pcbBytesNeeded, lpServicesReturned);
/* 395 */     if (!result) {
/* 396 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*     */     }
/* 398 */     if (lpServicesReturned.getValue() == 0) {
/* 399 */       return new Winsvc.ENUM_SERVICE_STATUS[0];
/*     */     }
/* 401 */     Winsvc.ENUM_SERVICE_STATUS status = (Winsvc.ENUM_SERVICE_STATUS)Structure.newInstance(Winsvc.ENUM_SERVICE_STATUS.class, (Pointer)buffer);
/* 402 */     status.read();
/* 403 */     return (Winsvc.ENUM_SERVICE_STATUS[])status.toArray(lpServicesReturned.getValue());
/*     */   }
/*     */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\com\sun\jna\platform\win32\W32Service.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */