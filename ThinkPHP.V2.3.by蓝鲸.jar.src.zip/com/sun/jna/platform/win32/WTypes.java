/*     */ package com.sun.jna.platform.win32;
/*     */ 
/*     */ import com.sun.jna.Memory;
/*     */ import com.sun.jna.Native;
/*     */ import com.sun.jna.Pointer;
/*     */ import com.sun.jna.PointerType;
/*     */ import com.sun.jna.Structure;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface WTypes
/*     */ {
/*     */   public static final int CLSCTX_INPROC_SERVER = 1;
/*     */   public static final int CLSCTX_INPROC_HANDLER = 2;
/*     */   public static final int CLSCTX_LOCAL_SERVER = 4;
/*     */   public static final int CLSCTX_INPROC_SERVER16 = 8;
/*     */   public static final int CLSCTX_REMOTE_SERVER = 16;
/*     */   public static final int CLSCTX_INPROC_HANDLER16 = 32;
/*     */   public static final int CLSCTX_RESERVED1 = 64;
/*     */   public static final int CLSCTX_RESERVED2 = 128;
/*     */   public static final int CLSCTX_RESERVED3 = 256;
/*     */   public static final int CLSCTX_RESERVED4 = 512;
/*     */   public static final int CLSCTX_NO_CODE_DOWNLOAD = 1024;
/*     */   public static final int CLSCTX_RESERVED5 = 2048;
/*     */   public static final int CLSCTX_NO_CUSTOM_MARSHAL = 4096;
/*     */   public static final int CLSCTX_ENABLE_CODE_DOWNLOAD = 8192;
/*     */   public static final int CLSCTX_NO_FAILURE_LOG = 16384;
/*     */   public static final int CLSCTX_DISABLE_AAA = 32768;
/*     */   public static final int CLSCTX_ENABLE_AAA = 65536;
/*     */   public static final int CLSCTX_FROM_DEFAULT_CONTEXT = 131072;
/*     */   public static final int CLSCTX_ACTIVATE_32_BIT_SERVER = 262144;
/*     */   public static final int CLSCTX_ACTIVATE_64_BIT_SERVER = 524288;
/*     */   public static final int CLSCTX_ENABLE_CLOAKING = 1048576;
/*     */   public static final int CLSCTX_APPCONTAINER = 4194304;
/*     */   public static final int CLSCTX_ACTIVATE_AAA_AS_IU = 8388608;
/*     */   public static final int CLSCTX_PS_DLL = -2147483648;
/*     */   public static final int CLSCTX_SERVER = 21;
/*     */   public static final int CLSCTX_ALL = 7;
/*     */   
/*     */   public static class BSTR
/*     */     extends PointerType
/*     */   {
/*     */     public BSTR() {
/* 105 */       super(Pointer.NULL);
/*     */     }
/*     */     
/*     */     public BSTR(Pointer pointer) {
/* 109 */       super(pointer);
/*     */     }
/*     */ 
/*     */     
/*     */     public BSTR(String value) {
/* 114 */       setValue(value);
/*     */     }
/*     */     
/*     */     public void setValue(String value) {
/* 118 */       if (value == null) {
/* 119 */         value = "";
/*     */       }
/*     */       try {
/* 122 */         byte[] encodedValue = value.getBytes("UTF-16LE");
/*     */ 
/*     */         
/* 125 */         Memory mem = new Memory((4 + encodedValue.length + 2));
/* 126 */         mem.clear();
/* 127 */         mem.setInt(0L, encodedValue.length);
/* 128 */         mem.write(4L, encodedValue, 0, encodedValue.length);
/* 129 */         setPointer(mem.share(4L));
/* 130 */       } catch (UnsupportedEncodingException ex) {
/* 131 */         throw new RuntimeException("UTF-16LE charset is not supported", ex);
/*     */       } 
/*     */     }
/*     */     
/*     */     public String getValue() {
/*     */       try {
/* 137 */         Pointer pointer = getPointer();
/* 138 */         if (pointer == null) {
/* 139 */           return "";
/*     */         }
/* 141 */         int stringLength = pointer.getInt(-4L);
/* 142 */         return new String(pointer.getByteArray(0L, stringLength), "UTF-16LE");
/* 143 */       } catch (UnsupportedEncodingException ex) {
/* 144 */         throw new RuntimeException("UTF-16LE charset is not supported", ex);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 150 */       return getValue();
/*     */     }
/*     */   }
/*     */   
/*     */   public static class BSTRByReference extends com.sun.jna.ptr.ByReference {
/*     */     public BSTRByReference() {
/* 156 */       super(Native.POINTER_SIZE);
/*     */     }
/*     */     
/*     */     public BSTRByReference(WTypes.BSTR value) {
/* 160 */       this();
/* 161 */       setValue(value);
/*     */     }
/*     */     
/*     */     public void setValue(WTypes.BSTR value) {
/* 165 */       getPointer().setPointer(0L, value.getPointer());
/*     */     }
/*     */     
/*     */     public WTypes.BSTR getValue() {
/* 169 */       return new WTypes.BSTR(getPointer().getPointer(0L));
/*     */     }
/*     */     
/*     */     public String getString() {
/* 173 */       return getValue().getValue();
/*     */     }
/*     */   }
/*     */   
/*     */   public static class LPSTR
/*     */     extends PointerType {
/*     */     public static class ByReference
/*     */       extends LPSTR implements Structure.ByReference {}
/*     */     
/*     */     public LPSTR() {
/* 183 */       super(Pointer.NULL);
/*     */     }
/*     */     
/*     */     public LPSTR(Pointer pointer) {
/* 187 */       super(pointer);
/*     */     }
/*     */     
/*     */     public LPSTR(String value) {
/* 191 */       this((Pointer)new Memory(value.length() + 1L));
/* 192 */       setValue(value);
/*     */     }
/*     */     
/*     */     public void setValue(String value) {
/* 196 */       getPointer().setString(0L, value);
/*     */     }
/*     */     
/*     */     public String getValue() {
/* 200 */       Pointer pointer = getPointer();
/* 201 */       String str = null;
/* 202 */       if (pointer != null) {
/* 203 */         str = pointer.getString(0L);
/*     */       }
/* 205 */       return str;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 210 */       return getValue();
/*     */     }
/*     */   }
/*     */   
/*     */   public static class LPWSTR
/*     */     extends PointerType {
/*     */     public static class ByReference
/*     */       extends LPWSTR implements Structure.ByReference {}
/*     */     
/*     */     public LPWSTR() {
/* 220 */       super(Pointer.NULL);
/*     */     }
/*     */     
/*     */     public LPWSTR(Pointer pointer) {
/* 224 */       super(pointer);
/*     */     }
/*     */     
/*     */     public LPWSTR(String value) {
/* 228 */       this((Pointer)new Memory((value.length() + 1L) * Native.WCHAR_SIZE));
/* 229 */       setValue(value);
/*     */     }
/*     */     
/*     */     public void setValue(String value) {
/* 233 */       getPointer().setWideString(0L, value);
/*     */     }
/*     */     
/*     */     public String getValue() {
/* 237 */       Pointer pointer = getPointer();
/* 238 */       String str = null;
/* 239 */       if (pointer != null) {
/* 240 */         str = pointer.getWideString(0L);
/*     */       }
/* 242 */       return str;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 247 */       return getValue();
/*     */     }
/*     */   }
/*     */   
/*     */   public static class LPOLESTR
/*     */     extends PointerType {
/*     */     public static class ByReference
/*     */       extends LPOLESTR implements Structure.ByReference {}
/*     */     
/*     */     public LPOLESTR() {
/* 257 */       super(Pointer.NULL);
/*     */     }
/*     */     
/*     */     public LPOLESTR(Pointer pointer) {
/* 261 */       super(pointer);
/*     */     }
/*     */     
/*     */     public LPOLESTR(String value) {
/* 265 */       super((Pointer)new Memory((value.length() + 1L) * Native.WCHAR_SIZE));
/* 266 */       setValue(value);
/*     */     }
/*     */     
/*     */     public void setValue(String value) {
/* 270 */       getPointer().setWideString(0L, value);
/*     */     }
/*     */     
/*     */     public String getValue() {
/* 274 */       Pointer pointer = getPointer();
/* 275 */       String str = null;
/* 276 */       if (pointer != null) {
/* 277 */         str = pointer.getWideString(0L);
/*     */       }
/* 279 */       return str;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 284 */       return getValue();
/*     */     }
/*     */   }
/*     */   
/*     */   public static class VARTYPE extends WinDef.USHORT {
/*     */     private static final long serialVersionUID = 1L;
/*     */     
/*     */     public VARTYPE() {
/* 292 */       this(0);
/*     */     }
/*     */     
/*     */     public VARTYPE(int value) {
/* 296 */       super(value);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class VARTYPEByReference extends com.sun.jna.ptr.ByReference {
/*     */     public VARTYPEByReference() {
/* 302 */       super(2);
/*     */     }
/*     */     
/*     */     public VARTYPEByReference(WTypes.VARTYPE type) {
/* 306 */       super(2);
/* 307 */       setValue(type);
/*     */     }
/*     */     
/*     */     public VARTYPEByReference(short type) {
/* 311 */       super(2);
/* 312 */       getPointer().setShort(0L, type);
/*     */     }
/*     */     
/*     */     public void setValue(WTypes.VARTYPE value) {
/* 316 */       getPointer().setShort(0L, value.shortValue());
/*     */     }
/*     */     
/*     */     public WTypes.VARTYPE getValue() {
/* 320 */       return new WTypes.VARTYPE(getPointer().getShort(0L));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\com\sun\jna\platform\win32\WTypes.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */