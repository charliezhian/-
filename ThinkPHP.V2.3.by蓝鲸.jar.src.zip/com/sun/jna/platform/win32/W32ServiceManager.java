/*     */ package com.sun.jna.platform.win32;
/*     */ 
/*     */ import com.sun.jna.Memory;
/*     */ import com.sun.jna.Pointer;
/*     */ import com.sun.jna.Structure;
/*     */ import com.sun.jna.ptr.IntByReference;
/*     */ import java.io.Closeable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class W32ServiceManager
/*     */   implements Closeable
/*     */ {
/*  40 */   Winsvc.SC_HANDLE _handle = null;
/*  41 */   String _machineName = null;
/*  42 */   String _databaseName = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public W32ServiceManager() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public W32ServiceManager(int permissions) {
/*  63 */     open(permissions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public W32ServiceManager(String machineName, String databaseName) {
/*  82 */     this._machineName = machineName;
/*  83 */     this._databaseName = databaseName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public W32ServiceManager(String machineName, String databaseName, int permissions) {
/* 104 */     this._machineName = machineName;
/* 105 */     this._databaseName = databaseName;
/* 106 */     open(permissions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void open(int permissions) {
/* 115 */     close();
/*     */     
/* 117 */     this._handle = Advapi32.INSTANCE.OpenSCManager(this._machineName, this._databaseName, permissions);
/*     */ 
/*     */     
/* 120 */     if (this._handle == null) {
/* 121 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/* 130 */     if (this._handle != null) {
/* 131 */       if (!Advapi32.INSTANCE.CloseServiceHandle(this._handle)) {
/* 132 */         throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*     */       }
/* 134 */       this._handle = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public W32Service openService(String serviceName, int permissions) {
/* 148 */     Winsvc.SC_HANDLE serviceHandle = Advapi32.INSTANCE.OpenService(this._handle, serviceName, permissions);
/*     */ 
/*     */     
/* 151 */     if (serviceHandle == null) {
/* 152 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*     */     }
/*     */     
/* 155 */     return new W32Service(serviceHandle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Winsvc.SC_HANDLE getHandle() {
/* 164 */     return this._handle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Winsvc.ENUM_SERVICE_STATUS_PROCESS[] enumServicesStatusExProcess(int dwServiceType, int dwServiceState, String groupName) {
/* 213 */     IntByReference pcbBytesNeeded = new IntByReference(0);
/* 214 */     IntByReference lpServicesReturned = new IntByReference(0);
/* 215 */     IntByReference lpResumeHandle = new IntByReference(0);
/* 216 */     Advapi32.INSTANCE.EnumServicesStatusEx(this._handle, 0, dwServiceType, dwServiceState, Pointer.NULL, 0, pcbBytesNeeded, lpServicesReturned, lpResumeHandle, groupName);
/* 217 */     int lastError = Kernel32.INSTANCE.GetLastError();
/* 218 */     if (lastError != 234) {
/* 219 */       throw new Win32Exception(lastError);
/*     */     }
/* 221 */     Memory buffer = new Memory(pcbBytesNeeded.getValue());
/* 222 */     boolean result = Advapi32.INSTANCE.EnumServicesStatusEx(this._handle, 0, dwServiceType, dwServiceState, (Pointer)buffer, (int)buffer.size(), pcbBytesNeeded, lpServicesReturned, lpResumeHandle, groupName);
/* 223 */     if (!result) {
/* 224 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*     */     }
/* 226 */     if (lpServicesReturned.getValue() == 0) {
/* 227 */       return new Winsvc.ENUM_SERVICE_STATUS_PROCESS[0];
/*     */     }
/* 229 */     Winsvc.ENUM_SERVICE_STATUS_PROCESS status = (Winsvc.ENUM_SERVICE_STATUS_PROCESS)Structure.newInstance(Winsvc.ENUM_SERVICE_STATUS_PROCESS.class, (Pointer)buffer);
/* 230 */     status.read();
/* 231 */     return (Winsvc.ENUM_SERVICE_STATUS_PROCESS[])status.toArray(lpServicesReturned.getValue());
/*     */   }
/*     */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\com\sun\jna\platform\win32\W32ServiceManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */