/*      */ package com.sun.jna;
/*      */ 
/*      */ import java.awt.Component;
/*      */ import java.awt.GraphicsEnvironment;
/*      */ import java.awt.HeadlessException;
/*      */ import java.awt.Window;
/*      */ import java.io.File;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.FilenameFilter;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.lang.ref.Reference;
/*      */ import java.lang.ref.WeakReference;
/*      */ import java.lang.reflect.Array;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.InvocationHandler;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.lang.reflect.Proxy;
/*      */ import java.net.URI;
/*      */ import java.net.URISyntaxException;
/*      */ import java.net.URL;
/*      */ import java.net.URLClassLoader;
/*      */ import java.nio.Buffer;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.charset.Charset;
/*      */ import java.nio.charset.IllegalCharsetNameException;
/*      */ import java.nio.charset.UnsupportedCharsetException;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.WeakHashMap;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class Native
/*      */   implements Version
/*      */ {
/*  114 */   private static final Logger LOG = Logger.getLogger(Native.class.getName());
/*      */   
/*  116 */   public static final Charset DEFAULT_CHARSET = Charset.defaultCharset();
/*  117 */   public static final String DEFAULT_ENCODING = DEFAULT_CHARSET.name();
/*  118 */   public static final boolean DEBUG_LOAD = Boolean.getBoolean("jna.debug_load");
/*  119 */   public static final boolean DEBUG_JNA_LOAD = Boolean.getBoolean("jna.debug_load.jna");
/*  120 */   private static final Level DEBUG_JNA_LOAD_LEVEL = DEBUG_JNA_LOAD ? Level.INFO : Level.FINE;
/*      */ 
/*      */   
/*  123 */   static String jnidispatchPath = null;
/*  124 */   private static final Map<Class<?>, Map<String, Object>> typeOptions = Collections.synchronizedMap(new WeakHashMap<Class<?>, Map<String, Object>>());
/*  125 */   private static final Map<Class<?>, Reference<?>> libraries = Collections.synchronizedMap(new WeakHashMap<Class<?>, Reference<?>>()); private static final String _OPTION_ENCLOSING_LIBRARY = "enclosing-library";
/*      */   
/*  127 */   private static final Callback.UncaughtExceptionHandler DEFAULT_HANDLER = new Callback.UncaughtExceptionHandler()
/*      */     {
/*      */       public void uncaughtException(Callback c, Throwable e)
/*      */       {
/*  131 */         Native.LOG.log(Level.WARNING, "JNA: Callback " + c + " threw the following exception", e);
/*      */       }
/*      */     };
/*  134 */   private static Callback.UncaughtExceptionHandler callbackExceptionHandler = DEFAULT_HANDLER;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static boolean isCompatibleVersion(String expectedVersion, String nativeVersion) {
/*  172 */     String[] expectedVersionParts = expectedVersion.split("\\.");
/*  173 */     String[] nativeVersionParts = nativeVersion.split("\\.");
/*  174 */     if (expectedVersionParts.length < 3 || nativeVersionParts.length < 3) {
/*  175 */       return false;
/*      */     }
/*      */     
/*  178 */     int expectedMajor = Integer.parseInt(expectedVersionParts[0]);
/*  179 */     int nativeMajor = Integer.parseInt(nativeVersionParts[0]);
/*  180 */     int expectedMinor = Integer.parseInt(expectedVersionParts[1]);
/*  181 */     int nativeMinor = Integer.parseInt(nativeVersionParts[1]);
/*      */     
/*  183 */     if (expectedMajor != nativeMajor) {
/*  184 */       return false;
/*      */     }
/*      */     
/*  187 */     if (expectedMinor > nativeMinor) {
/*  188 */       return false;
/*      */     }
/*      */     
/*  191 */     return true;
/*      */   }
/*      */   
/*      */   static {
/*  195 */     loadNativeDispatchLibrary();
/*      */     
/*  197 */     if (!isCompatibleVersion("6.0.0", getNativeVersion())) {
/*  198 */       String LS = System.getProperty("line.separator");
/*  199 */       throw new Error(LS + LS + "There is an incompatible JNA native library installed on this system" + LS + "Expected: " + "6.0.0" + LS + "Found:    " + 
/*      */ 
/*      */           
/*  202 */           getNativeVersion() + LS + ((jnidispatchPath != null) ? ("(at " + jnidispatchPath + ")") : 
/*      */           
/*  204 */           System.getProperty("java.library.path")) + "." + LS + "To resolve this issue you may do one of the following:" + LS + " - remove or uninstall the offending library" + LS + " - set the system property jna.nosys=true" + LS + " - set jna.boot.library.path to include the path to the version of the " + LS + "   jnidispatch library included with the JNA jar file you are using" + LS);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  213 */   public static final int POINTER_SIZE = sizeof(0);
/*  214 */   public static final int LONG_SIZE = sizeof(1);
/*  215 */   public static final int WCHAR_SIZE = sizeof(2);
/*  216 */   public static final int SIZE_T_SIZE = sizeof(3);
/*  217 */   public static final int BOOL_SIZE = sizeof(4);
/*  218 */   public static final int LONG_DOUBLE_SIZE = sizeof(5); private static final int TYPE_VOIDP = 0; private static final int TYPE_LONG = 1; private static final int TYPE_WCHAR_T = 2; private static final int TYPE_SIZE_T = 3; private static final int TYPE_BOOL = 4;
/*      */   private static final int TYPE_LONG_DOUBLE = 5;
/*      */   
/*      */   static {
/*  222 */     initIDs();
/*  223 */     if (Boolean.getBoolean("jna.protected"))
/*  224 */       setProtected(true); 
/*      */   }
/*  226 */   static final int MAX_ALIGNMENT = (Platform.isSPARC() || Platform.isWindows() || (
/*  227 */     Platform.isLinux() && (Platform.isARM() || Platform.isPPC() || Platform.isMIPS())) || 
/*  228 */     Platform.isAIX() || 
/*  229 */     Platform.isAndroid()) ? 8 : LONG_SIZE;
/*      */   
/*  231 */   static final int MAX_PADDING = (Platform.isMac() && Platform.isPPC()) ? 8 : MAX_ALIGNMENT; static {
/*  232 */     System.setProperty("jna.loaded", "true");
/*      */   }
/*      */ 
/*      */   
/*  236 */   private static final Object finalizer = new Object()
/*      */     {
/*      */       protected void finalize() throws Throwable {
/*  239 */         Native.dispose();
/*  240 */         super.finalize();
/*      */       }
/*      */     };
/*      */ 
/*      */   
/*      */   static final String JNA_TMPLIB_PREFIX = "jna";
/*      */ 
/*      */   
/*      */   private static void dispose() {
/*  249 */     CallbackReference.disposeAll();
/*  250 */     Memory.disposeAll();
/*  251 */     NativeLibrary.disposeAll();
/*  252 */     unregisterAll();
/*  253 */     jnidispatchPath = null;
/*  254 */     System.setProperty("jna.loaded", "false");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static boolean deleteLibrary(File lib) {
/*  269 */     if (lib.delete()) {
/*  270 */       return true;
/*      */     }
/*      */ 
/*      */     
/*  274 */     markTemporaryFile(lib);
/*      */     
/*  276 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long getWindowID(Window w) throws HeadlessException {
/*  316 */     return AWT.getWindowID(w);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long getComponentID(Component c) throws HeadlessException {
/*  326 */     return AWT.getComponentID(c);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer getWindowPointer(Window w) throws HeadlessException {
/*  336 */     return new Pointer(AWT.getWindowID(w));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer getComponentPointer(Component c) throws HeadlessException {
/*  346 */     return new Pointer(AWT.getComponentID(c));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer getDirectBufferPointer(Buffer b) {
/*  355 */     long peer = _getDirectBufferPointer(b);
/*  356 */     return (peer == 0L) ? null : new Pointer(peer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Charset getCharset(String encoding) {
/*  369 */     Charset charset = null;
/*  370 */     if (encoding != null) {
/*      */       try {
/*  372 */         charset = Charset.forName(encoding);
/*      */       }
/*  374 */       catch (IllegalCharsetNameException e) {
/*  375 */         LOG.log(Level.WARNING, "JNA Warning: Encoding ''{0}'' is unsupported ({1})", new Object[] { encoding, e
/*  376 */               .getMessage() });
/*      */       }
/*  378 */       catch (UnsupportedCharsetException e) {
/*  379 */         LOG.log(Level.WARNING, "JNA Warning: Encoding ''{0}'' is unsupported ({1})", new Object[] { encoding, e
/*  380 */               .getMessage() });
/*      */       } 
/*      */     }
/*  383 */     if (charset == null) {
/*  384 */       LOG.log(Level.WARNING, "JNA Warning: Using fallback encoding {0}", DEFAULT_CHARSET);
/*  385 */       charset = DEFAULT_CHARSET;
/*      */     } 
/*  387 */     return charset;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toString(byte[] buf) {
/*  399 */     return toString(buf, getDefaultStringEncoding());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toString(byte[] buf, String encoding) {
/*  416 */     return toString(buf, getCharset(encoding));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toString(byte[] buf, Charset charset) {
/*  432 */     int len = buf.length;
/*      */     
/*  434 */     for (int index = 0; index < len; index++) {
/*  435 */       if (buf[index] == 0) {
/*  436 */         len = index;
/*      */         
/*      */         break;
/*      */       } 
/*      */     } 
/*  441 */     if (len == 0) {
/*  442 */       return "";
/*      */     }
/*      */     
/*  445 */     return new String(buf, 0, len, charset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toString(char[] buf) {
/*  455 */     int len = buf.length;
/*  456 */     for (int index = 0; index < len; index++) {
/*  457 */       if (buf[index] == '\000') {
/*  458 */         len = index;
/*      */         
/*      */         break;
/*      */       } 
/*      */     } 
/*  463 */     if (len == 0) {
/*  464 */       return "";
/*      */     }
/*  466 */     return new String(buf, 0, len);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<String> toStringList(char[] buf) {
/*  480 */     return toStringList(buf, 0, buf.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<String> toStringList(char[] buf, int offset, int len) {
/*  494 */     List<String> list = new ArrayList<String>();
/*  495 */     int lastPos = offset;
/*  496 */     int maxPos = offset + len;
/*  497 */     for (int curPos = offset; curPos < maxPos; curPos++) {
/*  498 */       if (buf[curPos] == '\000') {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  503 */         if (lastPos == curPos) {
/*  504 */           return list;
/*      */         }
/*      */         
/*  507 */         String value = new String(buf, lastPos, curPos - lastPos);
/*  508 */         list.add(value);
/*  509 */         lastPos = curPos + 1;
/*      */       } 
/*      */     } 
/*      */     
/*  513 */     if (lastPos < maxPos) {
/*  514 */       String value = new String(buf, lastPos, maxPos - lastPos);
/*  515 */       list.add(value);
/*      */     } 
/*      */     
/*  518 */     return list;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Library> T load(Class<T> interfaceClass) {
/*  533 */     return load((String)null, interfaceClass);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Library> T load(Class<T> interfaceClass, Map<String, ?> options) {
/*  552 */     return load(null, interfaceClass, options);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Library> T load(String name, Class<T> interfaceClass) {
/*  570 */     return load(name, interfaceClass, Collections.emptyMap());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Library> T load(String name, Class<T> interfaceClass, Map<String, ?> options) {
/*  590 */     if (!Library.class.isAssignableFrom(interfaceClass))
/*      */     {
/*  592 */       throw new IllegalArgumentException("Interface (" + interfaceClass.getSimpleName() + ") of library=" + name + " does not extend " + Library.class
/*  593 */           .getSimpleName());
/*      */     }
/*      */     
/*  596 */     Library.Handler handler = new Library.Handler(name, interfaceClass, options);
/*  597 */     ClassLoader loader = interfaceClass.getClassLoader();
/*  598 */     Object proxy = Proxy.newProxyInstance(loader, new Class[] { interfaceClass }, handler);
/*  599 */     cacheOptions(interfaceClass, options, proxy);
/*  600 */     return interfaceClass.cast(proxy);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static <T> T loadLibrary(Class<T> interfaceClass) {
/*  610 */     return loadLibrary((String)null, interfaceClass);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static <T> T loadLibrary(Class<T> interfaceClass, Map<String, ?> options) {
/*  620 */     return loadLibrary(null, interfaceClass, options);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static <T> T loadLibrary(String name, Class<T> interfaceClass) {
/*  630 */     return loadLibrary(name, interfaceClass, Collections.emptyMap());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static <T> T loadLibrary(String name, Class<T> interfaceClass, Map<String, ?> options) {
/*  640 */     if (!Library.class.isAssignableFrom(interfaceClass))
/*      */     {
/*  642 */       throw new IllegalArgumentException("Interface (" + interfaceClass.getSimpleName() + ") of library=" + name + " does not extend " + Library.class
/*  643 */           .getSimpleName());
/*      */     }
/*      */     
/*  646 */     Library.Handler handler = new Library.Handler(name, interfaceClass, options);
/*  647 */     ClassLoader loader = interfaceClass.getClassLoader();
/*  648 */     Object proxy = Proxy.newProxyInstance(loader, new Class[] { interfaceClass }, handler);
/*  649 */     cacheOptions(interfaceClass, options, proxy);
/*  650 */     return interfaceClass.cast(proxy);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void loadLibraryInstance(Class<?> cls) {
/*  659 */     if (cls != null && !libraries.containsKey(cls)) {
/*      */       try {
/*  661 */         Field[] fields = cls.getFields();
/*  662 */         for (int i = 0; i < fields.length; i++) {
/*  663 */           Field field = fields[i];
/*  664 */           if (field.getType() == cls && 
/*  665 */             Modifier.isStatic(field.getModifiers())) {
/*      */             
/*  667 */             libraries.put(cls, new WeakReference(field.get((Object)null)));
/*      */             
/*      */             break;
/*      */           } 
/*      */         } 
/*  672 */       } catch (Exception e) {
/*  673 */         throw new IllegalArgumentException("Could not access instance of " + cls + " (" + e + ")");
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Class<?> findEnclosingLibraryClass(Class<?> cls) {
/*  687 */     if (cls == null) {
/*  688 */       return null;
/*      */     }
/*      */ 
/*      */     
/*  692 */     Map<String, ?> libOptions = typeOptions.get(cls);
/*  693 */     if (libOptions != null) {
/*  694 */       Class<?> enclosingClass = (Class)libOptions.get("enclosing-library");
/*  695 */       if (enclosingClass != null) {
/*  696 */         return enclosingClass;
/*      */       }
/*  698 */       return cls;
/*      */     } 
/*  700 */     if (Library.class.isAssignableFrom(cls)) {
/*  701 */       return cls;
/*      */     }
/*  703 */     if (Callback.class.isAssignableFrom(cls)) {
/*  704 */       cls = CallbackReference.findCallbackClass(cls);
/*      */     }
/*  706 */     Class<?> declaring = cls.getDeclaringClass();
/*  707 */     Class<?> fromDeclaring = findEnclosingLibraryClass(declaring);
/*  708 */     if (fromDeclaring != null) {
/*  709 */       return fromDeclaring;
/*      */     }
/*  711 */     return findEnclosingLibraryClass(cls.getSuperclass());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Map<String, Object> getLibraryOptions(Class<?> type) {
/*  730 */     Map<String, Object> libraryOptions = typeOptions.get(type);
/*  731 */     if (libraryOptions != null) {
/*  732 */       return libraryOptions;
/*      */     }
/*      */     
/*  735 */     Class<?> mappingClass = findEnclosingLibraryClass(type);
/*  736 */     if (mappingClass != null) {
/*  737 */       loadLibraryInstance(mappingClass);
/*      */     } else {
/*  739 */       mappingClass = type;
/*      */     } 
/*      */     
/*  742 */     libraryOptions = typeOptions.get(mappingClass);
/*  743 */     if (libraryOptions != null) {
/*  744 */       typeOptions.put(type, libraryOptions);
/*  745 */       return libraryOptions;
/*      */     } 
/*      */     
/*      */     try {
/*  749 */       Field field = mappingClass.getField("OPTIONS");
/*  750 */       field.setAccessible(true);
/*  751 */       libraryOptions = (Map<String, Object>)field.get((Object)null);
/*  752 */       if (libraryOptions == null) {
/*  753 */         throw new IllegalStateException("Null options field");
/*      */       }
/*  755 */     } catch (NoSuchFieldException e) {
/*  756 */       libraryOptions = Collections.emptyMap();
/*  757 */     } catch (Exception e) {
/*  758 */       throw new IllegalArgumentException("OPTIONS must be a public field of type java.util.Map (" + e + "): " + mappingClass);
/*      */     } 
/*      */     
/*  761 */     libraryOptions = new HashMap<String, Object>(libraryOptions);
/*  762 */     if (!libraryOptions.containsKey("type-mapper")) {
/*  763 */       libraryOptions.put("type-mapper", lookupField(mappingClass, "TYPE_MAPPER", TypeMapper.class));
/*      */     }
/*  765 */     if (!libraryOptions.containsKey("structure-alignment")) {
/*  766 */       libraryOptions.put("structure-alignment", lookupField(mappingClass, "STRUCTURE_ALIGNMENT", Integer.class));
/*      */     }
/*  768 */     if (!libraryOptions.containsKey("string-encoding")) {
/*  769 */       libraryOptions.put("string-encoding", lookupField(mappingClass, "STRING_ENCODING", String.class));
/*      */     }
/*  771 */     libraryOptions = cacheOptions(mappingClass, libraryOptions, null);
/*      */     
/*  773 */     if (type != mappingClass) {
/*  774 */       typeOptions.put(type, libraryOptions);
/*      */     }
/*  776 */     return libraryOptions;
/*      */   }
/*      */   
/*      */   private static Object lookupField(Class<?> mappingClass, String fieldName, Class<?> resultClass) {
/*      */     try {
/*  781 */       Field field = mappingClass.getField(fieldName);
/*  782 */       field.setAccessible(true);
/*  783 */       return field.get((Object)null);
/*      */     }
/*  785 */     catch (NoSuchFieldException e) {
/*  786 */       return null;
/*      */     }
/*  788 */     catch (Exception e) {
/*  789 */       throw new IllegalArgumentException(fieldName + " must be a public field of type " + resultClass
/*  790 */           .getName() + " (" + e + "): " + mappingClass);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static TypeMapper getTypeMapper(Class<?> cls) {
/*  799 */     Map<String, ?> options = getLibraryOptions(cls);
/*  800 */     return (TypeMapper)options.get("type-mapper");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getStringEncoding(Class<?> cls) {
/*  810 */     Map<String, ?> options = getLibraryOptions(cls);
/*  811 */     String encoding = (String)options.get("string-encoding");
/*  812 */     return (encoding != null) ? encoding : getDefaultStringEncoding();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getDefaultStringEncoding() {
/*  820 */     return System.getProperty("jna.encoding", DEFAULT_ENCODING);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getStructureAlignment(Class<?> cls) {
/*  829 */     Integer alignment = (Integer)getLibraryOptions(cls).get("structure-alignment");
/*  830 */     return (alignment == null) ? 0 : alignment.intValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static byte[] getBytes(String s) {
/*  839 */     return getBytes(s, getDefaultStringEncoding());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static byte[] getBytes(String s, String encoding) {
/*  851 */     return getBytes(s, getCharset(encoding));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static byte[] getBytes(String s, Charset charset) {
/*  861 */     return s.getBytes(charset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] toByteArray(String s) {
/*  871 */     return toByteArray(s, getDefaultStringEncoding());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] toByteArray(String s, String encoding) {
/*  883 */     return toByteArray(s, getCharset(encoding));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] toByteArray(String s, Charset charset) {
/*  894 */     byte[] bytes = getBytes(s, charset);
/*  895 */     byte[] buf = new byte[bytes.length + 1];
/*  896 */     System.arraycopy(bytes, 0, buf, 0, bytes.length);
/*  897 */     return buf;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] toCharArray(String s) {
/*  905 */     char[] chars = s.toCharArray();
/*  906 */     char[] buf = new char[chars.length + 1];
/*  907 */     System.arraycopy(chars, 0, buf, 0, chars.length);
/*  908 */     return buf;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void loadNativeDispatchLibrary() {
/*  917 */     if (!Boolean.getBoolean("jna.nounpack")) {
/*      */       try {
/*  919 */         removeTemporaryFiles();
/*      */       }
/*  921 */       catch (IOException e) {
/*  922 */         LOG.log(Level.WARNING, "JNA Warning: IOException removing temporary files", e);
/*      */       } 
/*      */     }
/*      */     
/*  926 */     String libName = System.getProperty("jna.boot.library.name", "jnidispatch");
/*  927 */     String bootPath = System.getProperty("jna.boot.library.path");
/*  928 */     if (bootPath != null) {
/*      */       
/*  930 */       StringTokenizer dirs = new StringTokenizer(bootPath, File.pathSeparator);
/*  931 */       while (dirs.hasMoreTokens()) {
/*  932 */         String dir = dirs.nextToken();
/*  933 */         File file = new File(new File(dir), System.mapLibraryName(libName).replace(".dylib", ".jnilib"));
/*  934 */         String path = file.getAbsolutePath();
/*  935 */         LOG.log(DEBUG_JNA_LOAD_LEVEL, "Looking in {0}", path);
/*  936 */         if (file.exists()) {
/*      */           try {
/*  938 */             LOG.log(DEBUG_JNA_LOAD_LEVEL, "Trying {0}", path);
/*  939 */             System.setProperty("jnidispatch.path", path);
/*  940 */             System.load(path);
/*  941 */             jnidispatchPath = path;
/*  942 */             LOG.log(DEBUG_JNA_LOAD_LEVEL, "Found jnidispatch at {0}", path);
/*      */             return;
/*  944 */           } catch (UnsatisfiedLinkError unsatisfiedLinkError) {}
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  950 */         if (Platform.isMac()) {
/*      */           String orig, ext;
/*  952 */           if (path.endsWith("dylib")) {
/*  953 */             orig = "dylib";
/*  954 */             ext = "jnilib";
/*      */           } else {
/*  956 */             orig = "jnilib";
/*  957 */             ext = "dylib";
/*      */           } 
/*  959 */           path = path.substring(0, path.lastIndexOf(orig)) + ext;
/*  960 */           LOG.log(DEBUG_JNA_LOAD_LEVEL, "Looking in {0}", path);
/*  961 */           if ((new File(path)).exists()) {
/*      */             try {
/*  963 */               LOG.log(DEBUG_JNA_LOAD_LEVEL, "Trying {0}", path);
/*  964 */               System.setProperty("jnidispatch.path", path);
/*  965 */               System.load(path);
/*  966 */               jnidispatchPath = path;
/*  967 */               LOG.log(DEBUG_JNA_LOAD_LEVEL, "Found jnidispatch at {0}", path);
/*      */               return;
/*  969 */             } catch (UnsatisfiedLinkError ex) {
/*  970 */               LOG.log(Level.WARNING, "File found at " + path + " but not loadable: " + ex.getMessage(), ex);
/*      */             } 
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*  976 */     String jnaNosys = System.getProperty("jna.nosys", "true");
/*  977 */     if (!Boolean.parseBoolean(jnaNosys) || Platform.isAndroid()) {
/*      */       try {
/*  979 */         LOG.log(DEBUG_JNA_LOAD_LEVEL, "Trying (via loadLibrary) {0}", libName);
/*  980 */         System.loadLibrary(libName);
/*  981 */         LOG.log(DEBUG_JNA_LOAD_LEVEL, "Found jnidispatch on system path");
/*      */         
/*      */         return;
/*  984 */       } catch (UnsatisfiedLinkError unsatisfiedLinkError) {}
/*      */     }
/*      */     
/*  987 */     if (!Boolean.getBoolean("jna.noclasspath")) {
/*  988 */       loadNativeDispatchLibraryFromClasspath();
/*      */     } else {
/*      */       
/*  991 */       throw new UnsatisfiedLinkError("Unable to locate JNA native support library");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void loadNativeDispatchLibraryFromClasspath() {
/*      */     try {
/* 1002 */       String libName = "/com/sun/jna/" + Platform.RESOURCE_PREFIX + "/" + System.mapLibraryName("jnidispatch").replace(".dylib", ".jnilib");
/* 1003 */       File lib = extractFromResourcePath(libName, Native.class.getClassLoader());
/* 1004 */       if (lib == null && 
/* 1005 */         lib == null) {
/* 1006 */         throw new UnsatisfiedLinkError("Could not find JNA native support");
/*      */       }
/*      */ 
/*      */       
/* 1010 */       LOG.log(DEBUG_JNA_LOAD_LEVEL, "Trying {0}", lib.getAbsolutePath());
/* 1011 */       System.setProperty("jnidispatch.path", lib.getAbsolutePath());
/* 1012 */       System.load(lib.getAbsolutePath());
/* 1013 */       jnidispatchPath = lib.getAbsolutePath();
/* 1014 */       LOG.log(DEBUG_JNA_LOAD_LEVEL, "Found jnidispatch at {0}", jnidispatchPath);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1020 */       if (isUnpacked(lib) && 
/* 1021 */         !Boolean.getBoolean("jnidispatch.preserve")) {
/* 1022 */         deleteLibrary(lib);
/*      */       }
/*      */     }
/* 1025 */     catch (IOException e) {
/* 1026 */       throw new UnsatisfiedLinkError(e.getMessage());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   static boolean isUnpacked(File file) {
/* 1032 */     return file.getName().startsWith("jna");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File extractFromResourcePath(String name) throws IOException {
/* 1047 */     return extractFromResourcePath(name, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File extractFromResourcePath(String name, ClassLoader loader) throws IOException {
/* 1065 */     Level DEBUG = (DEBUG_LOAD || (DEBUG_JNA_LOAD && name.contains("jnidispatch"))) ? Level.INFO : Level.FINE;
/* 1066 */     if (loader == null) {
/* 1067 */       loader = Thread.currentThread().getContextClassLoader();
/*      */       
/* 1069 */       if (loader == null) {
/* 1070 */         loader = Native.class.getClassLoader();
/*      */       }
/*      */     } 
/* 1073 */     LOG.log(DEBUG, "Looking in classpath from {0} for {1}", new Object[] { loader, name });
/* 1074 */     String libname = name.startsWith("/") ? name : NativeLibrary.mapSharedLibraryName(name);
/* 1075 */     String resourcePath = name.startsWith("/") ? name : (Platform.RESOURCE_PREFIX + "/" + libname);
/* 1076 */     if (resourcePath.startsWith("/")) {
/* 1077 */       resourcePath = resourcePath.substring(1);
/*      */     }
/* 1079 */     URL url = loader.getResource(resourcePath);
/* 1080 */     if (url == null && resourcePath.startsWith(Platform.RESOURCE_PREFIX))
/*      */     {
/* 1082 */       url = loader.getResource(libname);
/*      */     }
/* 1084 */     if (url == null) {
/* 1085 */       String path = System.getProperty("java.class.path");
/* 1086 */       if (loader instanceof URLClassLoader) {
/* 1087 */         path = Arrays.<URL>asList(((URLClassLoader)loader).getURLs()).toString();
/*      */       }
/* 1089 */       throw new IOException("Native library (" + resourcePath + ") not found in resource path (" + path + ")");
/*      */     } 
/* 1091 */     LOG.log(DEBUG, "Found library resource at {0}", url);
/*      */     
/* 1093 */     File lib = null;
/* 1094 */     if (url.getProtocol().toLowerCase().equals("file")) {
/*      */       try {
/* 1096 */         lib = new File(new URI(url.toString()));
/*      */       }
/* 1098 */       catch (URISyntaxException e) {
/* 1099 */         lib = new File(url.getPath());
/*      */       } 
/* 1101 */       LOG.log(DEBUG, "Looking in {0}", lib.getAbsolutePath());
/* 1102 */       if (!lib.exists()) {
/* 1103 */         throw new IOException("File URL " + url + " could not be properly decoded");
/*      */       }
/*      */     }
/* 1106 */     else if (!Boolean.getBoolean("jna.nounpack")) {
/* 1107 */       InputStream is = loader.getResourceAsStream(resourcePath);
/* 1108 */       if (is == null) {
/* 1109 */         throw new IOException("Can't obtain InputStream for " + resourcePath);
/*      */       }
/*      */       
/* 1112 */       FileOutputStream fos = null;
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/* 1117 */         File dir = getTempDir();
/* 1118 */         lib = File.createTempFile("jna", Platform.isWindows() ? ".dll" : null, dir);
/* 1119 */         if (!Boolean.getBoolean("jnidispatch.preserve")) {
/* 1120 */           lib.deleteOnExit();
/*      */         }
/* 1122 */         LOG.log(DEBUG, "Extracting library to {0}", lib.getAbsolutePath());
/* 1123 */         fos = new FileOutputStream(lib);
/*      */         
/* 1125 */         byte[] buf = new byte[1024]; int count;
/* 1126 */         while ((count = is.read(buf, 0, buf.length)) > 0) {
/* 1127 */           fos.write(buf, 0, count);
/*      */         }
/*      */       }
/* 1130 */       catch (IOException e) {
/* 1131 */         throw new IOException("Failed to create temporary file for " + name + " library: " + e.getMessage());
/*      */       } finally {
/*      */         
/* 1134 */         try { is.close(); } catch (IOException iOException) {}
/* 1135 */         if (fos != null) {
/* 1136 */           try { fos.close(); } catch (IOException iOException) {}
/*      */         }
/*      */       } 
/*      */     } 
/* 1140 */     return lib;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Library synchronizedLibrary(final Library library) {
/* 1183 */     Class<?> cls = library.getClass();
/* 1184 */     if (!Proxy.isProxyClass(cls)) {
/* 1185 */       throw new IllegalArgumentException("Library must be a proxy class");
/*      */     }
/* 1187 */     InvocationHandler ih = Proxy.getInvocationHandler(library);
/* 1188 */     if (!(ih instanceof Library.Handler)) {
/* 1189 */       throw new IllegalArgumentException("Unrecognized proxy handler: " + ih);
/*      */     }
/* 1191 */     final Library.Handler handler = (Library.Handler)ih;
/* 1192 */     InvocationHandler newHandler = new InvocationHandler()
/*      */       {
/*      */         public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/* 1195 */           synchronized (handler.getNativeLibrary()) {
/* 1196 */             return handler.invoke(library, method, args);
/*      */           } 
/*      */         }
/*      */       };
/* 1200 */     return (Library)Proxy.newProxyInstance(cls.getClassLoader(), cls
/* 1201 */         .getInterfaces(), newHandler);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getWebStartLibraryPath(String libName) {
/* 1221 */     if (System.getProperty("javawebstart.version") == null) {
/* 1222 */       return null;
/*      */     }
/*      */     try {
/* 1225 */       ClassLoader cl = Native.class.getClassLoader();
/* 1226 */       Method m = AccessController.<Method>doPrivileged(new PrivilegedAction<Method>()
/*      */           {
/*      */             public Method run() {
/*      */               try {
/* 1230 */                 Method m = ClassLoader.class.getDeclaredMethod("findLibrary", new Class[] { String.class });
/* 1231 */                 m.setAccessible(true);
/* 1232 */                 return m;
/*      */               }
/* 1234 */               catch (Exception e) {
/* 1235 */                 return null;
/*      */               } 
/*      */             }
/*      */           });
/* 1239 */       String libpath = (String)m.invoke(cl, new Object[] { libName });
/* 1240 */       if (libpath != null) {
/* 1241 */         return (new File(libpath)).getParent();
/*      */       }
/* 1243 */       return null;
/*      */     }
/* 1245 */     catch (Exception e) {
/* 1246 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void markTemporaryFile(File file) {
/*      */     try {
/* 1256 */       File marker = new File(file.getParentFile(), file.getName() + ".x");
/* 1257 */       marker.createNewFile();
/*      */     } catch (IOException e) {
/* 1259 */       e.printStackTrace();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static File getTempDir() throws IOException {
/*      */     File jnatmp;
/* 1267 */     String prop = System.getProperty("jna.tmpdir");
/* 1268 */     if (prop != null) {
/* 1269 */       jnatmp = new File(prop);
/* 1270 */       jnatmp.mkdirs();
/*      */     } else {
/*      */       
/* 1273 */       File tmp = new File(System.getProperty("java.io.tmpdir"));
/* 1274 */       if (Platform.isMac()) {
/*      */         
/* 1276 */         jnatmp = new File(System.getProperty("user.home"), "Library/Caches/JNA/temp");
/* 1277 */       } else if (Platform.isLinux() || Platform.isSolaris() || Platform.isAIX() || Platform.isFreeBSD() || Platform.isNetBSD() || Platform.isOpenBSD() || Platform.iskFreeBSD()) {
/*      */         File xdgCacheFile;
/*      */         
/* 1280 */         String xdgCacheEnvironment = System.getenv("XDG_CACHE_HOME");
/*      */         
/* 1282 */         if (xdgCacheEnvironment == null || xdgCacheEnvironment.trim().isEmpty()) {
/* 1283 */           xdgCacheFile = new File(System.getProperty("user.home"), ".cache");
/*      */         } else {
/* 1285 */           xdgCacheFile = new File(xdgCacheEnvironment);
/*      */         } 
/* 1287 */         jnatmp = new File(xdgCacheFile, "JNA/temp");
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 1292 */         jnatmp = new File(tmp, "jna-" + System.getProperty("user.name").hashCode());
/*      */       } 
/*      */       
/* 1295 */       jnatmp.mkdirs();
/* 1296 */       if (!jnatmp.exists() || !jnatmp.canWrite()) {
/* 1297 */         jnatmp = tmp;
/*      */       }
/*      */     } 
/* 1300 */     if (!jnatmp.exists()) {
/* 1301 */       throw new IOException("JNA temporary directory '" + jnatmp + "' does not exist");
/*      */     }
/* 1303 */     if (!jnatmp.canWrite()) {
/* 1304 */       throw new IOException("JNA temporary directory '" + jnatmp + "' is not writable");
/*      */     }
/* 1306 */     return jnatmp;
/*      */   }
/*      */ 
/*      */   
/*      */   static void removeTemporaryFiles() throws IOException {
/* 1311 */     File dir = getTempDir();
/* 1312 */     FilenameFilter filter = new FilenameFilter()
/*      */       {
/*      */         public boolean accept(File dir, String name) {
/* 1315 */           return (name.endsWith(".x") && name.startsWith("jna"));
/*      */         }
/*      */       };
/* 1318 */     File[] files = dir.listFiles(filter);
/* 1319 */     for (int i = 0; files != null && i < files.length; i++) {
/* 1320 */       File marker = files[i];
/* 1321 */       String name = marker.getName();
/* 1322 */       name = name.substring(0, name.length() - 2);
/* 1323 */       File target = new File(marker.getParentFile(), name);
/* 1324 */       if (!target.exists() || target.delete()) {
/* 1325 */         marker.delete();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getNativeSize(Class<?> type, Object value) {
/* 1337 */     if (type.isArray()) {
/* 1338 */       int len = Array.getLength(value);
/* 1339 */       if (len > 0) {
/* 1340 */         Object o = Array.get(value, 0);
/* 1341 */         return len * getNativeSize(type.getComponentType(), o);
/*      */       } 
/*      */       
/* 1344 */       throw new IllegalArgumentException("Arrays of length zero not allowed: " + type);
/*      */     } 
/* 1346 */     if (Structure.class.isAssignableFrom(type) && 
/* 1347 */       !Structure.ByReference.class.isAssignableFrom(type)) {
/* 1348 */       return Structure.size(type, value);
/*      */     }
/*      */     try {
/* 1351 */       return getNativeSize(type);
/*      */     }
/* 1353 */     catch (IllegalArgumentException e) {
/* 1354 */       throw new IllegalArgumentException("The type \"" + type.getName() + "\" is not supported: " + e
/*      */           
/* 1356 */           .getMessage());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getNativeSize(Class<?> cls) {
/* 1369 */     if (NativeMapped.class.isAssignableFrom(cls)) {
/* 1370 */       cls = NativeMappedConverter.getInstance(cls).nativeType();
/*      */     }
/*      */     
/* 1373 */     if (cls == boolean.class || cls == Boolean.class) return 4; 
/* 1374 */     if (cls == byte.class || cls == Byte.class) return 1; 
/* 1375 */     if (cls == short.class || cls == Short.class) return 2; 
/* 1376 */     if (cls == char.class || cls == Character.class) return WCHAR_SIZE; 
/* 1377 */     if (cls == int.class || cls == Integer.class) return 4; 
/* 1378 */     if (cls == long.class || cls == Long.class) return 8; 
/* 1379 */     if (cls == float.class || cls == Float.class) return 4; 
/* 1380 */     if (cls == double.class || cls == Double.class) return 8; 
/* 1381 */     if (Structure.class.isAssignableFrom(cls)) {
/* 1382 */       if (Structure.ByValue.class.isAssignableFrom(cls)) {
/* 1383 */         return Structure.size((Class)cls);
/*      */       }
/* 1385 */       return POINTER_SIZE;
/*      */     } 
/* 1387 */     if (Pointer.class.isAssignableFrom(cls) || (Platform.HAS_BUFFERS && 
/* 1388 */       Buffers.isBuffer(cls)) || Callback.class
/* 1389 */       .isAssignableFrom(cls) || String.class == cls || WString.class == cls)
/*      */     {
/*      */       
/* 1392 */       return POINTER_SIZE;
/*      */     }
/* 1394 */     throw new IllegalArgumentException("Native size for type \"" + cls.getName() + "\" is unknown");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSupportedNativeType(Class<?> cls) {
/* 1403 */     if (Structure.class.isAssignableFrom(cls)) {
/* 1404 */       return true;
/*      */     }
/*      */     try {
/* 1407 */       return (getNativeSize(cls) != 0);
/*      */     }
/* 1409 */     catch (IllegalArgumentException e) {
/* 1410 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setCallbackExceptionHandler(Callback.UncaughtExceptionHandler eh) {
/* 1422 */     callbackExceptionHandler = (eh == null) ? DEFAULT_HANDLER : eh;
/*      */   }
/*      */ 
/*      */   
/*      */   public static Callback.UncaughtExceptionHandler getCallbackExceptionHandler() {
/* 1427 */     return callbackExceptionHandler;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void register(String libName) {
/* 1437 */     register(findDirectMappedClass(getCallingClass()), libName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void register(NativeLibrary lib) {
/* 1447 */     register(findDirectMappedClass(getCallingClass()), lib);
/*      */   }
/*      */ 
/*      */   
/*      */   static Class<?> findDirectMappedClass(Class<?> cls) {
/* 1452 */     Method[] methods = cls.getDeclaredMethods();
/* 1453 */     for (Method m : methods) {
/* 1454 */       if ((m.getModifiers() & 0x100) != 0) {
/* 1455 */         return cls;
/*      */       }
/*      */     } 
/* 1458 */     int idx = cls.getName().lastIndexOf("$");
/* 1459 */     if (idx != -1) {
/* 1460 */       String name = cls.getName().substring(0, idx);
/*      */       try {
/* 1462 */         return findDirectMappedClass(Class.forName(name, true, cls.getClassLoader()));
/* 1463 */       } catch (ClassNotFoundException classNotFoundException) {}
/*      */     } 
/*      */ 
/*      */     
/* 1467 */     throw new IllegalArgumentException("Can't determine class with native methods from the current context (" + cls + ")");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Class<?> getCallingClass() {
/* 1479 */     Class<?>[] context = (new SecurityManager() { public Class<?>[] getClassContext() { return super.getClassContext(); } }).getClassContext();
/* 1480 */     if (context == null) {
/* 1481 */       throw new IllegalStateException("The SecurityManager implementation on this platform is broken; you must explicitly provide the class to register");
/*      */     }
/* 1483 */     if (context.length < 4) {
/* 1484 */       throw new IllegalStateException("This method must be called from the static initializer of a class");
/*      */     }
/* 1486 */     return context[3];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setCallbackThreadInitializer(Callback cb, CallbackThreadInitializer initializer) {
/* 1496 */     CallbackReference.setCallbackThreadInitializer(cb, initializer);
/*      */   }
/*      */   
/* 1499 */   private static final Map<Class<?>, long[]> registeredClasses = (Map)new WeakHashMap<Class<?>, long>();
/* 1500 */   private static final Map<Class<?>, NativeLibrary> registeredLibraries = new WeakHashMap<Class<?>, NativeLibrary>(); static final int CB_HAS_INITIALIZER = 1; private static final int CVT_UNSUPPORTED = -1; private static final int CVT_DEFAULT = 0; private static final int CVT_POINTER = 1; private static final int CVT_STRING = 2; private static final int CVT_STRUCTURE = 3; private static final int CVT_STRUCTURE_BYVAL = 4; private static final int CVT_BUFFER = 5; private static final int CVT_ARRAY_BYTE = 6; private static final int CVT_ARRAY_SHORT = 7; private static final int CVT_ARRAY_CHAR = 8; private static final int CVT_ARRAY_INT = 9; private static final int CVT_ARRAY_LONG = 10; private static final int CVT_ARRAY_FLOAT = 11; private static final int CVT_ARRAY_DOUBLE = 12; private static final int CVT_ARRAY_BOOLEAN = 13; private static final int CVT_BOOLEAN = 14; private static final int CVT_CALLBACK = 15; private static final int CVT_FLOAT = 16; private static final int CVT_NATIVE_MAPPED = 17; private static final int CVT_NATIVE_MAPPED_STRING = 18; private static final int CVT_NATIVE_MAPPED_WSTRING = 19; private static final int CVT_WSTRING = 20; private static final int CVT_INTEGER_TYPE = 21; private static final int CVT_POINTER_TYPE = 22; private static final int CVT_TYPE_MAPPER = 23; private static final int CVT_TYPE_MAPPER_STRING = 24; private static final int CVT_TYPE_MAPPER_WSTRING = 25; private static final int CVT_OBJECT = 26; private static final int CVT_JNIENV = 27; static final int CB_OPTION_DIRECT = 1; static final int CB_OPTION_IN_DLL = 2;
/*      */   
/*      */   private static void unregisterAll() {
/* 1503 */     synchronized (registeredClasses) {
/* 1504 */       for (Map.Entry<Class<?>, long[]> e : registeredClasses.entrySet()) {
/* 1505 */         unregister(e.getKey(), e.getValue());
/*      */       }
/*      */       
/* 1508 */       registeredClasses.clear();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void unregister() {
/* 1517 */     unregister(findDirectMappedClass(getCallingClass()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void unregister(Class<?> cls) {
/* 1525 */     synchronized (registeredClasses) {
/* 1526 */       long[] handles = registeredClasses.get(cls);
/* 1527 */       if (handles != null) {
/* 1528 */         unregister(cls, handles);
/* 1529 */         registeredClasses.remove(cls);
/* 1530 */         registeredLibraries.remove(cls);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean registered(Class<?> cls) {
/* 1540 */     synchronized (registeredClasses) {
/* 1541 */       return registeredClasses.containsKey(cls);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static String getSignature(Class<?> cls) {
/* 1549 */     if (cls.isArray()) {
/* 1550 */       return "[" + getSignature(cls.getComponentType());
/*      */     }
/* 1552 */     if (cls.isPrimitive()) {
/* 1553 */       if (cls == void.class) return "V"; 
/* 1554 */       if (cls == boolean.class) return "Z"; 
/* 1555 */       if (cls == byte.class) return "B"; 
/* 1556 */       if (cls == short.class) return "S"; 
/* 1557 */       if (cls == char.class) return "C"; 
/* 1558 */       if (cls == int.class) return "I"; 
/* 1559 */       if (cls == long.class) return "J"; 
/* 1560 */       if (cls == float.class) return "F"; 
/* 1561 */       if (cls == double.class) return "D"; 
/*      */     } 
/* 1563 */     return "L" + replace(".", "/", cls.getName()) + ";";
/*      */   }
/*      */ 
/*      */   
/*      */   static String replace(String s1, String s2, String str) {
/* 1568 */     StringBuilder buf = new StringBuilder();
/*      */     while (true) {
/* 1570 */       int idx = str.indexOf(s1);
/* 1571 */       if (idx == -1) {
/* 1572 */         buf.append(str);
/*      */         
/*      */         break;
/*      */       } 
/* 1576 */       buf.append(str.substring(0, idx));
/* 1577 */       buf.append(s2);
/* 1578 */       str = str.substring(idx + s1.length());
/*      */     } 
/*      */     
/* 1581 */     return buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int getConversion(Class<?> type, TypeMapper mapper, boolean allowObjects) {
/* 1618 */     if (type == Void.class) type = void.class;
/*      */     
/* 1620 */     if (mapper != null) {
/* 1621 */       FromNativeConverter fromNative = mapper.getFromNativeConverter(type);
/* 1622 */       ToNativeConverter toNative = mapper.getToNativeConverter(type);
/* 1623 */       if (fromNative != null) {
/* 1624 */         Class<?> nativeType = fromNative.nativeType();
/* 1625 */         if (nativeType == String.class) {
/* 1626 */           return 24;
/*      */         }
/* 1628 */         if (nativeType == WString.class) {
/* 1629 */           return 25;
/*      */         }
/* 1631 */         return 23;
/*      */       } 
/* 1633 */       if (toNative != null) {
/* 1634 */         Class<?> nativeType = toNative.nativeType();
/* 1635 */         if (nativeType == String.class) {
/* 1636 */           return 24;
/*      */         }
/* 1638 */         if (nativeType == WString.class) {
/* 1639 */           return 25;
/*      */         }
/* 1641 */         return 23;
/*      */       } 
/*      */     } 
/*      */     
/* 1645 */     if (Pointer.class.isAssignableFrom(type)) {
/* 1646 */       return 1;
/*      */     }
/* 1648 */     if (String.class == type) {
/* 1649 */       return 2;
/*      */     }
/* 1651 */     if (WString.class.isAssignableFrom(type)) {
/* 1652 */       return 20;
/*      */     }
/* 1654 */     if (Platform.HAS_BUFFERS && Buffers.isBuffer(type)) {
/* 1655 */       return 5;
/*      */     }
/* 1657 */     if (Structure.class.isAssignableFrom(type)) {
/* 1658 */       if (Structure.ByValue.class.isAssignableFrom(type)) {
/* 1659 */         return 4;
/*      */       }
/* 1661 */       return 3;
/*      */     } 
/* 1663 */     if (type.isArray()) {
/* 1664 */       switch (type.getName().charAt(1)) { case 'Z':
/* 1665 */           return 13;
/* 1666 */         case 'B': return 6;
/* 1667 */         case 'S': return 7;
/* 1668 */         case 'C': return 8;
/* 1669 */         case 'I': return 9;
/* 1670 */         case 'J': return 10;
/* 1671 */         case 'F': return 11;
/* 1672 */         case 'D': return 12; }
/*      */ 
/*      */     
/*      */     }
/* 1676 */     if (type.isPrimitive()) {
/* 1677 */       return (type == boolean.class) ? 14 : 0;
/*      */     }
/* 1679 */     if (Callback.class.isAssignableFrom(type)) {
/* 1680 */       return 15;
/*      */     }
/* 1682 */     if (IntegerType.class.isAssignableFrom(type)) {
/* 1683 */       return 21;
/*      */     }
/* 1685 */     if (PointerType.class.isAssignableFrom(type)) {
/* 1686 */       return 22;
/*      */     }
/* 1688 */     if (NativeMapped.class.isAssignableFrom(type)) {
/* 1689 */       Class<?> nativeType = NativeMappedConverter.getInstance(type).nativeType();
/* 1690 */       if (nativeType == String.class) {
/* 1691 */         return 18;
/*      */       }
/* 1693 */       if (nativeType == WString.class) {
/* 1694 */         return 19;
/*      */       }
/* 1696 */       return 17;
/*      */     } 
/* 1698 */     if (JNIEnv.class == type) {
/* 1699 */       return 27;
/*      */     }
/* 1701 */     return allowObjects ? 26 : -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void register(Class<?> cls, String libName) {
/* 1716 */     NativeLibrary library = NativeLibrary.getInstance(libName, Collections.singletonMap("classloader", cls.getClassLoader()));
/* 1717 */     register(cls, library);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void register(Class<?> cls, NativeLibrary lib) {
/* 1730 */     Method[] methods = cls.getDeclaredMethods();
/* 1731 */     List<Method> mlist = new ArrayList<Method>();
/* 1732 */     Map<String, ?> options = lib.getOptions();
/* 1733 */     TypeMapper mapper = (TypeMapper)options.get("type-mapper");
/* 1734 */     boolean allowObjects = Boolean.TRUE.equals(options.get("allow-objects"));
/* 1735 */     options = cacheOptions(cls, options, null);
/*      */     
/* 1737 */     for (Method m : methods) {
/* 1738 */       if ((m.getModifiers() & 0x100) != 0) {
/* 1739 */         mlist.add(m);
/*      */       }
/*      */     } 
/*      */     
/* 1743 */     long[] handles = new long[mlist.size()];
/* 1744 */     for (int i = 0; i < handles.length; i++) {
/* 1745 */       long rtype, closure_rtype; Method method = mlist.get(i);
/* 1746 */       String sig = "(";
/* 1747 */       Class<?> rclass = method.getReturnType();
/*      */       
/* 1749 */       Class<?>[] ptypes = method.getParameterTypes();
/* 1750 */       long[] atypes = new long[ptypes.length];
/* 1751 */       long[] closure_atypes = new long[ptypes.length];
/* 1752 */       int[] cvt = new int[ptypes.length];
/* 1753 */       ToNativeConverter[] toNative = new ToNativeConverter[ptypes.length];
/* 1754 */       FromNativeConverter fromNative = null;
/* 1755 */       int rcvt = getConversion(rclass, mapper, allowObjects);
/* 1756 */       boolean throwLastError = false;
/* 1757 */       switch (rcvt) {
/*      */         case -1:
/* 1759 */           throw new IllegalArgumentException(rclass + " is not a supported return type (in method " + method.getName() + " in " + cls + ")");
/*      */         case 23:
/*      */         case 24:
/*      */         case 25:
/* 1763 */           fromNative = mapper.getFromNativeConverter(rclass);
/*      */ 
/*      */ 
/*      */           
/* 1767 */           closure_rtype = (Structure.FFIType.get(rclass.isPrimitive() ? rclass : Pointer.class)).peer;
/* 1768 */           rtype = (Structure.FFIType.get(fromNative.nativeType())).peer;
/*      */           break;
/*      */         case 17:
/*      */         case 18:
/*      */         case 19:
/*      */         case 21:
/*      */         case 22:
/* 1775 */           closure_rtype = (Structure.FFIType.get(Pointer.class)).peer;
/* 1776 */           rtype = (Structure.FFIType.get(NativeMappedConverter.getInstance(rclass).nativeType())).peer;
/*      */           break;
/*      */         case 3:
/*      */         case 26:
/* 1780 */           closure_rtype = rtype = (Structure.FFIType.get(Pointer.class)).peer;
/*      */         
/*      */         case 4:
/* 1783 */           closure_rtype = (Structure.FFIType.get(Pointer.class)).peer;
/* 1784 */           rtype = (Structure.FFIType.get(rclass)).peer;
/*      */           break;
/*      */         default:
/* 1787 */           closure_rtype = rtype = (Structure.FFIType.get(rclass)).peer;
/*      */           break;
/*      */       } 
/* 1790 */       for (int t = 0; t < ptypes.length; t++) {
/* 1791 */         Class<?> type = ptypes[t];
/* 1792 */         sig = sig + getSignature(type);
/* 1793 */         int conversionType = getConversion(type, mapper, allowObjects);
/* 1794 */         cvt[t] = conversionType;
/* 1795 */         if (conversionType == -1) {
/* 1796 */           throw new IllegalArgumentException(type + " is not a supported argument type (in method " + method.getName() + " in " + cls + ")");
/*      */         }
/* 1798 */         if (conversionType == 17 || conversionType == 18 || conversionType == 19 || conversionType == 21) {
/*      */ 
/*      */ 
/*      */           
/* 1802 */           type = NativeMappedConverter.getInstance(type).nativeType();
/* 1803 */         } else if (conversionType == 23 || conversionType == 24 || conversionType == 25) {
/*      */ 
/*      */           
/* 1806 */           toNative[t] = mapper.getToNativeConverter(type);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1812 */         switch (conversionType) {
/*      */           case 4:
/*      */           case 17:
/*      */           case 18:
/*      */           case 19:
/*      */           case 21:
/*      */           case 22:
/* 1819 */             atypes[t] = (Structure.FFIType.get(type)).peer;
/* 1820 */             closure_atypes[t] = (Structure.FFIType.get(Pointer.class)).peer;
/*      */             break;
/*      */           case 23:
/*      */           case 24:
/*      */           case 25:
/* 1825 */             closure_atypes[t] = (Structure.FFIType.get(type.isPrimitive() ? type : Pointer.class)).peer;
/* 1826 */             atypes[t] = (Structure.FFIType.get(toNative[t].nativeType())).peer;
/*      */             break;
/*      */           case 0:
/* 1829 */             atypes[t] = (Structure.FFIType.get(type)).peer; closure_atypes[t] = (Structure.FFIType.get(type)).peer;
/*      */           
/*      */           default:
/* 1832 */             atypes[t] = (Structure.FFIType.get(Pointer.class)).peer; closure_atypes[t] = (Structure.FFIType.get(Pointer.class)).peer; break;
/*      */         } 
/*      */       } 
/* 1835 */       sig = sig + ")";
/* 1836 */       sig = sig + getSignature(rclass);
/*      */       
/* 1838 */       Class<?>[] etypes = method.getExceptionTypes();
/* 1839 */       for (int e = 0; e < etypes.length; e++) {
/* 1840 */         if (LastErrorException.class.isAssignableFrom(etypes[e])) {
/* 1841 */           throwLastError = true;
/*      */           
/*      */           break;
/*      */         } 
/*      */       } 
/* 1846 */       Function f = lib.getFunction(method.getName(), method);
/*      */       try {
/* 1848 */         handles[i] = registerMethod(cls, method.getName(), sig, cvt, closure_atypes, atypes, rcvt, closure_rtype, rtype, method, f.peer, f
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1853 */             .getCallingConvention(), throwLastError, toNative, fromNative, f.encoding);
/*      */ 
/*      */       
/*      */       }
/* 1857 */       catch (NoSuchMethodError noSuchMethodError) {
/* 1858 */         throw new UnsatisfiedLinkError("No method " + method.getName() + " with signature " + sig + " in " + cls);
/*      */       } 
/*      */     } 
/* 1861 */     synchronized (registeredClasses) {
/* 1862 */       registeredClasses.put(cls, handles);
/* 1863 */       registeredLibraries.put(cls, lib);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Map<String, Object> cacheOptions(Class<?> cls, Map<String, ?> options, Object proxy) {
/* 1871 */     Map<String, Object> libOptions = new HashMap<String, Object>(options);
/* 1872 */     libOptions.put("enclosing-library", cls);
/* 1873 */     typeOptions.put(cls, libOptions);
/* 1874 */     if (proxy != null) {
/* 1875 */       libraries.put(cls, new WeakReference(proxy));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1881 */     if (!cls.isInterface() && Library.class
/* 1882 */       .isAssignableFrom(cls)) {
/* 1883 */       Class<?>[] ifaces = cls.getInterfaces();
/* 1884 */       for (Class<?> ifc : ifaces) {
/* 1885 */         if (Library.class.isAssignableFrom(ifc)) {
/* 1886 */           cacheOptions(ifc, libOptions, proxy);
/*      */           break;
/*      */         } 
/*      */       } 
/*      */     } 
/* 1891 */     return libOptions;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static NativeMapped fromNative(Class<?> cls, Object value) {
/* 1915 */     return (NativeMapped)NativeMappedConverter.getInstance(cls).fromNative(value, new FromNativeContext(cls));
/*      */   }
/*      */   
/*      */   private static NativeMapped fromNative(Method m, Object value) {
/* 1919 */     Class<?> cls = m.getReturnType();
/* 1920 */     return (NativeMapped)NativeMappedConverter.getInstance(cls).fromNative(value, new MethodResultContext(cls, null, null, m));
/*      */   }
/*      */   
/*      */   private static Class<?> nativeType(Class<?> cls) {
/* 1924 */     return NativeMappedConverter.getInstance(cls).nativeType();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static Object toNative(ToNativeConverter cvt, Object o) {
/* 1930 */     return cvt.toNative(o, new ToNativeContext());
/*      */   }
/*      */   
/*      */   private static Object fromNative(FromNativeConverter cvt, Object o, Method m) {
/* 1934 */     return cvt.fromNative(o, new MethodResultContext(m.getReturnType(), null, null, m));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void main(String[] args) {
/* 1953 */     String DEFAULT_TITLE = "Java Native Access (JNA)";
/* 1954 */     String DEFAULT_VERSION = "5.2.0";
/* 1955 */     String DEFAULT_BUILD = "5.2.0 (package information missing)";
/* 1956 */     Package pkg = Native.class.getPackage();
/*      */     
/* 1958 */     String title = (pkg != null) ? pkg.getSpecificationTitle() : "Java Native Access (JNA)";
/* 1959 */     if (title == null) title = "Java Native Access (JNA)";
/*      */     
/* 1961 */     String version = (pkg != null) ? pkg.getSpecificationVersion() : "5.2.0";
/* 1962 */     if (version == null) version = "5.2.0"; 
/* 1963 */     title = title + " API Version " + version;
/* 1964 */     System.out.println(title);
/*      */     
/* 1966 */     version = (pkg != null) ? pkg.getImplementationVersion() : "5.2.0 (package information missing)";
/* 1967 */     if (version == null) version = "5.2.0 (package information missing)"; 
/* 1968 */     System.out.println("Version: " + version);
/* 1969 */     System.out.println(" Native: " + getNativeVersion() + " (" + 
/* 1970 */         getAPIChecksum() + ")");
/* 1971 */     System.out.println(" Prefix: " + Platform.RESOURCE_PREFIX);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Structure invokeStructure(Function function, long fp, int callFlags, Object[] args, Structure s) {
/* 2096 */     invokeStructure(function, fp, callFlags, args, (s.getPointer()).peer, 
/* 2097 */         (s.getTypeInfo()).peer);
/* 2098 */     return s;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static long open(String name) {
/* 2116 */     return open(name, -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Pointer getPointer(long addr) {
/* 2205 */     long peer = _getPointer(addr);
/* 2206 */     return (peer == 0L) ? null : new Pointer(peer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static String getString(Pointer pointer, long offset) {
/* 2214 */     return getString(pointer, offset, getDefaultStringEncoding());
/*      */   }
/*      */   
/*      */   static String getString(Pointer pointer, long offset, String encoding) {
/* 2218 */     byte[] data = getStringBytes(pointer, pointer.peer, offset);
/* 2219 */     if (encoding != null) {
/*      */       try {
/* 2221 */         return new String(data, encoding);
/*      */       }
/* 2223 */       catch (UnsupportedEncodingException unsupportedEncodingException) {}
/*      */     }
/*      */     
/* 2226 */     return new String(data);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2268 */   private static final ThreadLocal<Memory> nativeThreadTerminationFlag = new ThreadLocal<Memory>()
/*      */     {
/*      */       protected Memory initialValue()
/*      */       {
/* 2272 */         Memory m = new Memory(4L);
/* 2273 */         m.clear();
/* 2274 */         return m;
/*      */       }
/*      */     };
/* 2277 */   private static final Map<Thread, Pointer> nativeThreads = Collections.synchronizedMap(new WeakHashMap<Thread, Pointer>()); private static native void initIDs(); public static synchronized native void setProtected(boolean paramBoolean); public static synchronized native boolean isProtected(); static native long getWindowHandle0(Component paramComponent); private static native long _getDirectBufferPointer(Buffer paramBuffer); private static native int sizeof(int paramInt);
/*      */   private static native String getNativeVersion();
/*      */   private static native String getAPIChecksum();
/*      */   public static native int getLastError();
/*      */   public static native void setLastError(int paramInt);
/*      */   private static native void unregister(Class<?> paramClass, long[] paramArrayOflong);
/*      */   private static native long registerMethod(Class<?> paramClass, String paramString1, String paramString2, int[] paramArrayOfint, long[] paramArrayOflong1, long[] paramArrayOflong2, int paramInt1, long paramLong1, long paramLong2, Method paramMethod, long paramLong3, int paramInt2, boolean paramBoolean, ToNativeConverter[] paramArrayOfToNativeConverter, FromNativeConverter paramFromNativeConverter, String paramString3);
/*      */   public static native long ffi_prep_cif(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*      */   public static native void ffi_call(long paramLong1, long paramLong2, long paramLong3, long paramLong4);
/*      */   public static native long ffi_prep_closure(long paramLong, ffi_callback paramffi_callback);
/*      */   public static native void ffi_free_closure(long paramLong);
/*      */   static native int initialize_ffi_type(long paramLong);
/*      */   static synchronized native void freeNativeCallback(long paramLong);
/*      */   public static void detach(boolean detach) {
/* 2291 */     Thread thread = Thread.currentThread();
/* 2292 */     if (detach) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2299 */       nativeThreads.remove(thread);
/* 2300 */       Pointer p = nativeThreadTerminationFlag.get();
/* 2301 */       setDetachState(true, 0L);
/*      */     
/*      */     }
/* 2304 */     else if (!nativeThreads.containsKey(thread)) {
/* 2305 */       Pointer p = nativeThreadTerminationFlag.get();
/* 2306 */       nativeThreads.put(thread, p);
/* 2307 */       setDetachState(false, p.peer);
/*      */     } 
/*      */   } static synchronized native long createNativeCallback(Callback paramCallback, Method paramMethod, Class<?>[] paramArrayOfClass, Class<?> paramClass, int paramInt1, int paramInt2, String paramString); static native int invokeInt(Function paramFunction, long paramLong, int paramInt, Object[] paramArrayOfObject); static native long invokeLong(Function paramFunction, long paramLong, int paramInt, Object[] paramArrayOfObject); static native void invokeVoid(Function paramFunction, long paramLong, int paramInt, Object[] paramArrayOfObject); static native float invokeFloat(Function paramFunction, long paramLong, int paramInt, Object[] paramArrayOfObject); static native double invokeDouble(Function paramFunction, long paramLong, int paramInt, Object[] paramArrayOfObject); static native long invokePointer(Function paramFunction, long paramLong, int paramInt, Object[] paramArrayOfObject); private static native void invokeStructure(Function paramFunction, long paramLong1, int paramInt, Object[] paramArrayOfObject, long paramLong2, long paramLong3); static native Object invokeObject(Function paramFunction, long paramLong, int paramInt, Object[] paramArrayOfObject); static native long open(String paramString, int paramInt); static native void close(long paramLong); static native long findSymbol(long paramLong, String paramString); static native long indexOf(Pointer paramPointer, long paramLong1, long paramLong2, byte paramByte); static native void read(Pointer paramPointer, long paramLong1, long paramLong2, byte[] paramArrayOfbyte, int paramInt1, int paramInt2); static native void read(Pointer paramPointer, long paramLong1, long paramLong2, short[] paramArrayOfshort, int paramInt1, int paramInt2); static native void read(Pointer paramPointer, long paramLong1, long paramLong2, char[] paramArrayOfchar, int paramInt1, int paramInt2); static native void read(Pointer paramPointer, long paramLong1, long paramLong2, int[] paramArrayOfint, int paramInt1, int paramInt2); static native void read(Pointer paramPointer, long paramLong1, long paramLong2, long[] paramArrayOflong, int paramInt1, int paramInt2); static native void read(Pointer paramPointer, long paramLong1, long paramLong2, float[] paramArrayOffloat, int paramInt1, int paramInt2); static native void read(Pointer paramPointer, long paramLong1, long paramLong2, double[] paramArrayOfdouble, int paramInt1, int paramInt2); static native void write(Pointer paramPointer, long paramLong1, long paramLong2, byte[] paramArrayOfbyte, int paramInt1, int paramInt2); static native void write(Pointer paramPointer, long paramLong1, long paramLong2, short[] paramArrayOfshort, int paramInt1, int paramInt2); static native void write(Pointer paramPointer, long paramLong1, long paramLong2, char[] paramArrayOfchar, int paramInt1, int paramInt2); static native void write(Pointer paramPointer, long paramLong1, long paramLong2, int[] paramArrayOfint, int paramInt1, int paramInt2); static native void write(Pointer paramPointer, long paramLong1, long paramLong2, long[] paramArrayOflong, int paramInt1, int paramInt2); static native void write(Pointer paramPointer, long paramLong1, long paramLong2, float[] paramArrayOffloat, int paramInt1, int paramInt2); static native void write(Pointer paramPointer, long paramLong1, long paramLong2, double[] paramArrayOfdouble, int paramInt1, int paramInt2); static native byte getByte(Pointer paramPointer, long paramLong1, long paramLong2); static native char getChar(Pointer paramPointer, long paramLong1, long paramLong2); static native short getShort(Pointer paramPointer, long paramLong1, long paramLong2); static native int getInt(Pointer paramPointer, long paramLong1, long paramLong2); static native long getLong(Pointer paramPointer, long paramLong1, long paramLong2); static native float getFloat(Pointer paramPointer, long paramLong1, long paramLong2);
/*      */   static native double getDouble(Pointer paramPointer, long paramLong1, long paramLong2);
/*      */   private static native long _getPointer(long paramLong);
/*      */   static Pointer getTerminationFlag(Thread t) {
/* 2313 */     return nativeThreads.get(t);
/*      */   } static native String getWideString(Pointer paramPointer, long paramLong1, long paramLong2); static native byte[] getStringBytes(Pointer paramPointer, long paramLong1, long paramLong2); static native void setMemory(Pointer paramPointer, long paramLong1, long paramLong2, long paramLong3, byte paramByte); static native void setByte(Pointer paramPointer, long paramLong1, long paramLong2, byte paramByte); static native void setShort(Pointer paramPointer, long paramLong1, long paramLong2, short paramShort); static native void setChar(Pointer paramPointer, long paramLong1, long paramLong2, char paramChar); static native void setInt(Pointer paramPointer, long paramLong1, long paramLong2, int paramInt); static native void setLong(Pointer paramPointer, long paramLong1, long paramLong2, long paramLong3); static native void setFloat(Pointer paramPointer, long paramLong1, long paramLong2, float paramFloat); static native void setDouble(Pointer paramPointer, long paramLong1, long paramLong2, double paramDouble); static native void setPointer(Pointer paramPointer, long paramLong1, long paramLong2, long paramLong3); static native void setWideString(Pointer paramPointer, long paramLong1, long paramLong2, String paramString); static native ByteBuffer getDirectByteBuffer(Pointer paramPointer, long paramLong1, long paramLong2, long paramLong3); public static native long malloc(long paramLong);
/*      */   public static native void free(long paramLong);
/*      */   private static native void setDetachState(boolean paramBoolean, long paramLong);
/*      */   public static interface ffi_callback {
/*      */     void invoke(long param1Long1, long param1Long2, long param1Long3); }
/*      */   private static class Buffers { static boolean isBuffer(Class<?> cls) {
/* 2320 */       return Buffer.class.isAssignableFrom(cls);
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class AWT
/*      */   {
/*      */     static long getWindowID(Window w) throws HeadlessException {
/* 2329 */       return getComponentID(w);
/*      */     }
/*      */ 
/*      */     
/*      */     static long getComponentID(Object o) throws HeadlessException {
/* 2334 */       if (GraphicsEnvironment.isHeadless()) {
/* 2335 */         throw new HeadlessException("No native windows when headless");
/*      */       }
/* 2337 */       Component c = (Component)o;
/* 2338 */       if (c.isLightweight()) {
/* 2339 */         throw new IllegalArgumentException("Component must be heavyweight");
/*      */       }
/* 2341 */       if (!c.isDisplayable()) {
/* 2342 */         throw new IllegalStateException("Component must be displayable");
/*      */       }
/* 2344 */       if (Platform.isX11() && 
/* 2345 */         System.getProperty("java.version").startsWith("1.4") && 
/* 2346 */         !c.isVisible()) {
/* 2347 */         throw new IllegalStateException("Component must be visible");
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2353 */       return Native.getWindowHandle0(c);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\com\sun\jna\Native.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */