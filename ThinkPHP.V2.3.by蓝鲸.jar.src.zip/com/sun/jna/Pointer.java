/*      */ package com.sun.jna;
/*      */ 
/*      */ import java.io.PrintWriter;
/*      */ import java.io.StringWriter;
/*      */ import java.lang.reflect.Array;
/*      */ import java.nio.Buffer;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.ByteOrder;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Pointer
/*      */ {
/*   50 */   public static final Pointer NULL = null;
/*      */   protected long peer;
/*      */   
/*      */   public static final Pointer createConstant(long peer) {
/*   54 */     return new Opaque(peer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final Pointer createConstant(int peer) {
/*   62 */     return new Opaque(peer & 0xFFFFFFFFFFFFFFFFL);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Pointer() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer(long peer) {
/*   78 */     this.peer = peer;
/*      */   }
/*      */ 
/*      */   
/*      */   public Pointer share(long offset) {
/*   83 */     return share(offset, 0L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer share(long offset, long sz) {
/*   90 */     if (offset == 0L) {
/*   91 */       return this;
/*      */     }
/*   93 */     return new Pointer(this.peer + offset);
/*      */   }
/*      */ 
/*      */   
/*      */   public void clear(long size) {
/*   98 */     setMemory(0L, size, (byte)0);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean equals(Object o) {
/*  103 */     if (o == this) {
/*  104 */       return true;
/*      */     }
/*  106 */     if (o == null) {
/*  107 */       return false;
/*      */     }
/*  109 */     return (o instanceof Pointer && ((Pointer)o).peer == this.peer);
/*      */   }
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  114 */     return (int)((this.peer >>> 32L) + (this.peer & 0xFFFFFFFFFFFFFFFFL));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long indexOf(long offset, byte value) {
/*  126 */     return Native.indexOf(this, this.peer, offset, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void read(long offset, byte[] buf, int index, int length) {
/*  139 */     Native.read(this, this.peer, offset, buf, index, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void read(long offset, short[] buf, int index, int length) {
/*  152 */     Native.read(this, this.peer, offset, buf, index, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void read(long offset, char[] buf, int index, int length) {
/*  165 */     Native.read(this, this.peer, offset, buf, index, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void read(long offset, int[] buf, int index, int length) {
/*  178 */     Native.read(this, this.peer, offset, buf, index, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void read(long offset, long[] buf, int index, int length) {
/*  191 */     Native.read(this, this.peer, offset, buf, index, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void read(long offset, float[] buf, int index, int length) {
/*  204 */     Native.read(this, this.peer, offset, buf, index, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void read(long offset, double[] buf, int index, int length) {
/*  217 */     Native.read(this, this.peer, offset, buf, index, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void read(long offset, Pointer[] buf, int index, int length) {
/*  230 */     for (int i = 0; i < length; i++) {
/*  231 */       Pointer p = getPointer(offset + (i * Native.POINTER_SIZE));
/*  232 */       Pointer oldp = buf[i + index];
/*      */       
/*  234 */       if (oldp == null || p == null || p.peer != oldp.peer) {
/*  235 */         buf[i + index] = p;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void write(long offset, byte[] buf, int index, int length) {
/*  256 */     Native.write(this, this.peer, offset, buf, index, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void write(long offset, short[] buf, int index, int length) {
/*  270 */     Native.write(this, this.peer, offset, buf, index, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void write(long offset, char[] buf, int index, int length) {
/*  284 */     Native.write(this, this.peer, offset, buf, index, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void write(long offset, int[] buf, int index, int length) {
/*  298 */     Native.write(this, this.peer, offset, buf, index, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void write(long offset, long[] buf, int index, int length) {
/*  312 */     Native.write(this, this.peer, offset, buf, index, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void write(long offset, float[] buf, int index, int length) {
/*  326 */     Native.write(this, this.peer, offset, buf, index, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void write(long offset, double[] buf, int index, int length) {
/*  340 */     Native.write(this, this.peer, offset, buf, index, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void write(long bOff, Pointer[] buf, int index, int length) {
/*  351 */     for (int i = 0; i < length; i++) {
/*  352 */       setPointer(bOff + (i * Native.POINTER_SIZE), buf[index + i]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Object getValue(long offset, Class<?> type, Object currentValue) {
/*  362 */     Object result = null;
/*  363 */     if (Structure.class.isAssignableFrom(type)) {
/*  364 */       Structure s = (Structure)currentValue;
/*  365 */       if (Structure.ByReference.class.isAssignableFrom(type)) {
/*  366 */         s = Structure.updateStructureByReference(type, s, getPointer(offset));
/*      */       } else {
/*  368 */         s.useMemory(this, (int)offset, true);
/*  369 */         s.read();
/*      */       } 
/*  371 */       result = s;
/*  372 */     } else if (type == boolean.class || type == Boolean.class) {
/*  373 */       result = Function.valueOf((getInt(offset) != 0));
/*  374 */     } else if (type == byte.class || type == Byte.class) {
/*  375 */       result = Byte.valueOf(getByte(offset));
/*  376 */     } else if (type == short.class || type == Short.class) {
/*  377 */       result = Short.valueOf(getShort(offset));
/*  378 */     } else if (type == char.class || type == Character.class) {
/*  379 */       result = Character.valueOf(getChar(offset));
/*  380 */     } else if (type == int.class || type == Integer.class) {
/*  381 */       result = Integer.valueOf(getInt(offset));
/*  382 */     } else if (type == long.class || type == Long.class) {
/*  383 */       result = Long.valueOf(getLong(offset));
/*  384 */     } else if (type == float.class || type == Float.class) {
/*  385 */       result = Float.valueOf(getFloat(offset));
/*  386 */     } else if (type == double.class || type == Double.class) {
/*  387 */       result = Double.valueOf(getDouble(offset));
/*  388 */     } else if (Pointer.class.isAssignableFrom(type)) {
/*  389 */       Pointer p = getPointer(offset);
/*  390 */       if (p != null) {
/*  391 */         Pointer oldp = (currentValue instanceof Pointer) ? (Pointer)currentValue : null;
/*      */         
/*  393 */         if (oldp == null || p.peer != oldp.peer) {
/*  394 */           result = p;
/*      */         } else {
/*  396 */           result = oldp;
/*      */         } 
/*      */       } 
/*  399 */     } else if (type == String.class) {
/*  400 */       Pointer p = getPointer(offset);
/*  401 */       result = (p != null) ? p.getString(0L) : null;
/*  402 */     } else if (type == WString.class) {
/*  403 */       Pointer p = getPointer(offset);
/*  404 */       result = (p != null) ? new WString(p.getWideString(0L)) : null;
/*  405 */     } else if (Callback.class.isAssignableFrom(type)) {
/*      */ 
/*      */       
/*  408 */       Pointer fp = getPointer(offset);
/*  409 */       if (fp == null) {
/*  410 */         result = null;
/*      */       } else {
/*  412 */         Callback cb = (Callback)currentValue;
/*  413 */         Pointer oldfp = CallbackReference.getFunctionPointer(cb);
/*  414 */         if (!fp.equals(oldfp)) {
/*  415 */           cb = CallbackReference.getCallback(type, fp);
/*      */         }
/*  417 */         result = cb;
/*      */       } 
/*  419 */     } else if (Platform.HAS_BUFFERS && Buffer.class.isAssignableFrom(type)) {
/*  420 */       Pointer bp = getPointer(offset);
/*  421 */       if (bp == null) {
/*  422 */         result = null;
/*      */       } else {
/*      */         
/*  425 */         Pointer oldbp = (currentValue == null) ? null : Native.getDirectBufferPointer((Buffer)currentValue);
/*  426 */         if (oldbp == null || !oldbp.equals(bp)) {
/*  427 */           throw new IllegalStateException("Can't autogenerate a direct buffer on memory read");
/*      */         }
/*  429 */         result = currentValue;
/*      */       } 
/*  431 */     } else if (NativeMapped.class.isAssignableFrom(type)) {
/*  432 */       NativeMapped nm = (NativeMapped)currentValue;
/*  433 */       if (nm != null) {
/*  434 */         Object value = getValue(offset, nm.nativeType(), null);
/*  435 */         result = nm.fromNative(value, new FromNativeContext(type));
/*  436 */         if (nm.equals(result)) {
/*  437 */           result = nm;
/*      */         }
/*      */       } else {
/*  440 */         NativeMappedConverter tc = NativeMappedConverter.getInstance(type);
/*  441 */         Object value = getValue(offset, tc.nativeType(), null);
/*  442 */         result = tc.fromNative(value, new FromNativeContext(type));
/*      */       } 
/*  444 */     } else if (type.isArray()) {
/*  445 */       result = currentValue;
/*  446 */       if (result == null) {
/*  447 */         throw new IllegalStateException("Need an initialized array");
/*      */       }
/*  449 */       readArray(offset, result, type.getComponentType());
/*      */     } else {
/*  451 */       throw new IllegalArgumentException("Reading \"" + type + "\" from memory is not supported");
/*      */     } 
/*  453 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   private void readArray(long offset, Object o, Class<?> cls) {
/*  458 */     int length = 0;
/*  459 */     length = Array.getLength(o);
/*  460 */     Object result = o;
/*      */     
/*  462 */     if (cls == byte.class) {
/*  463 */       read(offset, (byte[])result, 0, length);
/*      */     }
/*  465 */     else if (cls == short.class) {
/*  466 */       read(offset, (short[])result, 0, length);
/*      */     }
/*  468 */     else if (cls == char.class) {
/*  469 */       read(offset, (char[])result, 0, length);
/*      */     }
/*  471 */     else if (cls == int.class) {
/*  472 */       read(offset, (int[])result, 0, length);
/*      */     }
/*  474 */     else if (cls == long.class) {
/*  475 */       read(offset, (long[])result, 0, length);
/*      */     }
/*  477 */     else if (cls == float.class) {
/*  478 */       read(offset, (float[])result, 0, length);
/*      */     }
/*  480 */     else if (cls == double.class) {
/*  481 */       read(offset, (double[])result, 0, length);
/*      */     }
/*  483 */     else if (Pointer.class.isAssignableFrom(cls)) {
/*  484 */       read(offset, (Pointer[])result, 0, length);
/*      */     }
/*  486 */     else if (Structure.class.isAssignableFrom(cls)) {
/*  487 */       Structure[] sarray = (Structure[])result;
/*  488 */       if (Structure.ByReference.class.isAssignableFrom(cls)) {
/*  489 */         Pointer[] parray = getPointerArray(offset, sarray.length);
/*  490 */         for (int i = 0; i < sarray.length; i++) {
/*  491 */           sarray[i] = Structure.updateStructureByReference(cls, sarray[i], parray[i]);
/*      */         }
/*      */       } else {
/*      */         
/*  495 */         Structure first = sarray[0];
/*  496 */         if (first == null) {
/*  497 */           first = Structure.newInstance(cls, share(offset));
/*  498 */           first.conditionalAutoRead();
/*  499 */           sarray[0] = first;
/*      */         } else {
/*      */           
/*  502 */           first.useMemory(this, (int)offset, true);
/*  503 */           first.read();
/*      */         } 
/*  505 */         Structure[] tmp = first.toArray(sarray.length);
/*  506 */         for (int i = 1; i < sarray.length; i++) {
/*  507 */           if (sarray[i] == null) {
/*      */             
/*  509 */             sarray[i] = tmp[i];
/*      */           } else {
/*      */             
/*  512 */             sarray[i].useMemory(this, (int)(offset + (i * sarray[i].size())), true);
/*  513 */             sarray[i].read();
/*      */           }
/*      */         
/*      */         } 
/*      */       } 
/*  518 */     } else if (NativeMapped.class.isAssignableFrom(cls)) {
/*  519 */       NativeMapped[] array = (NativeMapped[])result;
/*  520 */       NativeMappedConverter tc = NativeMappedConverter.getInstance(cls);
/*  521 */       int size = Native.getNativeSize(result.getClass(), result) / array.length;
/*  522 */       for (int i = 0; i < array.length; i++) {
/*  523 */         Object value = getValue(offset + (size * i), tc.nativeType(), array[i]);
/*  524 */         array[i] = (NativeMapped)tc.fromNative(value, new FromNativeContext(cls));
/*      */       } 
/*      */     } else {
/*      */       
/*  528 */       throw new IllegalArgumentException("Reading array of " + cls + " from memory not supported");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte getByte(long offset) {
/*  543 */     return Native.getByte(this, this.peer, offset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char getChar(long offset) {
/*  555 */     return Native.getChar(this, this.peer, offset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short getShort(long offset) {
/*  567 */     return Native.getShort(this, this.peer, offset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getInt(long offset) {
/*  579 */     return Native.getInt(this, this.peer, offset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLong(long offset) {
/*  591 */     return Native.getLong(this, this.peer, offset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NativeLong getNativeLong(long offset) {
/*  603 */     return new NativeLong((NativeLong.SIZE == 8) ? getLong(offset) : getInt(offset));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFloat(long offset) {
/*  615 */     return Native.getFloat(this, this.peer, offset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDouble(long offset) {
/*  627 */     return Native.getDouble(this, this.peer, offset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer getPointer(long offset) {
/*  641 */     return Native.getPointer(this.peer + offset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ByteBuffer getByteBuffer(long offset, long length) {
/*  653 */     return Native.getDirectByteBuffer(this, this.peer, offset, length).order(ByteOrder.nativeOrder());
/*      */   }
/*      */ 
/*      */   
/*      */   public String getWideString(long offset) {
/*  658 */     return Native.getWideString(this, this.peer, offset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getString(long offset) {
/*  669 */     return getString(offset, Native.getDefaultStringEncoding());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getString(long offset, String encoding) {
/*  680 */     return Native.getString(this, offset, encoding);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getByteArray(long offset, int arraySize) {
/*  687 */     byte[] buf = new byte[arraySize];
/*  688 */     read(offset, buf, 0, arraySize);
/*  689 */     return buf;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char[] getCharArray(long offset, int arraySize) {
/*  696 */     char[] buf = new char[arraySize];
/*  697 */     read(offset, buf, 0, arraySize);
/*  698 */     return buf;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short[] getShortArray(long offset, int arraySize) {
/*  705 */     short[] buf = new short[arraySize];
/*  706 */     read(offset, buf, 0, arraySize);
/*  707 */     return buf;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int[] getIntArray(long offset, int arraySize) {
/*  714 */     int[] buf = new int[arraySize];
/*  715 */     read(offset, buf, 0, arraySize);
/*  716 */     return buf;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long[] getLongArray(long offset, int arraySize) {
/*  723 */     long[] buf = new long[arraySize];
/*  724 */     read(offset, buf, 0, arraySize);
/*  725 */     return buf;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float[] getFloatArray(long offset, int arraySize) {
/*  732 */     float[] buf = new float[arraySize];
/*  733 */     read(offset, buf, 0, arraySize);
/*  734 */     return buf;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double[] getDoubleArray(long offset, int arraySize) {
/*  741 */     double[] buf = new double[arraySize];
/*  742 */     read(offset, buf, 0, arraySize);
/*  743 */     return buf;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer[] getPointerArray(long offset) {
/*  750 */     List<Pointer> array = new ArrayList<Pointer>();
/*  751 */     int addOffset = 0;
/*  752 */     Pointer p = getPointer(offset);
/*  753 */     while (p != null) {
/*  754 */       array.add(p);
/*  755 */       addOffset += Native.POINTER_SIZE;
/*  756 */       p = getPointer(offset + addOffset);
/*      */     } 
/*  758 */     return array.<Pointer>toArray(new Pointer[array.size()]);
/*      */   }
/*      */ 
/*      */   
/*      */   public Pointer[] getPointerArray(long offset, int arraySize) {
/*  763 */     Pointer[] buf = new Pointer[arraySize];
/*  764 */     read(offset, buf, 0, arraySize);
/*  765 */     return buf;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getStringArray(long offset) {
/*  776 */     return getStringArray(offset, -1, Native.getDefaultStringEncoding());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getStringArray(long offset, String encoding) {
/*  784 */     return getStringArray(offset, -1, encoding);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getStringArray(long offset, int length) {
/*  794 */     return getStringArray(offset, length, Native.getDefaultStringEncoding());
/*      */   }
/*      */   
/*      */   public String[] getWideStringArray(long offset) {
/*  798 */     return getWideStringArray(offset, -1);
/*      */   }
/*      */   
/*      */   public String[] getWideStringArray(long offset, int length) {
/*  802 */     return getStringArray(offset, length, "--WIDE-STRING--");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getStringArray(long offset, int length, String encoding) {
/*  813 */     List<String> strings = new ArrayList<String>();
/*      */     
/*  815 */     int addOffset = 0;
/*  816 */     if (length != -1) {
/*  817 */       Pointer p = getPointer(offset + addOffset);
/*  818 */       int count = 0;
/*  819 */       while (count++ < length) {
/*      */ 
/*      */ 
/*      */         
/*  823 */         String s = (p == null) ? null : ("--WIDE-STRING--".equals(encoding) ? p.getWideString(0L) : p.getString(0L, encoding));
/*  824 */         strings.add(s);
/*  825 */         if (count < length) {
/*  826 */           addOffset += Native.POINTER_SIZE;
/*  827 */           p = getPointer(offset + addOffset);
/*      */         } 
/*      */       } 
/*      */     } else {
/*  831 */       Pointer p; while ((p = getPointer(offset + addOffset)) != null) {
/*      */ 
/*      */ 
/*      */         
/*  835 */         String s = (p == null) ? null : ("--WIDE-STRING--".equals(encoding) ? p.getWideString(0L) : p.getString(0L, encoding));
/*  836 */         strings.add(s);
/*  837 */         addOffset += Native.POINTER_SIZE;
/*      */       } 
/*      */     } 
/*  840 */     return strings.<String>toArray(new String[strings.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setValue(long offset, Object value, Class<?> type) {
/*  850 */     if (type == boolean.class || type == Boolean.class) {
/*  851 */       setInt(offset, Boolean.TRUE.equals(value) ? -1 : 0);
/*  852 */     } else if (type == byte.class || type == Byte.class) {
/*  853 */       setByte(offset, (value == null) ? 0 : ((Byte)value).byteValue());
/*  854 */     } else if (type == short.class || type == Short.class) {
/*  855 */       setShort(offset, (value == null) ? 0 : ((Short)value).shortValue());
/*  856 */     } else if (type == char.class || type == Character.class) {
/*  857 */       setChar(offset, (value == null) ? Character.MIN_VALUE : ((Character)value).charValue());
/*  858 */     } else if (type == int.class || type == Integer.class) {
/*  859 */       setInt(offset, (value == null) ? 0 : ((Integer)value).intValue());
/*  860 */     } else if (type == long.class || type == Long.class) {
/*  861 */       setLong(offset, (value == null) ? 0L : ((Long)value).longValue());
/*  862 */     } else if (type == float.class || type == Float.class) {
/*  863 */       setFloat(offset, (value == null) ? 0.0F : ((Float)value).floatValue());
/*  864 */     } else if (type == double.class || type == Double.class) {
/*  865 */       setDouble(offset, (value == null) ? 0.0D : ((Double)value).doubleValue());
/*  866 */     } else if (type == Pointer.class) {
/*  867 */       setPointer(offset, (Pointer)value);
/*  868 */     } else if (type == String.class) {
/*  869 */       setPointer(offset, (Pointer)value);
/*  870 */     } else if (type == WString.class) {
/*  871 */       setPointer(offset, (Pointer)value);
/*  872 */     } else if (Structure.class.isAssignableFrom(type)) {
/*  873 */       Structure s = (Structure)value;
/*  874 */       if (Structure.ByReference.class.isAssignableFrom(type)) {
/*  875 */         setPointer(offset, (s == null) ? null : s.getPointer());
/*  876 */         if (s != null) {
/*  877 */           s.autoWrite();
/*      */         }
/*      */       } else {
/*      */         
/*  881 */         s.useMemory(this, (int)offset, true);
/*  882 */         s.write();
/*      */       } 
/*  884 */     } else if (Callback.class.isAssignableFrom(type)) {
/*  885 */       setPointer(offset, CallbackReference.getFunctionPointer((Callback)value));
/*  886 */     } else if (Platform.HAS_BUFFERS && Buffer.class.isAssignableFrom(type)) {
/*      */       
/*  888 */       Pointer p = (value == null) ? null : Native.getDirectBufferPointer((Buffer)value);
/*  889 */       setPointer(offset, p);
/*  890 */     } else if (NativeMapped.class.isAssignableFrom(type)) {
/*  891 */       NativeMappedConverter tc = NativeMappedConverter.getInstance(type);
/*  892 */       Class<?> nativeType = tc.nativeType();
/*  893 */       setValue(offset, tc.toNative(value, new ToNativeContext()), nativeType);
/*  894 */     } else if (type.isArray()) {
/*  895 */       writeArray(offset, value, type.getComponentType());
/*      */     } else {
/*  897 */       throw new IllegalArgumentException("Writing " + type + " to memory is not supported");
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void writeArray(long offset, Object value, Class<?> cls) {
/*  903 */     if (cls == byte.class) {
/*  904 */       byte[] buf = (byte[])value;
/*  905 */       write(offset, buf, 0, buf.length);
/*  906 */     } else if (cls == short.class) {
/*  907 */       short[] buf = (short[])value;
/*  908 */       write(offset, buf, 0, buf.length);
/*  909 */     } else if (cls == char.class) {
/*  910 */       char[] buf = (char[])value;
/*  911 */       write(offset, buf, 0, buf.length);
/*  912 */     } else if (cls == int.class) {
/*  913 */       int[] buf = (int[])value;
/*  914 */       write(offset, buf, 0, buf.length);
/*  915 */     } else if (cls == long.class) {
/*  916 */       long[] buf = (long[])value;
/*  917 */       write(offset, buf, 0, buf.length);
/*  918 */     } else if (cls == float.class) {
/*  919 */       float[] buf = (float[])value;
/*  920 */       write(offset, buf, 0, buf.length);
/*  921 */     } else if (cls == double.class) {
/*  922 */       double[] buf = (double[])value;
/*  923 */       write(offset, buf, 0, buf.length);
/*  924 */     } else if (Pointer.class.isAssignableFrom(cls)) {
/*  925 */       Pointer[] buf = (Pointer[])value;
/*  926 */       write(offset, buf, 0, buf.length);
/*  927 */     } else if (Structure.class.isAssignableFrom(cls)) {
/*  928 */       Structure[] sbuf = (Structure[])value;
/*  929 */       if (Structure.ByReference.class.isAssignableFrom(cls)) {
/*  930 */         Pointer[] buf = new Pointer[sbuf.length];
/*  931 */         for (int i = 0; i < sbuf.length; i++) {
/*  932 */           if (sbuf[i] == null) {
/*  933 */             buf[i] = null;
/*      */           } else {
/*  935 */             buf[i] = sbuf[i].getPointer();
/*  936 */             sbuf[i].write();
/*      */           } 
/*      */         } 
/*  939 */         write(offset, buf, 0, buf.length);
/*      */       } else {
/*  941 */         Structure first = sbuf[0];
/*  942 */         if (first == null) {
/*  943 */           first = Structure.newInstance(cls, share(offset));
/*  944 */           sbuf[0] = first;
/*      */         } else {
/*  946 */           first.useMemory(this, (int)offset, true);
/*      */         } 
/*  948 */         first.write();
/*  949 */         Structure[] tmp = first.toArray(sbuf.length);
/*  950 */         for (int i = 1; i < sbuf.length; i++) {
/*  951 */           if (sbuf[i] == null) {
/*  952 */             sbuf[i] = tmp[i];
/*      */           } else {
/*  954 */             sbuf[i].useMemory(this, (int)(offset + (i * sbuf[i].size())), true);
/*      */           } 
/*  956 */           sbuf[i].write();
/*      */         } 
/*      */       } 
/*  959 */     } else if (NativeMapped.class.isAssignableFrom(cls)) {
/*  960 */       NativeMapped[] buf = (NativeMapped[])value;
/*  961 */       NativeMappedConverter tc = NativeMappedConverter.getInstance(cls);
/*  962 */       Class<?> nativeType = tc.nativeType();
/*  963 */       int size = Native.getNativeSize(value.getClass(), value) / buf.length;
/*  964 */       for (int i = 0; i < buf.length; i++) {
/*  965 */         Object element = tc.toNative(buf[i], new ToNativeContext());
/*  966 */         setValue(offset + (i * size), element, nativeType);
/*      */       } 
/*      */     } else {
/*  969 */       throw new IllegalArgumentException("Writing array of " + cls + " to memory not supported");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMemory(long offset, long length, byte value) {
/*  980 */     Native.setMemory(this, this.peer, offset, length, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setByte(long offset, byte value) {
/*  993 */     Native.setByte(this, this.peer, offset, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setShort(long offset, short value) {
/* 1006 */     Native.setShort(this, this.peer, offset, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setChar(long offset, char value) {
/* 1019 */     Native.setChar(this, this.peer, offset, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInt(long offset, int value) {
/* 1032 */     Native.setInt(this, this.peer, offset, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLong(long offset, long value) {
/* 1045 */     Native.setLong(this, this.peer, offset, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNativeLong(long offset, NativeLong value) {
/* 1058 */     if (NativeLong.SIZE == 8) {
/* 1059 */       setLong(offset, value.longValue());
/*      */     } else {
/* 1061 */       setInt(offset, value.intValue());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFloat(long offset, float value) {
/* 1075 */     Native.setFloat(this, this.peer, offset, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDouble(long offset, double value) {
/* 1088 */     Native.setDouble(this, this.peer, offset, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPointer(long offset, Pointer value) {
/* 1103 */     Native.setPointer(this, this.peer, offset, (value != null) ? value.peer : 0L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setWideString(long offset, String value) {
/* 1115 */     Native.setWideString(this, this.peer, offset, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setString(long offset, WString value) {
/* 1127 */     setWideString(offset, (value == null) ? null : value.toString());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setString(long offset, String value) {
/* 1140 */     setString(offset, value, Native.getDefaultStringEncoding());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setString(long offset, String value, String encoding) {
/* 1153 */     byte[] data = Native.getBytes(value, encoding);
/* 1154 */     write(offset, data, 0, data.length);
/* 1155 */     setByte(offset + data.length, (byte)0);
/*      */   }
/*      */ 
/*      */   
/*      */   public String dump(long offset, int size) {
/* 1160 */     int BYTES_PER_ROW = 4;
/* 1161 */     String TITLE = "memory dump";
/*      */     
/* 1163 */     StringWriter sw = new StringWriter("memory dump".length() + 2 + size * 2 + size / 4 * 4);
/* 1164 */     PrintWriter out = new PrintWriter(sw);
/* 1165 */     out.println("memory dump");
/*      */     
/* 1167 */     for (int i = 0; i < size; i++) {
/*      */       
/* 1169 */       byte b = getByte(offset + i);
/* 1170 */       if (i % 4 == 0) out.print("["); 
/* 1171 */       if (b >= 0 && b < 16)
/* 1172 */         out.print("0"); 
/* 1173 */       out.print(Integer.toHexString(b & 0xFF));
/* 1174 */       if (i % 4 == 3 && i < size - 1)
/* 1175 */         out.println("]"); 
/*      */     } 
/* 1177 */     if (sw.getBuffer().charAt(sw.getBuffer().length() - 2) != ']') {
/* 1178 */       out.println("]");
/*      */     }
/* 1180 */     return sw.toString();
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1185 */     return "native@0x" + Long.toHexString(this.peer);
/*      */   }
/*      */ 
/*      */   
/*      */   public static long nativeValue(Pointer p) {
/* 1190 */     return (p == null) ? 0L : p.peer;
/*      */   }
/*      */ 
/*      */   
/*      */   public static void nativeValue(Pointer p, long value) {
/* 1195 */     p.peer = value;
/*      */   }
/*      */   
/*      */   private static class Opaque extends Pointer {
/*      */     private Opaque(long peer) {
/* 1200 */       super(peer);
/* 1201 */       this.MSG = "This pointer is opaque: " + this;
/*      */     } private final String MSG;
/*      */     public Pointer share(long offset, long size) {
/* 1204 */       throw new UnsupportedOperationException(this.MSG);
/*      */     }
/*      */     
/*      */     public void clear(long size) {
/* 1208 */       throw new UnsupportedOperationException(this.MSG);
/*      */     }
/*      */     
/*      */     public long indexOf(long offset, byte value) {
/* 1212 */       throw new UnsupportedOperationException(this.MSG);
/*      */     }
/*      */     
/*      */     public void read(long bOff, byte[] buf, int index, int length) {
/* 1216 */       throw new UnsupportedOperationException(this.MSG);
/*      */     }
/*      */     
/*      */     public void read(long bOff, char[] buf, int index, int length) {
/* 1220 */       throw new UnsupportedOperationException(this.MSG);
/*      */     }
/*      */     
/*      */     public void read(long bOff, short[] buf, int index, int length) {
/* 1224 */       throw new UnsupportedOperationException(this.MSG);
/*      */     }
/*      */     
/*      */     public void read(long bOff, int[] buf, int index, int length) {
/* 1228 */       throw new UnsupportedOperationException(this.MSG);
/*      */     }
/*      */     
/*      */     public void read(long bOff, long[] buf, int index, int length) {
/* 1232 */       throw new UnsupportedOperationException(this.MSG);
/*      */     }
/*      */     
/*      */     public void read(long bOff, float[] buf, int index, int length) {
/* 1236 */       throw new UnsupportedOperationException(this.MSG);
/*      */     }
/*      */     
/*      */     public void read(long bOff, double[] buf, int index, int length) {
/* 1240 */       throw new UnsupportedOperationException(this.MSG);
/*      */     }
/*      */     
/*      */     public void read(long bOff, Pointer[] buf, int index, int length) {
/* 1244 */       throw new UnsupportedOperationException(this.MSG);
/*      */     }
/*      */     
/*      */     public void write(long bOff, byte[] buf, int index, int length) {
/* 1248 */       throw new UnsupportedOperationException(this.MSG);
/*      */     }
/*      */     
/*      */     public void write(long bOff, char[] buf, int index, int length) {
/* 1252 */       throw new UnsupportedOperationException(this.MSG);
/*      */     }
/*      */     
/*      */     public void write(long bOff, short[] buf, int index, int length) {
/* 1256 */       throw new UnsupportedOperationException(this.MSG);
/*      */     }
/*      */     
/*      */     public void write(long bOff, int[] buf, int index, int length) {
/* 1260 */       throw new UnsupportedOperationException(this.MSG);
/*      */     }
/*      */     
/*      */     public void write(long bOff, long[] buf, int index, int length) {
/* 1264 */       throw new UnsupportedOperationException(this.MSG);
/*      */     }
/*      */     
/*      */     public void write(long bOff, float[] buf, int index, int length) {
/* 1268 */       throw new UnsupportedOperationException(this.MSG);
/*      */     }
/*      */     
/*      */     public void write(long bOff, double[] buf, int index, int length) {
/* 1272 */       throw new UnsupportedOperationException(this.MSG);
/*      */     }
/*      */     
/*      */     public void write(long bOff, Pointer[] buf, int index, int length) {
/* 1276 */       throw new UnsupportedOperationException(this.MSG);
/*      */     }
/*      */     
/*      */     public ByteBuffer getByteBuffer(long offset, long length) {
/* 1280 */       throw new UnsupportedOperationException(this.MSG);
/*      */     }
/*      */     
/*      */     public byte getByte(long bOff) {
/* 1284 */       throw new UnsupportedOperationException(this.MSG);
/*      */     }
/*      */     
/*      */     public char getChar(long bOff) {
/* 1288 */       throw new UnsupportedOperationException(this.MSG);
/*      */     }
/*      */     
/*      */     public short getShort(long bOff) {
/* 1292 */       throw new UnsupportedOperationException(this.MSG);
/*      */     }
/*      */     
/*      */     public int getInt(long bOff) {
/* 1296 */       throw new UnsupportedOperationException(this.MSG);
/*      */     }
/*      */     
/*      */     public long getLong(long bOff) {
/* 1300 */       throw new UnsupportedOperationException(this.MSG);
/*      */     }
/*      */     
/*      */     public float getFloat(long bOff) {
/* 1304 */       throw new UnsupportedOperationException(this.MSG);
/*      */     }
/*      */     
/*      */     public double getDouble(long bOff) {
/* 1308 */       throw new UnsupportedOperationException(this.MSG);
/*      */     }
/*      */     
/*      */     public Pointer getPointer(long bOff) {
/* 1312 */       throw new UnsupportedOperationException(this.MSG);
/*      */     }
/*      */     
/*      */     public String getString(long bOff, String encoding) {
/* 1316 */       throw new UnsupportedOperationException(this.MSG);
/*      */     }
/*      */     
/*      */     public String getWideString(long bOff) {
/* 1320 */       throw new UnsupportedOperationException(this.MSG);
/*      */     }
/*      */     
/*      */     public void setByte(long bOff, byte value) {
/* 1324 */       throw new UnsupportedOperationException(this.MSG);
/*      */     }
/*      */     
/*      */     public void setChar(long bOff, char value) {
/* 1328 */       throw new UnsupportedOperationException(this.MSG);
/*      */     }
/*      */     
/*      */     public void setShort(long bOff, short value) {
/* 1332 */       throw new UnsupportedOperationException(this.MSG);
/*      */     }
/*      */     
/*      */     public void setInt(long bOff, int value) {
/* 1336 */       throw new UnsupportedOperationException(this.MSG);
/*      */     }
/*      */     
/*      */     public void setLong(long bOff, long value) {
/* 1340 */       throw new UnsupportedOperationException(this.MSG);
/*      */     }
/*      */     
/*      */     public void setFloat(long bOff, float value) {
/* 1344 */       throw new UnsupportedOperationException(this.MSG);
/*      */     }
/*      */     
/*      */     public void setDouble(long bOff, double value) {
/* 1348 */       throw new UnsupportedOperationException(this.MSG);
/*      */     }
/*      */     
/*      */     public void setPointer(long offset, Pointer value) {
/* 1352 */       throw new UnsupportedOperationException(this.MSG);
/*      */     }
/*      */     
/*      */     public void setString(long offset, String value, String encoding) {
/* 1356 */       throw new UnsupportedOperationException(this.MSG);
/*      */     }
/*      */     
/*      */     public void setWideString(long offset, String value) {
/* 1360 */       throw new UnsupportedOperationException(this.MSG);
/*      */     }
/*      */     
/*      */     public void setMemory(long offset, long size, byte value) {
/* 1364 */       throw new UnsupportedOperationException(this.MSG);
/*      */     }
/*      */     
/*      */     public String dump(long offset, int size) {
/* 1368 */       throw new UnsupportedOperationException(this.MSG);
/*      */     }
/*      */     
/*      */     public String toString() {
/* 1372 */       return "const@0x" + Long.toHexString(this.peer);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\com\sun\jna\Pointer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */