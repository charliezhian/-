/*     */ package com.sun.jna;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class IntegerType
/*     */   extends Number
/*     */   implements NativeMapped
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private int size;
/*     */   private Number number;
/*     */   private boolean unsigned;
/*     */   private long value;
/*     */   
/*     */   public IntegerType(int size) {
/*  52 */     this(size, 0L, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public IntegerType(int size, boolean unsigned) {
/*  57 */     this(size, 0L, unsigned);
/*     */   }
/*     */ 
/*     */   
/*     */   public IntegerType(int size, long value) {
/*  62 */     this(size, value, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public IntegerType(int size, long value, boolean unsigned) {
/*  67 */     this.size = size;
/*  68 */     this.unsigned = unsigned;
/*  69 */     setValue(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(long value) {
/*  76 */     long truncated = value;
/*  77 */     this.value = value;
/*  78 */     switch (this.size) {
/*     */       case 1:
/*  80 */         if (this.unsigned) this.value = value & 0xFFL; 
/*  81 */         truncated = (byte)(int)value;
/*  82 */         this.number = Byte.valueOf((byte)(int)value);
/*     */         break;
/*     */       case 2:
/*  85 */         if (this.unsigned) this.value = value & 0xFFFFL; 
/*  86 */         truncated = (short)(int)value;
/*  87 */         this.number = Short.valueOf((short)(int)value);
/*     */         break;
/*     */       case 4:
/*  90 */         if (this.unsigned) this.value = value & 0xFFFFFFFFL; 
/*  91 */         truncated = (int)value;
/*  92 */         this.number = Integer.valueOf((int)value);
/*     */         break;
/*     */       case 8:
/*  95 */         this.number = Long.valueOf(value);
/*     */         break;
/*     */       default:
/*  98 */         throw new IllegalArgumentException("Unsupported size: " + this.size);
/*     */     } 
/* 100 */     if (this.size < 8) {
/* 101 */       long mask = (1L << this.size * 8) - 1L ^ 0xFFFFFFFFFFFFFFFFL;
/* 102 */       if ((value < 0L && truncated != value) || (value >= 0L && (mask & value) != 0L))
/*     */       {
/* 104 */         throw new IllegalArgumentException("Argument value 0x" + 
/* 105 */             Long.toHexString(value) + " exceeds native capacity (" + this.size + " bytes) mask=0x" + 
/* 106 */             Long.toHexString(mask));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Object toNative() {
/* 113 */     return this.number;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object fromNative(Object nativeValue, FromNativeContext context) {
/* 120 */     long value = (nativeValue == null) ? 0L : ((Number)nativeValue).longValue();
/* 121 */     IntegerType number = (IntegerType)Klass.newInstance(getClass());
/* 122 */     number.setValue(value);
/* 123 */     return number;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> nativeType() {
/* 128 */     return this.number.getClass();
/*     */   }
/*     */ 
/*     */   
/*     */   public int intValue() {
/* 133 */     return (int)this.value;
/*     */   }
/*     */ 
/*     */   
/*     */   public long longValue() {
/* 138 */     return this.value;
/*     */   }
/*     */ 
/*     */   
/*     */   public float floatValue() {
/* 143 */     return this.number.floatValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public double doubleValue() {
/* 148 */     return this.number.doubleValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object rhs) {
/* 153 */     return (rhs instanceof IntegerType && this.number
/* 154 */       .equals(((IntegerType)rhs).number));
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 159 */     return this.number.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 164 */     return this.number.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends IntegerType> int compare(T v1, T v2) {
/* 182 */     if (v1 == v2)
/* 183 */       return 0; 
/* 184 */     if (v1 == null)
/* 185 */       return 1; 
/* 186 */     if (v2 == null) {
/* 187 */       return -1;
/*     */     }
/* 189 */     return compare(v1.longValue(), v2.longValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int compare(IntegerType v1, long v2) {
/* 205 */     if (v1 == null) {
/* 206 */       return 1;
/*     */     }
/* 208 */     return compare(v1.longValue(), v2);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int compare(long v1, long v2) {
/* 214 */     if (v1 == v2)
/* 215 */       return 0; 
/* 216 */     if (v1 < v2) {
/* 217 */       return -1;
/*     */     }
/* 219 */     return 1;
/*     */   }
/*     */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\com\sun\jna\IntegerType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */