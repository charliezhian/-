/*     */ package com.sun.jna;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NativeString
/*     */   implements CharSequence, Comparable
/*     */ {
/*     */   static final String WIDE_STRING = "--WIDE-STRING--";
/*     */   private Pointer pointer;
/*     */   private String encoding;
/*     */   
/*     */   private class StringMemory
/*     */     extends Memory
/*     */   {
/*     */     public StringMemory(long size) {
/*  39 */       super(size);
/*     */     }
/*     */     public String toString() {
/*  42 */       return NativeString.this.toString();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NativeString(String string) {
/*  50 */     this(string, Native.getDefaultStringEncoding());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NativeString(String string, boolean wide) {
/*  62 */     this(string, wide ? "--WIDE-STRING--" : Native.getDefaultStringEncoding());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NativeString(WString string) {
/*  69 */     this(string.toString(), "--WIDE-STRING--");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NativeString(String string, String encoding) {
/*  76 */     if (string == null) {
/*  77 */       throw new NullPointerException("String must not be null");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  82 */     this.encoding = encoding;
/*  83 */     if ("--WIDE-STRING--".equals(this.encoding)) {
/*  84 */       int len = (string.length() + 1) * Native.WCHAR_SIZE;
/*  85 */       this.pointer = new StringMemory(len);
/*  86 */       this.pointer.setWideString(0L, string);
/*     */     } else {
/*  88 */       byte[] data = Native.getBytes(string, encoding);
/*  89 */       this.pointer = new StringMemory((data.length + 1));
/*  90 */       this.pointer.write(0L, data, 0, data.length);
/*  91 */       this.pointer.setByte(data.length, (byte)0);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  97 */     return toString().hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object other) {
/* 102 */     if (other instanceof CharSequence) {
/* 103 */       return (compareTo(other) == 0);
/*     */     }
/* 105 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 110 */     boolean wide = "--WIDE-STRING--".equals(this.encoding);
/* 111 */     return wide ? this.pointer.getWideString(0L) : this.pointer.getString(0L, this.encoding);
/*     */   }
/*     */   
/*     */   public Pointer getPointer() {
/* 115 */     return this.pointer;
/*     */   }
/*     */ 
/*     */   
/*     */   public char charAt(int index) {
/* 120 */     return toString().charAt(index);
/*     */   }
/*     */ 
/*     */   
/*     */   public int length() {
/* 125 */     return toString().length();
/*     */   }
/*     */ 
/*     */   
/*     */   public CharSequence subSequence(int start, int end) {
/* 130 */     return toString().subSequence(start, end);
/*     */   }
/*     */ 
/*     */   
/*     */   public int compareTo(Object other) {
/* 135 */     if (other == null) {
/* 136 */       return 1;
/*     */     }
/* 138 */     return toString().compareTo(other.toString());
/*     */   }
/*     */ }


/* Location:              C:\Users\zyh\Desktop\ThinkPHP.V2.3.by蓝鲸.jar!\com\sun\jna\NativeString.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */